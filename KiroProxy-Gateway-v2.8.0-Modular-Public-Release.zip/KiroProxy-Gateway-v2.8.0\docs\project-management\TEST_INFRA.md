# KiroProxy Gateway — End-to-End Test Infrastructure Specification (`TEST_INFRA.md`)

## 1. Executive Summary & Purpose

The **KiroProxy Gateway E2E Test Suite** delivers rigorous, opaque-box end-to-end verification of the local multi-provider AI proxy gateway (`scripts/kiro_proxy_server.js`). The test suite validates complete protocol emulation, multi-provider reliability, browser-isolated reverse-tunneling (Ngrok Gemini Canvas Bridge), Kiro IDE agent integration, and uniform project rebranding.

The suite is engineered strictly from **authoritative user requirements** (`ORIGINAL_REQUEST.md` under section `## 2026-10-07T15:27:33Z` and `PROJECT.md`), adhering to the **systematic 4-tier testing methodology**.

---

## 2. Systematic 4-Tier Testing Methodology

The test suite categorizes all test cases into four distinct verification tiers:

| Tier | Name | Target Objective | Minimum Count | Actual Implemented |
|------|------|------------------|---------------|-------------------|
| **Tier 1** | **Feature Coverage** | Primary happy-path contracts, endpoints, schemas, headers, and protocol states for R1, R2, R3, and R4. | >= 5 per feature (20 total) | **24 tests** |
| **Tier 2** | **Boundary & Corner Cases** | Edge inputs, empty payloads, extreme prompt lengths, malformed JSON, invalid origins, foreign domains, and simulated network error handling. | >= 5 per feature (20 total) | **23 tests** |
| **Tier 3** | **Cross-Feature Combinations** | Pairwise interactions between distinct architectural subsystems (fallback + streaming, CORS + queueing, steering + Bedrock converse, etc.). | Complex interactions | **6 tests** |
| **Tier 4** | **Real-World Scenarios** | Full lifecycle emulation of end-to-end user workflows: Kiro IDE boot, multi-turn coding sessions, agent tool execution loops, and Gemini Canvas browser bridge sessions. | Real user journeys | **5 tests** |
| **Total** | | | **>= 45 tests** | **58 tests** |

---

## 3. Test Infrastructure Architecture

```
                                  ┌──────────────────────────────────────────────┐
                                  │           Master E2E Test Runner             │
                                  │         (tests/e2e/e2e_runner.js)            │
                                  └───────┬──────────────────────────────┬───────┘
                                          │                              │
                    ┌─────────────────────┴───────┐                      │
                    ▼                             ▼                      ▼
        ┌───────────────────────┐   ┌──────────────────────────┐   ┌───────────────────────────┐
        │   ServerManager       │   │       HttpClient         │   │   EventStreamDecoder      │
        │ - Health probe check  │   │ - HTTP/1.1 JSON requests │   │ - AWS Bedrock Prelude CRC │
        │ - Auto-spawn server   │   │ - Server-Sent Events     │   │ - Message CRC32 checksum  │
        │ - Graceful teardown   │   │ - Binary buffer stream   │   │ - Header & JSON decoder   │
        └───────────────────────┘   └─────────────┬────────────┘   └───────────────────────────┘
                                                  │
                                                  ▼
                                    ┌──────────────────────────┐
                                    │    KiroProxy Gateway     │
                                    │       (Port 8084)        │
                                    └──────────────────────────┘
```

### 3.1 Opaque-Box Independence
The test suite treats `KiroProxy Gateway` strictly as a black-box service communicating over TCP/IP:
- **Zero internal coupling**: Tests do NOT import internal classes, closures, or state variables from `scripts/kiro_proxy_server.js`.
- **Observable interfaces**: Every test validates external observable artifacts: HTTP status codes, JSON response bodies, SSE event streams, binary EventStream frames, HTTP response headers, filesystem configuration, and steering files.
- **Portability**: The test suite can run against a locally spawned Node process, a background daemon, a Docker container, or an Ngrok tunnel URL.

### 3.2 Key Components
1. **`tests/e2e/helpers/http_client.js`**:
   - Built on native Node.js `http` module with zero external dependencies.
   - Provides methods: `get()`, `post()`, `options()`, `request()`, and `streamSse()`.
   - Supports granular timeouts, custom HTTP headers (such as `x-amzn-*` and `ngrok-skip-browser-warning`), and binary buffer extraction.
2. **`tests/e2e/helpers/eventstream_decoder.js`**:
   - Independent parser for AWS Bedrock binary EventStream frames.
   - Validates **Prelude CRC32** (bytes 0..7) and **Message CRC32** (bytes 0..totalLen-5) using standard Node.js `zlib.crc32`.
   - Decodes AWS binary headers (Type 7 strings, boolean flags, integers) and extracts event payloads (`assistantResponseEvent`, `toolUseEvent`, `metadataEvent`).
3. **`tests/e2e/helpers/server_manager.js`**:
   - Inspects target port (default 8084).
   - If server is running, tests execute against the active instance.
   - If server is not running, spawns `scripts/kiro_proxy_server.js`, polls `/health` readiness probe, and cleanly stops it upon suite completion.

---

## 4. Comprehensive Feature & Test Matrix

### Requirement 1: Free Model Inference & Reliability Audit
| Test ID | Tier | Name | Target Verification |
|---------|------|------|---------------------|
| `T1_R1_01` | Tier 1 | Models Endpoint Discovery | `GET /listAvailableModels` returns 200 with non-empty array, required model metadata, and backward-compatible pricing structure. |
| `T1_R1_02` | Tier 1 | OpenAI Models Endpoint | `GET /v1/models` returns 200 with OpenAI-compatible schema (`object: "list"`). |
| `T1_R1_03` | Tier 1 | Multi-Provider Free Tiers | Verifies presence of free models across Kilo, Cline, OpenRouter, OrcaRouter, Gemini. |
| `T1_R1_04` | Tier 1 | Chat Completions Schema | `POST /v1/chat/completions` returns valid OpenAI `chat.completion` with role `assistant` or structured 502 fallback. |
| `T1_R1_05` | Tier 1 | Streaming SSE Inference | `POST /v1/chat/completions` with `stream: true` yields SSE stream terminating with `data: [DONE]`. |
| `T1_R1_06` | Tier 1 | Reliability & Metrics | `GET /status` reports uptime/version and `GET /metrics` exports Prometheus metrics. |
| `T2_R1_01` | Tier 2 | Empty Messages Validation | `POST /v1/chat/completions` with `messages: []` returns HTTP 400 (`invalid_request_error`). |
| `T2_R1_02` | Tier 2 | Null Message Content | `POST /v1/chat/completions` with null content returns HTTP 400. |
| `T2_R1_03` | Tier 2 | Missing Messages Key | Request omitting `messages` property returns HTTP 400. |
| `T2_R1_04` | Tier 2 | Unknown Model ID Fallback | Unknown model triggers auto-routing fallback or structured 502 without process crash. |
| `T2_R1_05` | Tier 2 | Extreme Message Size | Large payload (15KB+) handled cleanly without buffer overflow or socket drop. |
| `T2_R1_06` | Tier 2 | Malformed JSON Body | Syntactically corrupted JSON body rejected gracefully without server crash. |

### Requirement 2: Ngrok Gemini Canvas Bridge Isolation & CORS
| Test ID | Tier | Name | Target Verification |
|---------|------|------|---------------------|
| `T1_R2_01` | Tier 1 | Canvas Dashboard Delivery | `GET /canvas` returns HTTP 200 HTML dashboard with Canvas Bridge UI. |
| `T1_R2_02` | Tier 1 | Preflight CORS Headers | `OPTIONS /poll` returns CORS headers allowing `ngrok-skip-browser-warning` and browser origins. |
| `T1_R2_03` | Tier 1 | Polling Queue Contract | `GET /poll` returns 200 with queue metadata (`serverTime`, `queueDepth`, `id`). |
| `T1_R2_04` | Tier 1 | Chunk Streaming Ingestion | `POST /chunk` accepts streamed tokens with HTTP 200 'ok'. |
| `T1_R2_05` | Tier 1 | Completion Signal | `POST /done` accepts completion signal and functionCalls with HTTP 200 'ok'. |
| `T1_R2_06` | Tier 1 | Request Cancellation | `POST /cancel` cancels pending request returning `{ success: true }`. |
| `T2_R2_01` | Tier 2 | Foreign Origins Handling | Preflight requests from foreign origins receive permissive CORS headers. |
| `T2_R2_02` | Tier 2 | Rapid Concurrent Polling | Concurrent polling calls handled safely by long-polling engine / rate limiter. |
| `T2_R2_03` | Tier 2 | Orphan Chunk Payload | `POST /chunk` without ID handled without unhandled exception. |
| `T2_R2_04` | Tier 2 | Orphan Done Signal | `POST /done` with unknown ID handled safely. |
| `T2_R2_05` | Tier 2 | Empty Cancel Payload | `POST /cancel` without ID returns `{ success: true, cancelled: null }`. |
| `T2_R2_06` | Tier 2 | Malformed Chunk Body | Non-JSON text body to `/chunk` handled safely. |

### Requirement 3: Local Kiro IDE Application Integration Verification
| Test ID | Tier | Name | Target Verification |
|---------|------|------|---------------------|
| `T1_R3_01` | Tier 1 | Workflow Run Stub | `POST /runtime/workflows/run` returns 200 with `fallbackMode: "direct_execution"`. |
| `T1_R3_02` | Tier 1 | Workflow Inspect & Validate | Inspect returns 404, Validate returns 501 according to IDE compatibility layer. |
| `T1_R3_03` | Tier 1 | Unlimited Usage Limits | `GET /usagelimits` returns unlimited credits (`>= 10000`) and active status. |
| `T1_R3_04` | Tier 1 | Feature Configurations | `GET /featureconfiguration` returns AWS treatment flags for steering and retries. |
| `T1_R3_05` | Tier 1 | Bedrock EventStream Frames | `POST /generateAssistantResponse` emits binary EventStream with valid CRC32 framing. |
| `T1_R3_06` | Tier 1 | Steering File Enforcement | `.kiro/steering/proxy-mode.md` has `inclusion: auto` preventing workflow failure loops. |
| `T2_R3_01` | Tier 2 | Empty Conversation State | `POST /generateAssistantResponse` with `{}` handled cleanly via EventStream. |
| `T2_R3_02` | Tier 2 | Extreme AWS Headers | Extreme headers (500+ chars) processed without HTTP splitting errors. |
| `T2_R3_03` | Tier 2 | Deeply Nested Tool Schemas| Complex tool parameter schemas sanitized without call stack exhaustion. |
| `T2_R3_04` | Tier 2 | Catch-All Route Invariant | Unknown AWS actions handled by universal catch-all with 200 AWS envelope. |
| `T2_R3_05` | Tier 2 | Concurrent Converse Streams | Concurrent converse streaming requests execute without CRC32 buffer cross-talk. |

### Requirement 4: Comprehensive Rebranding to "KiroProxy Gateway"
| Test ID | Tier | Name | Target Verification |
|---------|------|------|---------------------|
| `T1_R4_01` | Tier 1 | Health Endpoint Rebranding | `GET /health` returns rebranded status (`message: "KiroProxy Active"` or `proxy: "KiroProxy Gateway"`). |
| `T1_R4_02` | Tier 1 | Status Endpoint Metadata | `GET /status` returns version and uptime without deprecated naming. |
| `T1_R4_03` | Tier 1 | Package Metadata Rebranding| `package.json` reflects KiroProxy Gateway name and description. |
| `T1_R4_04` | Tier 1 | Batch Launcher Rebranding | `start.bat` identifies proxy as KiroProxy Gateway. |
| `T1_R4_05` | Tier 1 | Documentation Rebranding | `README.md` uniformly refers to KiroProxy Gateway while preserving "Kilo Gateway" for `api.kilo.ai`. |
| `T1_R4_06` | Tier 1 | AWS Server Header Compliance| Protocol endpoints emit `Server: Amazon.com` conforming to Kiro IDE expectations. |
| `T2_R4_01` | Tier 2 | Case-Insensitive URL Routing | Endpoints resolve regardless of casing (`/HEALTH`, `/Status`, `/v1/MODELS`). |
| `T2_R4_02` | Tier 2 | Query Parameter Immunity | Query parameters on `/health` do not alter JSON schema. |
| `T2_R4_03` | Tier 2 | Legacy Path Aliases | Legacy paths (`/api/health`, `/api/hello`) return rebranded health JSON. |
| `T2_R4_04` | Tier 2 | Metadata Disambiguation | Server telemetry contains clean proxy metadata. |
| `T2_R4_05` | Tier 2 | Error Response Headers | 400 responses preserve valid JSON structure and headers. |

### Cross-Feature Combinations & Real-World Scenarios (Tiers 3 & 4)
| Test ID | Tier | Name | Target Verification |
|---------|------|------|---------------------|
| `T3_COMB_01` | Tier 3 | Fallback + Streaming | SSE stream requesting `model: auto` completes streaming chunks cleanly. |
| `T3_COMB_02` | Tier 3 | CORS + Ngrok Queueing | `OPTIONS` preflight followed by `GET /poll` with browser origin and ngrok headers. |
| `T3_COMB_03` | Tier 3 | Steering + Bedrock Converse | Converse payload with steering prompt and tools generates valid EventStream frames. |
| `T3_COMB_04` | Tier 3 | Canvas Bridge Lifecycle | Multi-chunk streaming followed by `/done` signal. |
| `T3_COMB_05` | Tier 3 | Telemetry under Load | `/health` and `/status` remain responsive during active inference. |
| `T3_COMB_06` | Tier 3 | Workflow Stub + Converse Stream | Workflow stub returns direct execution, followed immediately by converse stream. |
| `T4_SCEN_01` | Tier 4 | Kiro IDE Cold Boot | Full boot sequence: health -> models -> features -> limits -> profile -> spaces. |
| `T4_SCEN_02` | Tier 4 | Multi-Turn Conversation | Multi-turn coding conversation maintaining session continuity via EventStream. |
| `T4_SCEN_03` | Tier 4 | Agent Tool Invocation Loop | Agent prompt with tools produces valid Bedrock frames for tool execution. |
| `T4_SCEN_04` | Tier 4 | Workflow Recovery Flow | IDE workflow request degradation followed by prompt execution. |
| `T4_SCEN_05` | Tier 4 | Gemini Canvas Browser Cycle | Full cycle from `gemini.google.com` (preflight -> poll -> chunk -> done). |

---

## 5. Execution Guide & CLI Options

### Run Entire E2E Suite
```bash
node tests/e2e/e2e_runner.js
```

### Run by Specific Tier
```bash
node tests/e2e/e2e_runner.js --tier=1    # Feature Coverage only
node tests/e2e/e2e_runner.js --tier=2    # Boundary & Corner cases only
node tests/e2e/e2e_runner.js --tier=3    # Cross-feature combinations only
node tests/e2e/e2e_runner.js --tier=4    # Real-world scenarios only
```

### Custom Port / Remote Target
```bash
node tests/e2e/e2e_runner.js --port=8084
```

### Fail Fast Mode
```bash
node tests/e2e/e2e_runner.js --bail
```

### JSON Reporting for CI/CD
```bash
node tests/e2e/e2e_runner.js --json
```
