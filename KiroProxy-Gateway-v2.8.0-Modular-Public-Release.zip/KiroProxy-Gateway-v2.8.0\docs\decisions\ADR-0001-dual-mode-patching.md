# ADR-0001: Dual-Mode Extension Patching Architecture

- **Status:** Accepted
- **Date:** 2026-08-20
- **Deciders:** Core Architecture Team
- **Component:** [`scripts/patch_kiro_extension.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js)

---

## Context
Kiro IDE (`kiro.kiro-agent`) communicates exclusively with AWS Bedrock / Q Developer cloud backends over authenticated HTTPS. The client application contains no native user interface for configuring custom proxy endpoints or third-party LLM providers. Without modifying extension behavior, all user interactions are locked to paid AWS cloud models.

However, completely replacing the extension binary would prevent users from ever using native AWS Bedrock models if desired, and would break with every IDE auto-update.

## Decision
Implement a non-destructive AST/regex dual-mode patching mechanism (`patch_kiro_extension.js`) that injects a conditional redirection hook into `extension.js`. The patch checks `config/kiro_ai_config.json`:
- If `mode === "proxy"`, endpoint URLs redirect to `http://127.0.0.1:8084`.
- If `mode === "native"`, original AWS Bedrock endpoints and credentials remain active.

A dedicated backup file (`extension.js.bak`) is created prior to modification, and three idempotent NPM lifecycle scripts are provided:
- `npm run patch`: Applies the 4 required regex hooks.
- `npm run patch:check`: Inspects applied patch count (0/4 through 4/4).
- `npm run patch:restore`: Restores stock `extension.js` from `.bak`.

## Alternatives (Evidenced in Code/Docs)
1. **Full Extension Fork & Replacement:** Rejected because Kiro IDE extension auto-updates overwrite replaced directories, causing catastrophic breaks.
2. **OS-Level DNS Redirection / Hosts File Spoofing:** Rejected because AWS SDK validates SSL certificates and SigV4 authentication headers; proxying HTTPS without local root CA installation fails.

## Consequences
- **Positive:** Seamless toggle between zero-cost local gateway and native AWS Bedrock. Zero installation friction.
- **Negative:** Kiro IDE version updates overwrite `extension.js`, requiring users to re-run `npm run patch`. Minified variable names may drift, requiring regex maintenance.

## Do Not Change Unless
Do not change this patching model unless Kiro IDE officially introduces native OpenAI/Anthropic proxy configuration settings in its core UI preferences, rendering local byte patching obsolete.

## Evidence
- Implementation: [`scripts/patch_kiro_extension.js#L45-L95`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js)
- Test Verification: [`tests/test_full_suite_v2.js#L15`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_full_suite_v2.js)
