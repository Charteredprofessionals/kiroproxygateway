# Architecture Documentation

This section contains technical architecture documentation for developers and maintainers.

## 📄 Available Documents

- **[Kiro Gateway Architecture Guide](KIRO_GATEWAY_ARCHITECTURE_GUIDE.md)** - Complete system design

## 🎯 Purpose

These documents describe the internal architecture, data flow, and design decisions of the KiroProxy Gateway.

---

**Part of KiroProxy Gateway Documentation**