/**
 * Global Automode Interceptor
 * 
 * Overrides global fetch() to support comma-separated provider URLs with multi-model failover.
 * When a URL contains multiple provider domains separated by commas (e.g., 
 * "https://api.kilo.ai,https://api.cline.bot"), this interceptor automatically:
 * 
 * 1. Splits the URL into individual provider endpoints
 * 2. Maps each provider domain to its free model list
 * 3. Implements a two-tier retry loop:
 *    - Outer loop: Iterate through provider URLs
 *    - Inner loop: For each provider, try all its free models
 * 4. Mutates request body's `model` field on each attempt
 * 5. Falls over to next model/provider on 429, 401, 403, or 5xx errors
 * 
 * Single-URL requests (no comma) pass through with zero overhead.
 * 
 * @module global_automode_interceptor
 */
const originalFetch = global.fetch;

/**
 * Provider domain to free models mapping (v2.8.0-beta)
 * Priority: 1. Kilo -> 2. Cline -> 3. OpenRouter -> 4. OrcaRouter -> 5. Gemini -> 6. Custom Providers
 */
const PROVIDER_FREE_MODELS = {
  'api.kilo.ai': [],
  'api.cline.bot': [],
  'openrouter.ai': [],
  'api.orcarouter.ai': [],
  'generativelanguage.googleapis.com': [],
  'api.groq.com': [],
  'devgateway.space-z.ai': [],
  'corset-decipher-vocation.ngrok-free.dev': []
};

const PROVIDER_PRIORITY_ORDER = [
  'api.kilo.ai',
  'api.cline.bot',
  'openrouter.ai',
  'api.orcarouter.ai',
  'generativelanguage.googleapis.com',
  'api.groq.com',
  'devgateway.space-z.ai',
  'corset-decipher-vocation.ngrok-free.dev'
];

/**
 * Dynamically synchronize PROVIDER_FREE_MODELS from auto-populated model catalog
 * @param {Array} models - Array of model objects from MODELS.models
 */
function syncFromCatalog(models) {
  if (!Array.isArray(models)) return;
  const nonChatPattern = /(?:lyria|content-safety|embedding|imagen|veo|aqa|tts|whisper|moderation)/i;

  const domainMap = {
    kilo: 'api.kilo.ai',
    cline: 'api.cline.bot',
    openrouter: 'openrouter.ai',
    orcarouter: 'api.orcarouter.ai',
    orca: 'api.orcarouter.ai',
    gemini: 'generativelanguage.googleapis.com'
  };

  for (const m of models) {
    if (!m || m.modelId === 'global-automode' || m.modelId.endsWith('-otomode')) continue;
    if (m.rateMultiplier !== 0.0 && m.category !== 'free') continue;
    const slug = m.upstreamSlug || m.modelId;
    if (!slug || slug === 'kilo-auto/small' || nonChatPattern.test(slug)) continue;

    let domain = null;
    if (m.provider === 'custom' && m._customProvider && m._customProvider.baseUrl) {
      domain = extractDomain(m._customProvider.baseUrl);
    } else if (domainMap[m.provider]) {
      domain = domainMap[m.provider];
    }

    if (domain) {
      if (!PROVIDER_FREE_MODELS[domain]) {
        PROVIDER_FREE_MODELS[domain] = [];
      }
      if (!PROVIDER_FREE_MODELS[domain].includes(slug)) {
        PROVIDER_FREE_MODELS[domain].push(slug);
      }
      if (!PROVIDER_PRIORITY_ORDER.includes(domain)) {
        PROVIDER_PRIORITY_ORDER.push(domain);
      }
    }
  }
  console.log(`[GlobalAutomode] Dynamic catalog synced: ${Object.keys(PROVIDER_FREE_MODELS).length} provider domains active`);
}

/**
 * Extract domain from URL string
 * @param {string} url - Full URL
 * @returns {string} - Hostname/domain
 */
function extractDomain(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname;
  } catch (e) {
    console.warn('[GlobalAutomode] Failed to parse URL:', url, e.message);
    return '';
  }
}

/**
 * Custom fetch implementation with multi-provider failover
 * @param {string|Request} input - URL string or Request object
 * @param {object} init - Fetch options
 * @returns {Promise<Response>}
 */
async function customFetch(input, init = {}) {
  // Extract URL
  const url = typeof input === 'string' ? input : input.url;
  
  // Single-URL passthrough (optimization)
  if (!url || !url.includes(',')) {
    return originalFetch(input, init);
  }
  
  // Multi-provider detected — sort by priority order (Kilo -> Cline -> OpenRouter -> OrcaRouter -> Gemini -> Custom Providers)
  const rawUrls = url.split(',').map(u => u.trim());
  const providerUrls = rawUrls.sort((a, b) => {
    const domA = extractDomain(a);
    const domB = extractDomain(b);
    const idxA = PROVIDER_PRIORITY_ORDER.indexOf(domA);
    const idxB = PROVIDER_PRIORITY_ORDER.indexOf(domB);
    const rankA = idxA === -1 ? 999 : idxA;
    const rankB = idxB === -1 ? 999 : idxB;
    return rankA - rankB;
  });
  console.log(`[GlobalAutomode] Priority order: ${providerUrls.length} providers - ${providerUrls.join(' → ')}`);
  
  let lastError = null;
  let lastResponse = null;
  
  // Outer loop: Iterate through provider URLs in strict priority order
  for (let i = 0; i < providerUrls.length; i++) {
    const providerUrl = providerUrls[i];
    const domain = extractDomain(providerUrl);
    const models = PROVIDER_FREE_MODELS[domain] || [];
    
    if (models.length === 0) {
      console.log(`[GlobalAutomode] Provider ${i + 1}/${providerUrls.length}: ${providerUrl} - No free models mapped, skipping`);
      continue;
    }
    
    console.log(`[GlobalAutomode] Provider ${i + 1}/${providerUrls.length}: ${providerUrl} - ${models.length} models available`);
    
    // Inner loop: Try all free models for this provider (free model 1 -> free model 2 -> and so on)
    for (let j = 0; j < models.length; j++) {
      const model = models[j];
      
      try {
        // Clone and mutate request body
        let mutatedBody = init.body;
        if (init.body && typeof init.body === 'string') {
          try {
            const bodyObj = JSON.parse(init.body);
            bodyObj.model = model;
            mutatedBody = JSON.stringify(bodyObj); // Stringify mutated body
          } catch (parseErr) {
            console.warn('[GlobalAutomode] Failed to parse request body, using original');
          }
        }
        
        console.log(`[GlobalAutomode]   Model ${j + 1}/${models.length}: ${model} - Attempting...`);
        
        // Create mutated request
        const mutatedInit = { ...init, body: mutatedBody };
        const response = await originalFetch(providerUrl, mutatedInit);
        
        // Success path (2xx, 3xx)
        if (response.status >= 200 && response.status < 400) {
          console.log(`[GlobalAutomode]   SUCCESS: Model ${model} succeeded with status ${response.status}`);
          return response;
        }
        
        // Failover conditions: 429 (rate limit), 401/403 (auth), 402 (payment), 404 (unavailable), 422, 5xx (server error)
        if (response.status === 429 || response.status === 401 || response.status === 402 || response.status === 403 || response.status === 404 || response.status === 422 || response.status >= 500) {
          console.log(`[GlobalAutomode]   FAILED: Model ${model} failed with status ${response.status}, trying next free model...`);
          lastResponse = response;
          continue; // Try next free model
        }
        
        // Other 4xx client errors
        console.warn(`[GlobalAutomode]   WARNING: Model ${model} returned client error ${response.status}, trying next model...`);
        lastResponse = response;
        continue;
        
      } catch (fetchErr) {
        console.warn(`[GlobalAutomode]   ERROR: Model ${model} threw error: ${fetchErr.message}, trying next model...`);
        lastError = fetchErr;
        continue; // Try next model
      }
    }
    
    // Inner loop exhausted - all models failed for this provider
    console.log(`[GlobalAutomode] Provider ${providerUrl} exhausted all ${models.length} models, switching provider...`);
  }
  
  // All providers and models exhausted
  console.error(`[GlobalAutomode] All ${providerUrls.length} providers and their models exhausted, returning last error`);
  
  if (lastResponse) {
    return lastResponse;
  }
  if (lastError) {
    throw lastError;
  }
  
  // Fallback error
  throw new Error('GlobalAutomode: All providers exhausted with no response');
}

/**
 * Install the global fetch interceptor
 */
function install() {
  console.log('[GlobalAutomode] Installing global fetch interceptor...');
  global.fetch = customFetch;
  console.log('[Global Automode] \u2705 Global fetch interceptor installed');
}

/**
 * Restore original fetch (for testing/uninstall)
 */
function uninstall() {
  console.log('[GlobalAutomode] Uninstalling global fetch interceptor...');
  global.fetch = originalFetch;
  console.log('[GlobalAutomode] \u2705 Original fetch restored');
}

module.exports = {
  install,
  uninstall,
  extractDomain,
  syncFromCatalog,
  PROVIDER_FREE_MODELS,
  PROVIDER_PRIORITY_ORDER,
  _customFetch: customFetch // Exported for testing
};
