/**
 * src/providers/kilo.js - Kilo Gateway Provider Adapter (https://api.kilo.ai)
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const { executeWithRetry } = require('../resilience/retry_engine');
const { isCircuitOpen } = require('../resilience/circuit_breaker');
const { ProxyError } = require('../resilience/errors');
const { loadCustomConfig } = require('../config/index');
const { translateToolsToUpstream } = require('../translators/tool_translator');
const { recordProviderCall } = require('../resilience/metrics');
const { extractToolsAndTextFromProviderResponse } = require('../translators/tool_extractor');
const { rotateProviderKey } = require('../resilience/key_rotator');

function callKiloGateway(messages, model, tools = [], otomodeContext = null) {
  return executeWithRetry(async () => {
    if (isCircuitOpen('kilo')) {
      throw new ProxyError(
        'CIRCUIT_OPEN',
        'Kilo Gateway circuit breaker is open',
        'Wait 30s for automatic recovery or try another provider'
      );
    }

    const start = Date.now();
    return new Promise((resolve, reject) => {
      const cfg = loadCustomConfig();

      const translatedTools = tools && tools.length > 0
        ? translateToolsToUpstream(tools, 'openai')
        : undefined;

      const kiloModel = (model && model !== 'kilogateway' && model !== 'kilo-free' && model !== 'kilo-auto/small')
        ? model
        : 'kilo-auto/free';

      const requestBody = {
        model: kiloModel,
        messages: messages
      };

      if (translatedTools) {
        requestBody.tools = translatedTools;
      }

      const postData = JSON.stringify(requestBody);

      const keys = cfg.kiloApiKeys || [];
      const activeKey = cfg.kiloApiKey || (keys.length > 0 ? keys[0] : null);

      const headers = {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData),
        'User-Agent': 'Kiro-Integration/2.7.0'
      };

      if (activeKey && activeKey.trim().length > 0) {
        headers['Authorization'] = `Bearer ${activeKey.trim()}`;
      }

      const options = {
        hostname: 'api.kilo.ai',
        port: 443,
        path: '/api/gateway/chat/completions',
        method: 'POST',
        headers: headers,
        timeout: 90000
      };

      console.log(`[KiroProxy] Forwarding to Kilo Gateway (https://api.kilo.ai [${kiloModel}]${activeKey ? ' [Authenticated User Priority]' : ' [Anonymous]'}${translatedTools ? `, ${translatedTools.length} tools` : ''})`);

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          const latency = Date.now() - start;
          try {
            const parsed = JSON.parse(data);
            if (res.statusCode >= 200 && res.statusCode < 300) {
              const extracted = extractToolsAndTextFromProviderResponse(parsed, tools);
              const hasValidContent = Boolean(((extracted.text && extracted.text.trim().length > 0) || (extracted.toolCalls && extracted.toolCalls.length > 0)) && !parsed.error);

              if (hasValidContent) {
                recordProviderCall('kilo', true, latency);
                resolve({
                  ...parsed,
                  _kiro: extracted
                });
                return;
              }

              console.warn(`[KiroProxy] ⚠️ Kilo Gateway returned HTTP 200 with empty completion (0 text, 0 tools) for model '${kiloModel}'`);
              recordProviderCall('kilo', false, latency);

              if (otomodeContext && otomodeContext._fallbackList && otomodeContext._fallbackList.length > 0) {
                const oldModel = otomodeContext._activeModel || kiloModel;
                const nextModel = otomodeContext._fallbackList.shift();
                otomodeContext._activeModel = nextModel;
                const delay = 50;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName || 'Kilo'}) from ${oldModel} → ${nextModel} due to EMPTY_RESPONSE (HTTP 200)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callKiloGateway(messages, nextModel, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }

              if (otomodeContext && (!otomodeContext._fallbackList || otomodeContext._fallbackList.length === 0)) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName || 'Kilo'}`);
              }

              const emptyErr = new ProxyError(
                'EMPTY_RESPONSE',
                `Kilo Gateway (${res.statusCode}): Model returned 0 text and 0 tools`,
                'Free model context saturated or empty completion received',
                { statusCode: res.statusCode }
              );
              emptyErr.code = 'EMPTY_RESPONSE';
              reject(emptyErr);
              return;
            } else {
              if (translatedTools && (res.statusCode === 400 || res.statusCode === 422)) {
                console.log(`[KiroProxy] 🔄 Kilo model '${kiloModel}' rejected native tools (${res.statusCode}); retrying with prompt-based tool guide...`);
                callKiloGateway(messages, kiloModel, [], otomodeContext).then(resolve).catch(reject);
                return;
              }

              recordProviderCall('kilo', false, latency);

              const isOtomodeRetryable = res.statusCode >= 400;

              if (otomodeContext && otomodeContext._fallbackList.length > 0 && isOtomodeRetryable) {
                const oldModel = otomodeContext._activeModel;
                const nextModel = otomodeContext._fallbackList.shift();
                if (nextModel) {
                  otomodeContext._activeModel = nextModel;
                  const delay = 250 + Math.random() * 500;
                  console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName}) from ${oldModel} → ${nextModel} due to HTTP ${res.statusCode} (${otomodeContext._fallbackList.length} free models remaining)`);
                  (async () => {
                    await new Promise(r => setTimeout(r, delay));
                    try {
                      const result = await callKiloGateway(messages, nextModel, tools, otomodeContext);
                      resolve(result);
                    } catch (err) {
                      reject(err);
                    }
                  })();
                  return;
                }
              }

              if (otomodeContext && otomodeContext._fallbackList.length === 0 && isOtomodeRetryable) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName}`);
              }

              if (!otomodeContext && (res.statusCode === 402 || res.statusCode === 404) && kiloModel !== 'kilo-auto/free') {
                console.log(`[KiroProxy] 🔄 Kilo model '${kiloModel}' returned HTTP ${res.statusCode}; falling back to 'kilo-auto/free'...`);
                callKiloGateway(messages, 'kilo-auto/free', tools, null).then(resolve).catch(reject);
                return;
              }

              if (res.statusCode === 401 || res.statusCode === 429) {
                rotateProviderKey('kilo', cfg);
                console.log(`[KiroProxy] Kilo key rotated (${res.statusCode}) — retrying...`);
              }
              reject(new ProxyError(
                'PROVIDER_ERROR',
                `Kilo Gateway (${res.statusCode}): ${parsed.error?.message || data}`,
                'Check Kilo Gateway status at https://status.kilo.ai',
                { statusCode: res.statusCode }
              ));
            }
          } catch {
            recordProviderCall('kilo', false, latency);
            reject(new ProxyError(
              'INVALID_RESPONSE',
              `Invalid JSON from Kilo Gateway (${res.statusCode}): ${data.slice(0, 150)}`,
              'Provider returned malformed response',
              { statusCode: res.statusCode }
            ));
          }
        });
      });

      req.on('error', err => {
        recordProviderCall('kilo', false, Date.now() - start);
        reject(new ProxyError(
          'NETWORK_ERROR',
          `Failed to reach Kilo Gateway: ${err.message}`,
          'Check internet connection and firewall rules',
          { originalError: err.message }
        ));
      });

      req.on('timeout', () => {
        req.destroy();
        recordProviderCall('kilo', false, Date.now() - start);
        reject(new ProxyError(
          'TIMEOUT',
          'Kilo Gateway timed out',
          'Increase timeout or try another provider',
          { timeout: 90000 }
        ));
      });

      req.write(postData);
      req.end();
    });
  }, 'kilo', otomodeContext ? 1 : 3);
}

module.exports = {
  callKiloGateway
};
