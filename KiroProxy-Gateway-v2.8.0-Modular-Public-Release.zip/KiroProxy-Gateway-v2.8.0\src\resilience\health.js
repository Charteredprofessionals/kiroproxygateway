/**
 * src/resilience/health.js - Provider health check monitoring engine
 * Enforces singleton identity (INV-09)
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const http = require('http');
const { URL } = require('url');
const { loadCustomConfig, isKeyValid } = require('../config/index');

const HEALTH_STATUS = {
  providers: {
    kilo: { status: 'unknown', latency: 0, lastCheck: 0, error: null },
    cline: { status: 'unknown', latency: 0, lastCheck: 0, error: null },
    openrouter: { status: 'unknown', latency: 0, lastCheck: 0, error: null },
    orcarouter: { status: 'unknown', latency: 0, lastCheck: 0, error: null },
    ngrok: { status: 'unknown', latency: 0, lastCheck: 0, error: null },
    gemini: { status: 'unknown', latency: 0, lastCheck: 0, error: null }
  },
  lastHealthCheck: 0
};

async function checkProviderHealth(providerName, checkFn) {
  const start = Date.now();
  try {
    await checkFn();
    const latency = Date.now() - start;
    HEALTH_STATUS.providers[providerName] = {
      status: 'healthy',
      latency,
      lastCheck: Date.now(),
      error: null
    };
    console.log(`[HealthCheck] ✅ ${providerName}: healthy (${latency}ms)`);
    return true;
  } catch (err) {
    HEALTH_STATUS.providers[providerName] = {
      status: 'degraded',
      latency: Date.now() - start,
      lastCheck: Date.now(),
      error: err.message
    };
    console.warn(`[HealthCheck] ⚠️  ${providerName}: degraded (${err.message})`);
    return false;
  }
}

async function runHealthChecks() {
  console.log('[HealthCheck] Running provider health checks...');
  HEALTH_STATUS.lastHealthCheck = Date.now();

  const checks = [
    checkProviderHealth('kilo', () => new Promise((resolve, reject) => {
      const req = https.get({
        hostname: 'api.kilo.ai',
        path: '/api/gateway/models',
        timeout: 5000
      }, (res) => {
        if (res.statusCode === 200 || res.statusCode === 401) resolve();
        else reject(new Error(`HTTP ${res.statusCode}`));
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.end();
    })),
    
    checkProviderHealth('cline', () => new Promise((resolve, reject) => {
      const req = https.get({
        hostname: 'api.cline.bot',
        path: '/api/v1/models',
        timeout: 5000
      }, (res) => {
        if (res.statusCode === 200 || res.statusCode === 401) resolve();
        else reject(new Error(`HTTP ${res.statusCode}`));
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.end();
    })),
    
    checkProviderHealth('openrouter', () => new Promise((resolve, reject) => {
      const req = https.get({
        hostname: 'openrouter.ai',
        path: '/api/v1/models',
        timeout: 5000
      }, (res) => {
        if (res.statusCode === 200) resolve();
        else reject(new Error(`HTTP ${res.statusCode}`));
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.end();
    })),
    
    checkProviderHealth('orcarouter', () => new Promise((resolve, reject) => {
      const cfg = loadCustomConfig();
      if (!cfg.providers?.orcarouter?.apiKey || !isKeyValid(cfg.providers.orcarouter.apiKey)) {
        return resolve();
      }
      const req = https.get({
        hostname: 'api.orcarouter.ai',
        path: '/v1/models',
        headers: { 'Authorization': `Bearer ${cfg.providers.orcarouter.apiKey}` },
        timeout: 5000
      }, (res) => {
        if (res.statusCode === 200) resolve();
        else reject(new Error(`HTTP ${res.statusCode}`));
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.end();
    })),
    
    checkProviderHealth('ngrok', () => new Promise((resolve, reject) => {
      const cfg = loadCustomConfig();
      const ngrokAuthtoken = cfg.ngrokAuthtoken;
      const geminiGatewayUrl = cfg.geminiGatewayUrl || cfg.ngrokUrl || 'http://localhost:8081';
      
      if (!ngrokAuthtoken || ngrokAuthtoken === '' || !geminiGatewayUrl || geminiGatewayUrl === 'http://localhost:8081') {
        return resolve();
      }
      
      try {
        const urlObj = new URL(geminiGatewayUrl + '/health');
        const isHttps = urlObj.protocol === 'https:';
        const httpModule = isHttps ? https : http;
        
        const req = httpModule.get({
          hostname: urlObj.hostname,
          port: urlObj.port || (isHttps ? 443 : 80),
          path: '/health',
          headers: { 'ngrok-skip-browser-warning': '69420' },
          timeout: 5000
        }, (res) => {
          if (res.statusCode === 200) resolve();
          else reject(new Error(`HTTP ${res.statusCode}`));
        });
        req.on('error', reject);
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
        req.end();
      } catch (err) {
        reject(err);
      }
    })),
    
    checkProviderHealth('gemini', () => new Promise((resolve, reject) => {
      const cfg = loadCustomConfig();
      const apiKey = cfg?.providers?.gemini?.apiKey || cfg.geminiApiKey || process.env.GEMINI_API_KEY;
      
      if (!apiKey || apiKey === 'YOUR_GEMINI_API_KEY_HERE' || !isKeyValid(apiKey)) {
        return resolve();
      }
      
      const useHeaderAuth = apiKey.startsWith('AQ.');
      const reqOptions = {
        hostname: 'generativelanguage.googleapis.com',
        path: useHeaderAuth ? '/v1beta/models' : `/v1beta/models?key=${apiKey}`,
        timeout: 5000
      };
      
      if (useHeaderAuth) {
        reqOptions.headers = { 'X-goog-api-key': apiKey };
      }
      
      const req = https.get(reqOptions, (res) => {
        if (res.statusCode === 200) resolve();
        else reject(new Error(`HTTP ${res.statusCode}`));
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      req.end();
    }))
  ];

  await Promise.all(checks);

  const cfg = loadCustomConfig();
  const customProviders = (cfg.customProviders || []).filter(p => p.enabled !== false && p.baseUrl && p.apiKey);
  const customChecks = customProviders.map(p => {
    const key = 'custom-' + p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    return checkProviderHealth(key, () => new Promise((resolve, reject) => {
      try {
        const baseUrl = p.baseUrl.replace(/\/$/, '');
        const urlObj = new URL(baseUrl + '/models');
        const isHttps = urlObj.protocol === 'https:';
        const mod = isHttps ? https : http;
        const req = mod.get({
          hostname: urlObj.hostname,
          port: urlObj.port || (isHttps ? 443 : 80),
          path: urlObj.pathname,
          headers: { 'Authorization': `Bearer ${p.apiKey}`, 'User-Agent': 'KiroProxy/2.7.0' },
          timeout: 5000
        }, (res) => {
          if (res.statusCode === 200 || res.statusCode === 401 || res.statusCode === 403) resolve();
          else reject(new Error(`HTTP ${res.statusCode}`));
        });
        req.on('error', reject);
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
        req.end();
      } catch (err) { reject(err); }
    }));
  });
  await Promise.all(customChecks);

  return HEALTH_STATUS;
}

let tunnelUrl = null;

function getTunnelUrl() {
  return tunnelUrl;
}

async function startNgrokTunnel(port = 8084) {
  if (port !== 8084) return null;
  let ngrok = null;
  try {
    ngrok = require('@ngrok/ngrok');
  } catch (_) {
    return null;
  }
  const cfg = loadCustomConfig();
  const token = cfg.ngrokAuthtoken ||
                cfg.providers?.ngrok?.authtoken ||
                process.env.NGROK_AUTHTOKEN ||
                process.env.NGROK_TOKEN;
  if (!token || token === 'your_ngrok_authtoken_here' || !isKeyValid(token)) {
    return null;
  }
  try {
    const listener = await ngrok.forward({ addr: port, authtoken: token });
    tunnelUrl = listener.url();
    console.log(`[Ngrok] 🌐 Remote access enabled: ${tunnelUrl}`);
    return tunnelUrl;
  } catch (err) {
    console.warn(`[Ngrok] Continuing on localhost only (${err.message})`);
    tunnelUrl = null;
    return null;
  }
}

module.exports = {
  HEALTH_STATUS,
  checkProviderHealth,
  runHealthChecks,
  startNgrokTunnel,
  getTunnelUrl
};
