/**
 * src/providers/orcarouter.js - OrcaRouter Provider Adapter (https://api.orcarouter.ai)
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const { executeWithRetry } = require('../resilience/retry_engine');
const { isCircuitOpen } = require('../resilience/circuit_breaker');
const { ProxyError } = require('../resilience/errors');
const { isKeyValid } = require('../config/index');
const { translateToolsToUpstream } = require('../translators/tool_translator');
const { recordProviderCall } = require('../resilience/metrics');
const { extractToolsAndTextFromProviderResponse } = require('../translators/tool_extractor');

const ORCAROUTER_TIMEOUT = 120000;

function callOrcaRouter(messages, requestedModel, apiKey, tools = [], otomodeContext = null) {
  return executeWithRetry(async () => {
    if (isCircuitOpen('orcarouter')) {
      const err = new Error('OrcaRouter circuit breaker is open');
      err.code = 'CIRCUIT_OPEN';
      throw err;
    }

    if (!apiKey || !isKeyValid(apiKey)) {
      const err = new Error('No valid OrcaRouter API key configured');
      err.code = 'MISSING_API_KEY';
      throw err;
    }

    const start = Date.now();
    const modelSlug = (requestedModel || 'orcarouter/free').replace(/^orca-/, '');

    return new Promise((resolve, reject) => {
      const translatedTools = tools && tools.length > 0
        ? translateToolsToUpstream(tools, 'openai')
        : undefined;

      const requestBody = {
        model: modelSlug,
        messages: messages,
        stream: false
      };

      if (translatedTools) {
        requestBody.tools = translatedTools;
      }

      const postData = JSON.stringify(requestBody);

      const options = {
        hostname: 'api.orcarouter.ai',
        port: 443,
        path: '/v1/chat/completions',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'Authorization': `Bearer ${apiKey}`,
          'User-Agent': 'KiroProxy/2.7.0'
        },
        timeout: ORCAROUTER_TIMEOUT
      };

      console.log(`[KiroProxy] Forwarding to OrcaRouter (https://api.orcarouter.ai, model=${modelSlug}${translatedTools ? `, ${translatedTools.length} tools` : ''})...`);

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          const latency = Date.now() - start;

          try {
            const parsed = JSON.parse(data);
            if (res.statusCode >= 200 && res.statusCode < 300) {
              const extracted = extractToolsAndTextFromProviderResponse(parsed, tools);
              const hasValidContent = Boolean(((extracted.text && extracted.text.trim().length > 0) || (extracted.toolCalls && extracted.toolCalls.length > 0)) && !parsed.error);

              if (hasValidContent) {
                recordProviderCall('orcarouter', true, latency);
                resolve({
                  ...parsed,
                  _kiro: extracted
                });
                return;
              }

              console.warn(`[KiroProxy] ⚠️ OrcaRouter returned HTTP 200 with empty completion (0 text, 0 tools) for model '${modelSlug}'`);
              recordProviderCall('orcarouter', false, latency);

              if (otomodeContext && otomodeContext._fallbackList && otomodeContext._fallbackList.length > 0) {
                const oldModel = otomodeContext._activeModel || modelSlug || requestedModel;
                const nextModel = otomodeContext._fallbackList.shift();
                otomodeContext._activeModel = nextModel;
                const delay = 50;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName || 'OrcaRouter'}) from ${oldModel} → ${nextModel} due to EMPTY_RESPONSE (HTTP 200)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callOrcaRouter(messages, nextModel, apiKey, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }

              if (otomodeContext && (!otomodeContext._fallbackList || otomodeContext._fallbackList.length === 0)) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName || 'OrcaRouter'}`);
              }

              const emptyErr = new ProxyError(
                'EMPTY_RESPONSE',
                `OrcaRouter (${res.statusCode}): Model returned 0 text and 0 tools`,
                'Free model context saturated or empty completion received',
                { statusCode: res.statusCode }
              );
              emptyErr.code = 'EMPTY_RESPONSE';
              reject(emptyErr);
              return;
            } else {
              if (translatedTools && (res.statusCode === 400 || res.statusCode === 422)) {
                console.log(`[KiroProxy] 🔄 OrcaRouter model '${modelSlug}' rejected native tools (${res.statusCode}); retrying with prompt-based tool guide...`);
                callOrcaRouter(messages, modelSlug, apiKey, [], otomodeContext).then(resolve).catch(reject);
                return;
              }
              recordProviderCall('orcarouter', false, latency);

              const isOtomodeRetryable = res.statusCode >= 400;
              if (otomodeContext && otomodeContext._fallbackList.length > 0 && isOtomodeRetryable) {
                const oldModel = otomodeContext._activeModel;
                const nextModel = otomodeContext._fallbackList.shift();
                if (nextModel) {
                  otomodeContext._activeModel = nextModel;
                  const delay = 250 + Math.random() * 500;
                  console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName}) from ${oldModel} → ${nextModel} due to HTTP ${res.statusCode} (${otomodeContext._fallbackList.length} free models remaining)`);
                  (async () => {
                    await new Promise(r => setTimeout(r, delay));
                    try {
                      const result = await callOrcaRouter(messages, nextModel, apiKey, tools, otomodeContext);
                      resolve(result);
                    } catch (err) {
                      reject(err);
                    }
                  })();
                  return;
                }
              }

              if (otomodeContext && otomodeContext._fallbackList.length === 0 && isOtomodeRetryable) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName}`);
              }

              const err = new Error(`OrcaRouter (${res.statusCode}): ${parsed.error?.message || data.slice(0, 100)}`);
              err.code = 'PROVIDER_ERROR';
              reject(err);
            }
          } catch {
            recordProviderCall('orcarouter', false, latency);
            const err = new Error(`Invalid JSON from OrcaRouter (${res.statusCode}): ${data.slice(0, 150)}`);
            err.code = 'INVALID_RESPONSE';
            reject(err);
          }
        });
      });

      req.on('error', err => {
        recordProviderCall('orcarouter', false, Date.now() - start);
        err.code = err.code || 'NETWORK_ERROR';
        reject(err);
      });

      req.on('timeout', () => {
        req.destroy();
        recordProviderCall('orcarouter', false, Date.now() - start);
        const err = new Error(`OrcaRouter timed out after ${ORCAROUTER_TIMEOUT}ms`);
        err.code = 'TIMEOUT';
        reject(err);
      });

      req.write(postData);
      req.end();
    });
  }, 'orcarouter', otomodeContext ? 1 : 3);
}

module.exports = {
  callOrcaRouter
};
