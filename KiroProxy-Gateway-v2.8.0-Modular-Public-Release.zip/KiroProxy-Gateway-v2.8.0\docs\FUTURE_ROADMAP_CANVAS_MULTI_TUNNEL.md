# Future Roadmap Plan — Canvas Bridge Tunnel & Sub-Tunnel URL Manager (Multi-Chat Interfaces)

**Status:** Saved for Future Implementation  
**Target Component:** KiroProxy Gateway (`src/providers/canvas_bridge.js`, `src/handlers/canvas_handler.js`, `src/config/index.js`, `public/config.html`, `scripts/canvas_bridge_dashboard.html`)

---

## 1. Architectural & Capability Assessment (Current State)

1. **Current GUI Tunnel Display ([`public/config.html`](file:///d:/sdlc_studio/projects/kiro-integration/public/config.html) & [`src/resilience/health.js`](file:///d:/sdlc_studio/projects/kiro-integration/src/resilience/health.js))**:
   - In the current GUI header, the `Tunnel:` pill is read-only (populated from `@ngrok/ngrok` auto-discovery via `getTunnelUrl()`).
   - There is not yet a dedicated input field in the GUI header to manually edit the primary tunnel URL or define sub-tunnel URLs for the `/canvas` script generator.
2. **Multi-Chat Interface Support via Reverse-Polling (`/canvas`, `/poll`, `/chunk`, `/done`)**:
   - Because [`src/providers/canvas_bridge.js`](file:///d:/sdlc_studio/projects/kiro-integration/src/providers/canvas_bridge.js) uses a shared work queue (`geminiQueue`), users can already open multiple browser chat tabs simultaneously across one or more tunnels (Ngrok, Cloudflare Tunnel, Localtunnel, etc.) pointing to `localhost:8084`, and they act as concurrent workers pulling prompts from `geminiQueue`.
3. **Multi-Tunnel Routing via Custom Providers (`baseUrls: []`)**:
   - For tunnel-hosted OpenAI-compatible bridges (such as `Abhyast-Gemini` on `*.ngrok-free.dev/v1`), the **🌐 Base URL Failover Priority Order (`baseUrls: []`)** in the **⚙️ Custom Providers** tab already allows adding and reordering multiple tunnel/sub-tunnel URLs in the GUI.
   - When Chat Interface #1 (Tunnel URL #1) is busy, rate-limited, or disconnected, KiroProxy automatically fails over to Chat Interface #2 (Tunnel/Sub-Tunnel URL #2).

---

## 2. Planned Enhancement — Canvas Bridge Tunnel & Sub-Tunnel URL Manager

### Goal
Allow users to configure, prioritize, and switch between multiple **Primary Tunnel URLs** and **Sub-Tunnel URLs / Routes** (e.g., `/bridge-1/poll`, `/bridge-2/poll`, or multiple distinct tunnel domains) directly from the Command Center GUI (`/config`) and Canvas Bridge GUI (`/canvas`) to drive multiple isolated or pooled browser chat interfaces (Gemini, Claude Web, ChatGPT Web, etc.).

### Planned Implementation Steps

#### Step 1: Configuration Schema Extension ([`src/config/index.js`](file:///d:/sdlc_studio/projects/kiro-integration/src/config/index.js))
Add `canvasBridgeTunnels` to `kiro_ai_config.json`:
```json
{
  "canvasBridgeTunnels": {
    "primaryTunnelUrl": "https://primary-tunnel.ngrok-free.dev",
    "tunnelUrls": [
      "https://primary-tunnel.ngrok-free.dev",
      "https://backup-tunnel.trycloudflare.com"
    ],
    "subTunnels": [
      {
        "id": "bridge-1",
        "name": "Gemini Chat Tab #1",
        "subPath": "/bridge-1",
        "targetModel": "gemini-3-flash-preview",
        "priority": 1,
        "enabled": true
      },
      {
        "id": "bridge-2",
        "name": "Gemini Chat Tab #2",
        "subPath": "/bridge-2",
        "targetModel": "gemini-3-flash-preview",
        "priority": 2,
        "enabled": true
      }
    ]
  }
}
```

#### Step 2: Sub-Tunnel Queue Partitioning & Failover ([`src/providers/canvas_bridge.js`](file:///d:/sdlc_studio/projects/kiro-integration/src/providers/canvas_bridge.js) & [`src/handlers/canvas_handler.js`](file:///d:/sdlc_studio/projects/kiro-integration/src/handlers/canvas_handler.js))
- Support both **Shared Worker Pool Mode** (all sub-tunnels pull from the global `geminiQueue`) and **Dedicated Sub-Tunnel Routing Mode** (`/:subPath/poll`, `/:subPath/chunk`, `/:subPath/done`, `/:subPath/cancel`).
- Automatically fail over across `subTunnels` in user-defined priority order when a specific chat interface tab stops polling or times out.

#### Step 3: GUI Controls in `/config` & `/canvas` ([`public/config.html`](file:///d:/sdlc_studio/projects/kiro-integration/public/config.html) & [`scripts/canvas_bridge_dashboard.html`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/canvas_bridge_dashboard.html))
- Make the top `Tunnel:` status bar editable/selectable in `/config`.
- Add a **Canvas Bridge Tunnel & Sub-Tunnel URL Manager** section:
  - Add, remove, and reorder (`⬆️ / ⬇️`) Primary & Fallback Tunnel URLs (`tunnelUrls: []`).
  - Add, remove, and reorder (`⬆️ / ⬇️`) Sub-Tunnel routes (`/bridge-1`, `/bridge-2`, etc.) for separate browser chat interfaces.
  - One-click Userscript / Bookmarklet generator pre-configured with the selected Tunnel + Sub-Tunnel URL.
