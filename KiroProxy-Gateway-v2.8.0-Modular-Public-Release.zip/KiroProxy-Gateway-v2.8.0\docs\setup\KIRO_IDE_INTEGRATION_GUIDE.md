# Kiro IDE Integration Guide — KiroProxy Gateway

**Seamless Dual-Mode Routing, Dynamic Extension Patching & Model Auto-Population**

---

## 🎯 Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                       Kiro IDE                              │
│       (Local VS Code-based Agentic Development IDE)         │
└──────────────────────────────┬──────────────────────────────┘
                               │
       Dynamic Dual-Mode Patch │ (dist/extension.js)
       • Local Proxy Active?   ──► http://127.0.0.1:8084
       • Local Proxy Offline?  ──► https://bedrock-runtime... (AWS Native)
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                 KiroProxy Gateway (Port 8084)               │
│  • AWS Bedrock EventStream Emulation (CRC32 checksums)      │
│  • Direct Tool Execution Steering (no workflow loops)       │
│  • 5-Tier Zero-Cost Fallback Engine                         │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
  ┌──────────────┬─────────────┴─┬──────────────┬─────────────┐
  ▼              ▼               ▼              ▼             ▼
Kilo Gateway   Cline Free   OpenRouter Free  OrcaRouter   Custom Models
(api.kilo.ai)  (Free Tier)     (:free)       (Free Tier)  (Groq/Ollama)
```

---

## 🛠️ Step-by-Step Setup

### Step 1: Verify KiroProxy Gateway is Active
Ensure KiroProxy Gateway is running on port 8084:
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8084/health"
```
You should see:
```json
{
  "status": "ok",
  "message": "KiroProxy Active",
  "version": "2.7.0",
  "providersHealthy": "7/7"
}
```

### Step 2: Set CLOUD_CONFIG_ENDPOINT
Configure the environment variable so Kiro IDE discovers the local endpoint:
```powershell
[System.Environment]::SetEnvironmentVariable("CLOUD_CONFIG_ENDPOINT", "http://127.0.0.1:8084", "User")
```

### Step 3: Run the Dynamic Extension Patcher
Run the dual-mode patcher script:
```powershell
cd d:\sdlc_studio\projects\kiro-integration
node scripts/patch_kiro_extension.js
```

Verify that all patches are active:
```powershell
node scripts/patch_kiro_extension.js --check
```

Expected Output:
```text
=== Kiro IDE Extension Patch Status ===
Extension file: ...\kiro.kiro-agent\dist\extension.js
Backup file:    ...\extension.js.original

Patch 1 (Model list dynamic fallback) : ✅ APPLIED
Patch 2 (cloudConfig conditional)     : ✅ CLEAN
Patch 3A (KRS Client dynamic endpoint) : ✅ APPLIED
Patch 3B (Runtime Prompt URL / getTarget): ✅ APPLIED
Overall: FULLY PATCHED (Dual-mode proxy support active)
```

### Step 4: ⚠️ CRITICAL: Reload Kiro IDE Window
Because `extension.js` is loaded into memory when Kiro IDE launches, you **must reload the IDE window** to activate the patch:
1. In Kiro IDE, press <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>P</kbd>
2. Type **`Developer: Reload Window`**
3. Press <kbd>Enter</kbd>

### Step 5: Send a Prompt
1. In the Agent panel, select `auto`, `kilo/gemma-4-26b`, `cline-free`, or `ngrok-gemini-flash`.
2. Type: `"Hello from Kiro IDE"`
3. The response streams instantly with valid Bedrock EventStream frames.

---

## 🐛 Troubleshooting

### Issue: "The model '...' is not available. Please select a different model and try again."
- **Root Cause:** When a prompt is submitted, Kiro IDE's runtime executes `getTarget()` to resolve the destination URL for `POST /generateAssistantResponse`. **Patch 3B** (`WHGW_RUNTIME_OVERRIDE`) intercepts `getTarget()` to route prompts to `http://127.0.0.1:8084`, bypassing AWS region/login restrictions (`oos.has(n)`). Simultaneously, **Patch 3A** (`WHGW_FORCE_8084`) intercepts minified KRS client resolvers (`Bte`, `Zee`, `Lte`, `RKo`). If either patch is unapplied or if Kiro IDE has not reloaded `extension.js` into memory, requests escape to AWS Bedrock Cloud where proxy models do not exist.
- **Solution:** 
  1. Run `node scripts/patch_kiro_extension.js` (verifies Patch 1, 2, 3A, and 3B are applied).
  2. In Kiro IDE, press <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd> $\rightarrow$ run **`Developer: Reload Window`**.

### Issue: "Workflows are not available in proxy mode"
- **Cause:** Kiro IDE attempted to orchestrate an AWS Cloud workflow.
- **Solution:** Direct execution steering is enforced in `.kiro/steering/proxy-mode.md` (`inclusion: auto`), instructing the agent to directly execute workspace tools (`read_file`, `str_replace`, `fs_write`, `execute_pwsh`).

### Issue: Restoring Unpatched Extension
If you ever want to revert Kiro IDE to stock AWS Cloud behavior:
```powershell
node scripts/patch_kiro_extension.js --restore
```
Or run `scripts\batch\uninstall.bat`.

---

*KiroProxy Gateway — Zero-cost development with full local IDE parity.*
