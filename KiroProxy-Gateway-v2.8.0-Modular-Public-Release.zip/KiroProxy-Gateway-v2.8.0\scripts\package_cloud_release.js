/**
 * scripts/package_cloud_release.js
 * Packages the updated cloud gateway into dist/kiroproxy-gateway-cloud.zip
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SOURCE_DIR = path.resolve(__dirname, '..', 'tmp_cloud_audit');
const STAGING_DIR = path.resolve(__dirname, '..', 'dist', 'cloud_staging');
const TARGET_ZIP = path.resolve(__dirname, '..', 'dist', 'kiroproxy-gateway-cloud.zip');

function copyDirRecursive(src, dest, excludeDirs = new Set(['node_modules', '.git', '.cache'])) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (entry.isDirectory()) {
      if (!excludeDirs.has(entry.name)) {
        copyDirRecursive(srcPath, destPath, excludeDirs);
      }
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function main() {
  console.log('[1/3] Staging cloud gateway files...');
  if (fs.existsSync(STAGING_DIR)) {
    fs.rmSync(STAGING_DIR, { recursive: true, force: true });
  }
  copyDirRecursive(SOURCE_DIR, STAGING_DIR);

  console.log('[2/3] Compressing into kiroproxy-gateway-cloud.zip...');
  if (fs.existsSync(TARGET_ZIP)) {
    fs.unlinkSync(TARGET_ZIP);
  }

  // Compress contents of STAGING_DIR
  const psCmd = `Compress-Archive -Path "${STAGING_DIR}\\*" -DestinationPath "${TARGET_ZIP}" -Force`;
  execSync(`powershell -NoProfile -Command "${psCmd}"`, { stdio: 'inherit' });

  // Clean staging directory
  fs.rmSync(STAGING_DIR, { recursive: true, force: true });

  const sizeKb = (fs.statSync(TARGET_ZIP).size / 1024).toFixed(1);
  console.log(`[3/3] Done! Created ${TARGET_ZIP} (${sizeKb} KB)`);
}

main();
