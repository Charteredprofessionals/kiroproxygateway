# Invariants and Gotchas — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary Files:** [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/patch_kiro_extension.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js)  
**Audience:** Future AI assistants and systems architects modifying or debugging the gateway.

---

## 1. Invariants (Must Always Be True)

These rules are load-bearing invariants. Any code change violating them will break protocol emulation or provider dispatch.

| ID | Invariant Statement | Classification | Code Evidence | Failure Mode if Broken |
| :--- | :--- | :--- | :--- | :--- |
| **INV-01** | All models in `MODELS.models` catalog MUST set `rateMultiplier: 0.0`. | `[FACT]` | [`scripts/kiro_proxy_server.js#L735-L1140`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Kiro IDE triggers native billing/credit decrement UI for user requests. |
| **INV-02** | Every `modelId` MUST use its exact provider prefix (`kilo-*`, `cline-*`, `openrouter-*`, `orca-*`, `gemini-*`, `ngrok-*`, `custom-*`). | `[FACT]` | [`scripts/kiro_proxy_server.js#L4114`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`dispatchInference`) | Model routing regex fails to match provider, falling back to 503 error. |
| **INV-03** | Global Automode (Mode 3) MUST execute the strict 6-tier fallback: Kilo → Cline → OpenRouter → OrcaRouter → Gemini → Custom Providers. | `[FACT]` | [`scripts/kiro_proxy_server.js#L4199-L4256`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Exhausts paid or quota-limited providers before free zero-key upstream providers. |
| **INV-04** | Canvas Bridge (`ngrok-*`) MUST be excluded from Global Automode. | `[FACT]` | [`scripts/kiro_proxy_server.js#L4254`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/utils/global_automode_interceptor.js#L77`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js) | Browser userscript DOM polling blocks the automated queue for up to 120s, freezing IDE chat. |
| **INV-05** | AWS Bedrock EventStream frames MUST adhere to binary prelude (12 bytes), header type 7 (String), and CRC32 checksums. | `[FACT]` | [`scripts/kiro_proxy_server.js#L2077-L2130`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`createEventStreamFrame`) | Kiro IDE throws `CRC32 mismatch` or `Invalid EventStream prelude`, terminating connection immediately. |
| **INV-06** | `toolUseEvent.input` MUST be serialized as a JSON string (`JSON.stringify(args)`), NEVER as a JavaScript object. | `[FACT]` | [`scripts/kiro_proxy_server.js#L4905`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/kiro_proxy_server.js#L5218`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Kiro IDE Smithy deserializer throws parse error; tool card fails to render or execute. |
| **INV-07** | Raw JSON strings containing Windows file paths MUST be sanitized with `sanitizeJsonBackslashes()` before calling `JSON.parse()`. | `[FACT]` | [`scripts/kiro_proxy_server.js#L2276`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/kiro_proxy_server.js#L4579-L4605`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `JSON.parse` crashes on `d:\project\test` (`\p` and `\t` invalid escape characters); tool call is lost. |
| **INV-08** | Proprietary workflow tools (`FORBIDDEN_TOOLS_IN_PROXY`) MUST be filtered out of payload tools sent to upstream LLMs. | `[FACT]` | [`scripts/kiro_proxy_server.js#L4659-L4672`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | LLM hallucinates `run_workflow` calls, enters infinite retry loops, and fails because proxy has no workflow engine. |
| **INV-09** | Global state singletons (`CIRCUIT_BREAKERS`, `METRICS`, `HEALTH_STATUS`, `geminiQueue`) MUST maintain object identity. | `[FACT]` | [`scripts/kiro_proxy_server.js#L306`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/kiro_proxy_server.js#L452`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Re-assignment drops active queues, active circuit breaker trip counters, and metrics counters. |
| **INV-10** | Half-open circuit breakers allow exactly 1 probe request (`HALF_OPEN_REQUESTS.get(provider) === 1`). | `[FACT]` | [`scripts/kiro_proxy_server.js#L381`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Burst of parallel requests floods failing upstream endpoint during recovery test. |
| **INV-11** | Endpoints `/runtime/workflows/*` MUST respond with HTTP 404 or 501 stub responses. | `[FACT]` | [`scripts/kiro_proxy_server.js#L5984-L6020`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Proxy hangs attempting to invoke non-existent AWS cloud workflow runtimes. |
| **INV-12** | Model aliases (`ls`/`dir` → `list_directory`, `cat`/`read` → `read_file`, `grep` → `grep_search`) MUST be mapped in inbound translation. | `[FACT]` | [`scripts/kiro_proxy_server.js#L2480-L2510`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | LLMs outputting standard shell commands fail tool execution because Kiro IDE rejects unknown tool names. |

---

## 2. Gotchas (Non-Obvious Behavior)

### G1: Disconnected `scripts/utils/` Modules
- **`[FACT]`**: `scripts/kiro_proxy_server.js:51` only imports `global_automode_interceptor.js`.
- **`[FACT]`**: The files `api_key_rotator.js`, `request_queue.js`, `smart_retry_engine.js`, `structured_logger.js`, and `validators.js` exist in `scripts/utils/`, but are **NOT** imported by `kiro_proxy_server.js`.
- **Gotcha**: Modifying `scripts/utils/smart_retry_engine.js` has **zero effect** on proxy server runtime behavior! The server continues to run its inline `executeWithRetry()` (line 383) and inline `rotateProviderKey()` (line 1200).
- **Action**: Always edit the inline implementations in `scripts/kiro_proxy_server.js` until the server is refactored into ES modules.

### G2: Workspace Root Required for Steering & Subagents
- **`[FACT]`**: Kiro IDE relies on workspace folders to locate `.kiro/steering/` rules and proxy configuration.
- **`[INFERRED]`**: When Kiro IDE displays `EXPLORER: NO FOLDER OPENED`, steering prompts (`#/proxy-mode`) fail to load, and subagents attempting to operate on relative path `.` fail with path resolution errors.
- **Gotcha**: Users reporting "/slash command not working" or "agent cannot find files" usually have an empty workspace window rather than a proxy bug.

### G3: Inbound Direct XML Tool Tags (Format 6b)
- **`[FACT]`**: Certain models (GLM-4, Gemini 2.5 Flash via OpenRouter) output tool calls as raw XML tags in their response text rather than structured OpenAI function calls:
  ```xml
  <read_file>
  d:\project\src\index.js
  </read_file>
  ```
- **Gotcha**: Kiro IDE cannot parse direct XML tags. If `extractToolCallsFromResponse()` does not match Format 6b ([`scripts/kiro_proxy_server.js#L2420-L2475`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)), the XML is displayed as raw text in the chat window and the tool never executes.

### G4: Bare JSON Tool Invocations (Format 1b)
- **`[FACT]`**: DeepSeek V3 and Kilo models occasionally emit raw JSON objects without code fences or tool names:
  ```json
  {"path": "scripts/kiro_proxy_server.js"}
  ```
- **Gotcha**: Without Format 1b parser ([`scripts/kiro_proxy_server.js#L2380-L2415`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)), this text leaks into chat. The parser uses heuristic parameter keys (`path` → `read_file`, `command` → `execute_bash`) to reconstruct valid Kiro tool calls.

### G5: Cumulative Timeout vs Per-Request Timeout
- **`[FACT]`**: `executeWithRetry()` enforces a cumulative timeout of 180,000ms (`MAX_CUMULATIVE_TIMEOUT_MS`, line 402).
- **Gotcha**: If individual request timeout is 45s, 4 sequential provider retries will hit the cumulative limit and abort with `Cumulative timeout exceeded (180000ms)` before trying all remaining backup providers.

### G6: Canvas Bridge DOM Polling & Tab Visibility
- **`[FACT]`**: Canvas Bridge routes browser requests to Gemini Web via `userscript.js` polling `/poll` ([`scripts/kiro_proxy_server.js#L6475`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)).
- **Gotcha**: Modern browsers (Chrome, Edge) throttle `setInterval` / `fetch` in inactive background tabs. If the Gemini browser tab is minimized or hidden, `/poll` latency increases from 500ms to 30,000ms+, causing Kiro IDE chat to time out.

---

## 3. Fragile Areas (Do Not Touch Without Reading)

### FA-1: Extension Patch Pointers in `scripts/patch_kiro_extension.js`
- **Path:** [`scripts/patch_kiro_extension.js#L45-L95`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js)
- **Why Fragile:** Patches minified code (`extension.js`) inside `~/.kiro/extensions/kiro.kiro-agent-*/`.
- **Hazards:** 
  - Variable names (e.g., `e.endpoint`, `t.baseUrl`) change across Kiro IDE version updates.
  - Applying patches without verifying regex anchors corrupts the minified JS bundle.
- **Mandatory Guard:** Always execute `npm run patch:check` before and after modifications. Always keep backups (`extension.js.bak`).

### FA-2: EventStream Binary Frame Assembly
- **Path:** [`scripts/kiro_proxy_server.js#L2077-L2150`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)
- **Why Fragile:** Direct byte-level Buffer allocation and CRC32 table arithmetic:
  - Byte 0..3: Total Length (BE UInt32)
  - Byte 4..7: Headers Length (BE UInt32)
  - Byte 8..11: Prelude CRC32 (BE UInt32)
  - Byte 12..N: Headers + Payload
  - Byte N..N+4: Message CRC32 (BE UInt32)
- **Hazards:** Off-by-one errors in payload slicing or CRC calculation immediately drop the WebSocket/SSE stream.

### FA-3: Dual-Stage JSON Backslash Sanitizer
- **Path:** [`scripts/kiro_proxy_server.js#L2276-L2340`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)
- **Why Fragile:** Regex replaces unescaped Windows path backslashes without corrupting valid JSON escape sequences (`\"`, `\\`, `\n`, `\r`, `\t`, `\uXXXX`).
- **Hazards:** Naive string replacements break multiline string outputs or code generated by the LLM.

---

## 4. Race Conditions

| Scenario | Location | Impact | Mitigation in Code |
| :--- | :--- | :--- | :--- |
| **Concurrent Half-Open Probes** | [`scripts/kiro_proxy_server.js#L381`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Multiple parallel requests hit a recovering provider simultaneously. | `HALF_OPEN_REQUESTS` Map stores atomic in-flight probe state; subsequent requests are rejected until probe completes. |
| **Canvas Queue Dequeue Race** | [`scripts/kiro_proxy_server.js#L6480`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Multiple browser tabs polling `/poll` pop the same request. | Request is popped synchronously (`geminiQueue.shift()`) and moved to `pendingGeminiRequests` map. |
| **Dynamic Model Discovery Overwrite** | [`scripts/kiro_proxy_server.js#L1400-L1650`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Periodic background catalog refresh clobbers custom user models. | Model merger retains existing `rateMultiplier: 0.0` and custom prefixes; updates only active upstream lists. |

---

## 5. Hidden Couplings

```mermaid
graph TD
    A["Kiro IDE Extension (extension.js)"] -->|"Reads base URL"| B["config/kiro_ai_config.json"]
    A -->|"Sends Smithy POST"| C["scripts/kiro_proxy_server.js:5609"]
    C -->|"Emulates Bedrock Framing"| D["AWS EventStream Binary Spec"]
    C -->|"Suppresses forbidden tools"| E["AWS Cloud Workflow Tools"]
    C -->|"Reads steering rules"| F[".kiro/steering/#/proxy-mode"]
    C -->|"Excludes from AutoMode"| G["Canvas Bridge /poll Userscript"]
```

1. **Extension Bundle ↔ Port 8084**: Patched `extension.js` hardcodes or reads `http://127.0.0.1:8084` from `config/kiro_ai_config.json`. Changing `PROXY_PORT` requires updating the config and restarting both proxy and IDE.
2. **Smithy Tool Names ↔ Proxy Translators**: Kiro IDE expects exact tool names (`execute_bash`, `read_file`, `write_to_file`, `list_directory`). Upstream LLMs using generic names (`bash`, `read`, `ls`) must be normalized by `scripts/kiro_proxy_server.js:2480`.
3. **Canvas Bridge ↔ Browser DOM**: `userscript.js` directly queries Gemini Web UI DOM selectors (`rich-textarea`, `send-button`). If Google updates Gemini's web frontend, Canvas Bridge breaks without modifying proxy code.

---

## 6. Past Bugs and Fixes

| Bug ID | Date | Affected Area | Root Cause | Fix Applied | Code Reference |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **BUG-01** | 2026-09 | Tool Execution | Windows paths `d:\test` inside JSON caused `JSON.parse` syntax error. | Added `sanitizeJsonBackslashes()` with negative lookbehind. | `scripts/kiro_proxy_server.js:2276` |
| **BUG-02** | 2026-09 | Tool Translation | DeepSeek emitted tool calls without function wrapper or markdown fences. | Implemented Format 1b bare JSON tool parser. | `scripts/kiro_proxy_server.js:2380` |
| **BUG-03** | 2026-09 | Tool Translation | GLM models output `<read_file>path</read_file>` XML syntax. | Added Format 6b direct XML tag parser. | `scripts/kiro_proxy_server.js:2420` |
| **BUG-04** | 2026-10 | Tool Translation | LLMs used shell abbreviations (`ls`, `cat`, `grep`). | Implemented tool alias mapping table. | `scripts/kiro_proxy_server.js:2480` |
| **BUG-05** | 2026-10 | Bedrock Streaming | Tool cards leaked raw JSON or XML into user chat response. | Added text-stripping regexes before sending text delta frames. | `scripts/kiro_proxy_server.js:2520` |
| **BUG-06** | 2026-10 | Workflows | Kiro IDE entered validation loops on `/runtime/workflows/*`. | Suppressed workflow tools and stubbed endpoints with 404/501. | `scripts/kiro_proxy_server.js:4659, 5984` |
| **BUG-07** | 2026-10 | EventStream | AWS Bedrock rejected `toolUseEvent` with object `input`. | Forced `JSON.stringify(input)` in toolUse frame constructor. | `scripts/kiro_proxy_server.js:4905, 5218` |
