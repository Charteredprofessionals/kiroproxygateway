@echo off
:: ============================================================
::  verify_kiro_ide.bat — Verify Kiro IDE Integration v2.8.0
::  Checks if Kiro IDE can connect to the gateway
:: ============================================================

echo.
echo  ============================================================
echo    KiroProxy Gateway — Kiro IDE Integration Verification
echo  ============================================================
echo.

:: Check server
echo  [1] Checking server...
powershell -NoProfile -Command ^
  "try{$h=Invoke-RestMethod 'http://127.0.0.1:8084/health' -TimeoutSec 3;" ^
  "Write-Host ('    OK: Server v' + $h.version + ', ' + $h.modelCount + ' models') -ForegroundColor Green}catch{" ^
  "Write-Host '    FAIL: Server not running!' -ForegroundColor Red;" ^
  "Write-Host '    Run: start.bat to launch the server' -ForegroundColor Yellow;exit 1}"

:: Check environment variable
echo  [2] Checking CLOUD_CONFIG_ENDPOINT...
powershell -NoProfile -Command ^
  "$e=[System.Environment]::GetEnvironmentVariable('CLOUD_CONFIG_ENDPOINT','User');" ^
  "if($e -eq 'http://127.0.0.1:8084'){" ^
  "Write-Host ('    OK: ' + $e) -ForegroundColor Green}else{" ^
  "Write-Host '    FAIL: Not set or wrong value: '+$e -ForegroundColor Red;" ^
  "Write-Host '    Run: scripts\batch\install.bat to fix' -ForegroundColor Yellow;exit 1}"

:: Check extension patch
echo  [3] Checking extension patch...
cd /d "%~dp0..\.."
powershell -NoProfile -Command ^
  "$o=node scripts\patch_kiro_extension.js --check 2>&1|Out-String;" ^
  "if($o -match 'Patch 1.*APPLIED'){" ^
  "Write-Host '    OK: Extension patched' -ForegroundColor Green}else{" ^
  "Write-Host '    FAIL: Extension not patched' -ForegroundColor Red;" ^
  "Write-Host '    Run: node scripts\patch_kiro_extension.js' -ForegroundColor Yellow;exit 1}"

:: Test inference
echo  [4] Testing inference...
powershell -NoProfile -Command ^
  "try{$b='{\"model\":\"auto\",\"messages\":[{\"role\":\"user\",\"content\":\"respond: OK\"}]}';" ^
  "$r=Invoke-RestMethod 'http://127.0.0.1:8084/v1/chat/completions' -Method POST -Body $b -ContentType 'application/json' -TimeoutSec 30;" ^
  "Write-Host '    OK: Inference working' -ForegroundColor Green}catch{" ^
  "Write-Host '    WARN: Inference timeout (provider may be slow)' -ForegroundColor Yellow}"

:: Provider health
echo  [5] Provider health...
powershell -NoProfile -Command ^
  "$h=Invoke-RestMethod 'http://127.0.0.1:8084/health' -TimeoutSec 3;" ^
  "$props=@($h.providers.PSObject.Properties);" ^
  "$total=$props.Count;" ^
  "$healthy=@($props|Where-Object{$_.Value.status -eq 'healthy'}).Count;" ^
  "if($healthy -ge 3){" ^
  "Write-Host ('    OK: ' + $healthy + '/' + $total + ' providers healthy') -ForegroundColor Green}else{" ^
  "Write-Host ('    WARN: Only ' + $healthy + '/' + $total + ' providers healthy') -ForegroundColor Yellow}"

echo.
echo  ============================================================
echo    Result: All checks passed!
echo  ============================================================
echo.
echo   If Kiro IDE still doesn't work:
echo     1. Reload Window: Ctrl+Shift+P -> 'Developer: Reload Window'
echo     2. Or restart Kiro IDE completely
echo     3. Select a model (try 'auto' or 'kilo/gemma-4-26b')
echo     4. Send a test prompt
echo.
echo   Environment variables only load when app starts.
echo   You MUST restart Kiro IDE after running install.bat
echo.
pause

