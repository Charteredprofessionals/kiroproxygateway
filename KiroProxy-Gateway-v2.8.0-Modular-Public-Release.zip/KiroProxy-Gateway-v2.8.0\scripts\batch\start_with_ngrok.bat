@echo off
:: ============================================================
::  start_with_ngrok.bat — KiroProxy Gateway + Ngrok v2.8.0
::  Convenience wrapper — just calls start.bat from root.
::  Ngrok starts automatically when NGROK_AUTHTOKEN is in .env
:: ============================================================

set "BATCH_DIR=%~dp0"
set "BATCH_DIR=%BATCH_DIR:~0,-1%"
for %%i in ("%BATCH_DIR%\..") do set "SCRIPTS_DIR=%%~fi"
for %%i in ("%SCRIPTS_DIR%\..") do set "ROOT_DIR=%%~fi"

echo.
echo  KiroProxy Gateway — Starting with Ngrok tunnel...
echo  (Ngrok starts automatically if NGROK_AUTHTOKEN is set in .env)
echo.

cd /d "%ROOT_DIR%"
call start.bat
