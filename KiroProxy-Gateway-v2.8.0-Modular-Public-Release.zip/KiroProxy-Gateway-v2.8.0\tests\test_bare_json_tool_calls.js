/**
 * Unit Test: Bare / Unfenced JSON Tool Call Extraction & Windows Path Sanitization
 * Validates that KiroProxy detects and strips bare JSON tool calls (e.g. from Canvas Bridge or custom models)
 * including unescaped Windows backslashes in paths.
 */

const assert = require('assert');
const {
  extractToolMetadata,
  extractBalancedJson,
  extractToolArguments,
  extractToolCallsFromResponse,
  stripToolBlocksFromText
} = require('../src/translators/tool_extractor');
const { sanitizeJsonBackslashes } = require('../src/translators/sanitizer');

console.log('═══════════════════════════════════════════════════════');
console.log('   Bare JSON Tool Extraction & Windows Path Test Suite');
console.log('═══════════════════════════════════════════════════════\n');

let passed = 0;
let total = 0;

function runTest(name, fn) {
  total++;
  try {
    fn();
    console.log(`✅ [PASS] ${name}`);
    passed++;
  } catch (err) {
    console.error(`❌ [FAIL] ${name}: ${err.message}`);
  }
}

const registeredTools = [
  { type: 'function', function: { name: 'read_file', parameters: {} } },
  { type: 'function', function: { name: 'fs_write', parameters: {} } },
  { type: 'function', function: { name: 'execute_pwsh', parameters: {} } }
];

// Test 1: User Screenshot Exact Case (Bare JSON with Windows single backslashes)
runTest('Extracts bare JSON tool call with Windows single backslashes', () => {
  const input = '{"tool": "read_file", "arguments": {"path": "c:\\Users\\cscha\\Downloads\\ai-documentation-prompt-1.md"}}';
  const tools = extractToolCallsFromResponse(input, registeredTools);
  assert.strictEqual(tools.length, 1, 'Should extract exactly 1 tool call');
  assert.strictEqual(tools[0].name, 'read_file');
  assert.strictEqual(tools[0].args.path, 'c:\\Users\\cscha\\Downloads\\ai-documentation-prompt-1.md');
});

// Test 2: Bare JSON with "name" and "parameters"
runTest('Extracts bare JSON tool call with name and parameters keys', () => {
  const input = '{"name": "read_file", "parameters": {"path": "c:\\Projects\\code\\index.js"}}';
  const tools = extractToolCallsFromResponse(input, registeredTools);
  assert.strictEqual(tools.length, 1);
  assert.strictEqual(tools[0].name, 'read_file');
  assert.strictEqual(tools[0].args.path, 'c:\\Projects\\code\\index.js');
});

// Test 3: Bare JSON embedded in conversational text
runTest('Extracts bare JSON tool call embedded in conversational text', () => {
  const input = 'I will inspect that file for you now:\n\n{"tool": "read_file", "arguments": {"path": "d:\\sdlc_studio\\README.md"}}\n\nPlease wait.';
  const tools = extractToolCallsFromResponse(input, registeredTools);
  assert.strictEqual(tools.length, 1);
  assert.strictEqual(tools[0].name, 'read_file');
  assert.strictEqual(tools[0].args.path, 'd:\\sdlc_studio\\README.md');
});

// Test 4: Stripping bare JSON from assistant text prevents chat bubble leakage
runTest('Strips bare JSON tool block leaving only conversational text', () => {
  const input = 'I will inspect that file for you now:\n\n{"tool": "read_file", "arguments": {"path": "d:\\sdlc_studio\\README.md"}}\n\nPlease wait.';
  const stripped = stripToolBlocksFromText(input);
  assert.strictEqual(stripped, 'I will inspect that file for you now:\n\nPlease wait.');
});

// Test 5: Entire message as bare JSON strips to empty string
runTest('Strips standalone bare JSON to empty string', () => {
  const input = '{"tool": "read_file", "arguments": {"path": "c:\\Users\\cscha\\Downloads\\ai-documentation-prompt-1.md"}}';
  const stripped = stripToolBlocksFromText(input);
  assert.strictEqual(stripped, '');
});

// Test 6: Fenced JSON is not duplicated by bare JSON detector
runTest('Fenced JSON does not produce duplicate tool calls', () => {
  const input = '```json\n{"tool": "read_file", "arguments": {"path": "c:\\Users\\cscha\\test.txt"}}\n```';
  const tools = extractToolCallsFromResponse(input, registeredTools);
  assert.strictEqual(tools.length, 1, 'Should have exactly 1 tool call (no duplicates)');
});

// Test 7: Root level parameters (without "arguments" key)
runTest('Extracts bare JSON with parameters at root level', () => {
  const input = '{"tool": "read_file", "path": "c:\\Users\\cscha\\Downloads\\config.json"}';
  const tools = extractToolCallsFromResponse(input, registeredTools);
  assert.strictEqual(tools.length, 1);
  assert.strictEqual(tools[0].name, 'read_file');
  assert.strictEqual(tools[0].args.path, 'c:\\Users\\cscha\\Downloads\\config.json');
});

// Test 8: GLM Direct XML Tag (Image 5 exact output)
runTest('Extracts direct XML tag <read_file>path</read_file> (GLM format)', () => {
  const input = "I'll help you expand the prompt. <read_file> c:\\Users\\cscha\\Downloads\\ai-documentation-prompt-1.md </read_file>";
  const tools = extractToolCallsFromResponse(input, registeredTools);
  assert.strictEqual(tools.length, 1);
  assert.strictEqual(tools[0].name, 'read_file');
  assert.strictEqual(tools[0].args.path, 'c:\\Users\\cscha\\Downloads\\ai-documentation-prompt-1.md');
});

// Test 9: Strips direct XML tag leaving leading text
runTest('Strips direct XML tag from text leaving only assistant conversation', () => {
  const input = "I'll help you expand the prompt. <read_file> c:\\Users\\cscha\\Downloads\\ai-documentation-prompt-1.md </read_file>";
  const stripped = stripToolBlocksFromText(input);
  assert.strictEqual(stripped, "I'll help you expand the prompt.");
});

console.log(`\n═══════════════════════════════════════════════════════`);
console.log(`Summary: ${passed}/${total} tests passed (${Math.round((passed / total) * 100)}%)`);
console.log(`═══════════════════════════════════════════════════════\n`);

if (passed !== total) {
  process.exit(1);
}
