/**
 * src/providers/gemini_direct.js - Google Generative AI Direct API Provider Adapter
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const { executeWithRetry } = require('../resilience/retry_engine');
const { CIRCUIT_BREAKERS, isCircuitOpen, recordProviderSuccess, recordProviderFailure } = require('../resilience/circuit_breaker');
const { ProxyError } = require('../resilience/errors');
const { loadCustomConfig } = require('../config/index');
const { MODELS } = require('../config/catalog');
const { getProviderKey, rotateProviderKey, providerCurrentKeyIndex, providerKeyFailures } = require('../resilience/key_rotator');
const { translateToolsToUpstream } = require('../translators/tool_translator');
const { recordProviderCall } = require('../resilience/metrics');
const { extractToolCallsFromResponse, stripToolBlocksFromText } = require('../translators/tool_extractor');

async function callGeminiApi(messages, requestedModel, tools = [], otomodeContext = null) {
  if (!CIRCUIT_BREAKERS.gemini) {
    CIRCUIT_BREAKERS.gemini = { state: 'CLOSED', failures: 0, lastFailure: 0, resetTimeout: 30000 };
  }
  return executeWithRetry(async () => {
    if (isCircuitOpen('gemini')) {
      const err = new Error('Gemini circuit breaker is open');
      err.code = 'CIRCUIT_OPEN';
      throw err;
    }

    const cfg = loadCustomConfig();
    const geminiKeys = cfg.geminiApiKeys || [];

    if (!geminiKeys || geminiKeys.length === 0) {
      const err = new Error('No Gemini API keys configured');
      err.code = 'MISSING_API_KEY';
      throw err;
    }

    const currentKey = getProviderKey('gemini', cfg);
    if (!currentKey) {
      const err = new Error('No valid Gemini API key available');
      err.code = 'MISSING_API_KEY';
      throw err;
    }

    const currentIdx = providerCurrentKeyIndex.gemini;
    console.log(`[KiroProxy] Using Gemini API key ${currentIdx + 1}/${geminiKeys.length} for ${requestedModel}`);

    const start = Date.now();

    let modelSlug = requestedModel;

    const foundModel = MODELS.models.find(m => m.modelId === requestedModel);
    if (foundModel && foundModel.upstreamSlug) {
      modelSlug = foundModel.upstreamSlug;
      console.log(`[KiroProxy] Using upstream slug: ${modelSlug}`);
    } else {
      if (modelSlug.startsWith('gemini-')) {
        modelSlug = modelSlug.replace('gemini-', '');
      }
    }

    if (modelSlug.startsWith('models/')) {
      modelSlug = modelSlug.replace(/^models\//, '');
    }

    console.log(`[KiroProxy] Gemini API will call: /v1beta/models/${modelSlug}:generateContent`);

    return new Promise((resolve, reject) => {
      const useHeaderAuth = currentKey.startsWith('AQ.');

      const systemTexts = messages
        .filter(m => m.role === 'system' && m.content)
        .map(m => m.content);
      const nonSystemMessages = messages.filter(m => m.role !== 'system');

      const geminiMessages = [];
      for (const m of nonSystemMessages) {
        const gRole = m.role === 'assistant' ? 'model' : 'user';
        const textContent = typeof m.content === 'string' ? m.content : JSON.stringify(m.content || '');
        if (!textContent) continue;
        if (geminiMessages.length > 0 && geminiMessages[geminiMessages.length - 1].role === gRole) {
          geminiMessages[geminiMessages.length - 1].parts[0].text += '\n\n' + textContent;
        } else {
          geminiMessages.push({
            role: gRole,
            parts: [{ text: textContent }]
          });
        }
      }
      if (geminiMessages.length === 0) {
        geminiMessages.push({ role: 'user', parts: [{ text: 'Hello' }] });
      }

      const geminiTools = tools && tools.length > 0
        ? translateToolsToUpstream(tools, 'gemini')
        : undefined;

      const requestBody = {
        contents: geminiMessages,
        generationConfig: {
          maxOutputTokens: 8192,
          temperature: 0.7
        }
      };

      if (systemTexts.length > 0) {
        requestBody.systemInstruction = {
          parts: [{ text: systemTexts.join('\n\n') }]
        };
      }

      if (geminiTools && geminiTools.length > 0) {
        requestBody.tools = [{ functionDeclarations: geminiTools }];
      }

      const postData = JSON.stringify(requestBody);

      const reqOptions = {
        hostname: 'generativelanguage.googleapis.com',
        port: 443,
        path: useHeaderAuth
          ? `/v1beta/models/${modelSlug}:generateContent`
          : `/v1beta/models/${modelSlug}:generateContent?key=${currentKey}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'User-Agent': 'Kiro-Integration/2.7.0'
        },
        timeout: 60000
      };

      if (useHeaderAuth) {
        reqOptions.headers['X-goog-api-key'] = currentKey;
      }

      const req = https.request(reqOptions, (res) => {
        const latency = Date.now() - start;

        if (res.statusCode === 429 || res.statusCode === 401 || res.statusCode === 403) {
          recordProviderFailure('gemini');
          providerKeyFailures.gemini[currentIdx] = (providerKeyFailures.gemini[currentIdx] || 0) + 1;

          if (rotateProviderKey('gemini', cfg)) {
            const err = new Error(`Gemini API (${res.statusCode}): Rate limit or auth error, rotated to next key`);
            err.code = 'RATE_LIMIT';
            err.shouldRetry = true;
            return reject(err);
          }
        }

        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode !== 200) {
            if (geminiTools && geminiTools.length > 0 && (res.statusCode === 400 || res.statusCode === 422)) {
              console.log(`[KiroProxy] 🔄 Gemini model '${modelSlug}' rejected functionDeclarations (${res.statusCode}); retrying with prompt-based tool guide...`);
              callGeminiApi(messages, requestedModel, [], otomodeContext).then(resolve).catch(reject);
              return;
            }
            if (otomodeContext && otomodeContext._fallbackList.length > 0 && res.statusCode >= 400) {
              const oldModel = otomodeContext._activeModel;
              const nextModel = otomodeContext._fallbackList.shift();
              if (nextModel) {
                otomodeContext._activeModel = nextModel;
                const delay = 250 + Math.random() * 500;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName}) from ${oldModel} → ${nextModel} due to HTTP ${res.statusCode} (${otomodeContext._fallbackList.length} free models remaining)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callGeminiApi(messages, nextModel, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }
            }
            recordProviderFailure('gemini');
            const err = new Error(`Gemini API returned status ${res.statusCode}: ${data.slice(0, 150)}`);
            err.code = 'HTTP_ERROR';
            return reject(err);
          }

          try {
            const parsed = JSON.parse(data);
            const parts = parsed.candidates?.[0]?.content?.parts || [];
            let text = '';
            const nativeToolCalls = [];

            for (const part of parts) {
              if (part.text && !part.thought) {
                text += part.text;
              }
              if (part.functionCall && part.functionCall.name) {
                nativeToolCalls.push({
                  name: part.functionCall.name,
                  args: part.functionCall.args || {}
                });
              }
            }

            const textToolCalls = text ? extractToolCallsFromResponse(text, tools) : [];
            const toolCalls = [...nativeToolCalls, ...textToolCalls];

            const hasValidContent = Boolean(((text && text.trim().length > 0) || (toolCalls && toolCalls.length > 0)) && !parsed.error);

            if (!hasValidContent) {
              console.warn(`[KiroProxy] ⚠️ Gemini API returned HTTP 200 with empty completion (0 text, 0 tools) for model '${requestedModel}'`);
              recordProviderFailure('gemini');
              recordProviderCall('gemini', false, latency);

              if (otomodeContext && otomodeContext._fallbackList && otomodeContext._fallbackList.length > 0) {
                const oldModel = otomodeContext._activeModel || requestedModel;
                const nextModel = otomodeContext._fallbackList.shift();
                otomodeContext._activeModel = nextModel;
                const delay = 50;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName || 'Gemini'}) from ${oldModel} → ${nextModel} due to EMPTY_RESPONSE (HTTP 200)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callGeminiApi(messages, nextModel, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }

              if (otomodeContext && (!otomodeContext._fallbackList || otomodeContext._fallbackList.length === 0)) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName || 'Gemini'}`);
              }

              const emptyErr = new ProxyError(
                'EMPTY_RESPONSE',
                'Empty response from Gemini API (0 text and 0 tools)',
                'Model returned empty response or context saturated'
              );
              emptyErr.code = 'EMPTY_RESPONSE';
              return reject(emptyErr);
            }

            recordProviderSuccess('gemini');
            recordProviderCall('gemini', true, latency);
            providerKeyFailures.gemini[currentIdx] = 0;

            const cleanText = toolCalls.length > 0
              ? stripToolBlocksFromText(text)
              : text;

            resolve({
              id: 'gemini-' + Date.now(),
              object: 'chat.completion',
              created: Math.floor(Date.now() / 1000),
              model: requestedModel,
              choices: [{
                index: 0,
                message: {
                  role: 'assistant',
                  content: cleanText
                },
                finish_reason: toolCalls.length > 0 ? 'tool_calls' : 'stop'
              }],
              usage: {
                prompt_tokens: Math.round(postData.length / 4),
                completion_tokens: Math.round(text.length / 4),
                total_tokens: Math.round((postData.length + text.length) / 4)
              },
              _kiro: {
                text: cleanText,
                toolCalls: toolCalls,
                stopReason: toolCalls.length > 0 ? 'TOOL_USE' : 'END_TURN'
              }
            });
          } catch (e) {
            recordProviderFailure('gemini');
            recordProviderCall('gemini', false, latency);
            reject(new Error(`Failed to parse Gemini response: ${e.message}`));
          }
        });
      });

      req.on('error', (e) => {
        recordProviderFailure('gemini');
        recordProviderCall('gemini', false, Date.now() - start);
        reject(new Error(`Gemini API request failed: ${e.message}`));
      });

      req.on('timeout', () => {
        req.destroy();
        recordProviderFailure('gemini');
        reject(new Error('Gemini API request timeout'));
      });

      req.write(postData);
      req.end();
    });
  }, 'gemini', otomodeContext ? 1 : 3);
}

module.exports = {
  callGeminiApi
};
