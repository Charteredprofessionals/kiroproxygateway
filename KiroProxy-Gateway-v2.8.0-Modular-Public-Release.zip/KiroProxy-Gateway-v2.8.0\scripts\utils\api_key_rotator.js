/**
 * api_key_rotator.js - Dynamic API key rotation and management
 * Part of Phase 1 improvements for Kiro Proxy Gateway
 * 
 * Addresses Edge Cases:
 * - EC-2.1: API key exhaustion (rate limits)
 * - EC-2.2: Invalid/expired API keys
 * - EC-2.3: No fallback when key fails
 */

'use strict';

const EventEmitter = require('events');
const { validateApiKey, ValidationError } = require('./validators');

class ApiKeyRotator extends EventEmitter {
  constructor(provider, options = {}) {
    super();
    
    this.provider = provider;
    this.keys = [];
    this.currentIndex = 0;
    this.keyStats = new Map();
    
    this.options = {
      rotationStrategy: options.rotationStrategy || 'round-robin', // round-robin, least-used, random
      maxFailures: options.maxFailures || 3,
      cooldownPeriod: options.cooldownPeriod || 60000, // 1 minute
      healthCheckInterval: options.healthCheckInterval || 300000, // 5 minutes
      ...options
    };

    if (this.options.healthCheckInterval > 0) {
      this.healthCheckTimer = setInterval(
        () => this._runHealthChecks(),
        this.options.healthCheckInterval
      );
    }
  }

  /**
   * Adds an API key to the rotation pool
   * @param {string} key - API key to add
   * @param {object} metadata - Optional metadata (name, tier, etc.)
   */
  addKey(key, metadata = {}) {
    try {
      validateApiKey(key, this.provider);
    } catch (err) {
      this.emit('validation-error', { key: this._sanitizeKey(key), error: err.message });
      throw err;
    }

    const keyObj = {
      key,
      metadata,
      addedAt: Date.now(),
      status: 'active', // active, exhausted, failed, cooldown
      failureCount: 0,
      successCount: 0,
      lastUsed: 0,
      lastFailure: 0,
      cooldownUntil: 0,
      usageCount: 0
    };

    this.keys.push(keyObj);
    this.keyStats.set(key, keyObj);
    this.emit('key-added', { provider: this.provider, count: this.keys.length });

    return keyObj;
  }

  /**
   * Adds multiple API keys at once
   * @param {Array<string|object>} keys - Array of keys or {key, metadata} objects
   */
  addKeys(keys) {
    const added = [];
    const failed = [];

    for (const item of keys) {
      try {
        const key = typeof item === 'string' ? item : item.key;
        const metadata = typeof item === 'object' ? item.metadata : {};
        added.push(this.addKey(key, metadata));
      } catch (err) {
        failed.push({ item, error: err.message });
      }
    }

    return { added, failed };
  }

  /**
   * Gets the next available API key based on rotation strategy
   * @returns {string|null} API key or null if none available
   */
  getNextKey() {
    const availableKeys = this._getAvailableKeys();
    
    if (availableKeys.length === 0) {
      this.emit('no-keys-available', { provider: this.provider });
      return null;
    }

    let selectedKey;
    
    switch (this.options.rotationStrategy) {
      case 'least-used':
        selectedKey = this._getLeastUsedKey(availableKeys);
        break;
      case 'random':
        selectedKey = this._getRandomKey(availableKeys);
        break;
      case 'round-robin':
      default:
        selectedKey = this._getRoundRobinKey(availableKeys);
        break;
    }

    if (selectedKey) {
      selectedKey.lastUsed = Date.now();
      selectedKey.usageCount++;
      this.emit('key-selected', { 
        provider: this.provider, 
        strategy: this.options.rotationStrategy,
        usageCount: selectedKey.usageCount
      });
    }

    return selectedKey ? selectedKey.key : null;
  }

  /**
   * Records a successful API call
   * @param {string} key - API key that succeeded
   */
  recordSuccess(key) {
    const keyObj = this.keyStats.get(key);
    if (!keyObj) return;

    keyObj.successCount++;
    keyObj.failureCount = 0; // Reset failure count on success
    keyObj.status = 'active';
    
    this.emit('key-success', { 
      provider: this.provider, 
      successCount: keyObj.successCount 
    });
  }

  /**
   * Records a failed API call
   * @param {string} key - API key that failed
   * @param {string} reason - Failure reason (rate-limit, invalid, error)
   */
  recordFailure(key, reason = 'error') {
    const keyObj = this.keyStats.get(key);
    if (!keyObj) return;

    keyObj.failureCount++;
    keyObj.lastFailure = Date.now();

    // Handle different failure types
    if (reason === 'rate-limit' || reason === 'exhausted') {
      keyObj.status = 'exhausted';
      keyObj.cooldownUntil = Date.now() + this.options.cooldownPeriod;
      this.emit('key-exhausted', { 
        provider: this.provider, 
        cooldownUntil: keyObj.cooldownUntil 
      });
    } else if (reason === 'invalid' || reason === 'unauthorized') {
      keyObj.status = 'failed';
      this.emit('key-invalid', { provider: this.provider });
    } else if (keyObj.failureCount >= this.options.maxFailures) {
      keyObj.status = 'cooldown';
      keyObj.cooldownUntil = Date.now() + this.options.cooldownPeriod;
      this.emit('key-cooldown', { 
        provider: this.provider, 
        failures: keyObj.failureCount 
      });
    }

    this.emit('key-failure', { 
      provider: this.provider, 
      reason, 
      failureCount: keyObj.failureCount 
    });
  }

  /**
   * Gets statistics for all keys
   * @returns {object} Key statistics
   */
  getStats() {
    const stats = {
      provider: this.provider,
      totalKeys: this.keys.length,
      active: 0,
      exhausted: 0,
      failed: 0,
      cooldown: 0,
      totalUsage: 0,
      totalSuccesses: 0,
      totalFailures: 0
    };

    for (const keyObj of this.keys) {
      stats[keyObj.status]++;
      stats.totalUsage += keyObj.usageCount;
      stats.totalSuccesses += keyObj.successCount;
      stats.totalFailures += keyObj.failureCount;
    }

    return stats;
  }

  /**
   * Resets a key's status (useful for manual intervention)
   * @param {string} key - API key to reset
   */
  resetKey(key) {
    const keyObj = this.keyStats.get(key);
    if (!keyObj) return false;

    keyObj.status = 'active';
    keyObj.failureCount = 0;
    keyObj.cooldownUntil = 0;
    this.emit('key-reset', { provider: this.provider });
    
    return true;
  }

  /**
   * Removes a key from rotation
   * @param {string} key - API key to remove
   */
  removeKey(key) {
    const index = this.keys.findIndex(k => k.key === key);
    if (index === -1) return false;

    this.keys.splice(index, 1);
    this.keyStats.delete(key);
    this.emit('key-removed', { provider: this.provider, remaining: this.keys.length });
    
    return true;
  }

  /**
   * Shuts down the rotator
   */
  shutdown() {
    if (this.healthCheckTimer) {
      clearInterval(this.healthCheckTimer);
    }
    this.emit('shutdown', { provider: this.provider });
  }

  // ── Private Methods ──────────────────────────────────────────────────────────

  _getAvailableKeys() {
    const now = Date.now();
    return this.keys.filter(keyObj => {
      if (keyObj.status === 'failed') return false;
      if (keyObj.status === 'cooldown' && keyObj.cooldownUntil > now) return false;
      if (keyObj.status === 'exhausted' && keyObj.cooldownUntil > now) return false;
      
      // Restore keys from cooldown
      if (keyObj.cooldownUntil > 0 && keyObj.cooldownUntil <= now) {
        keyObj.status = 'active';
        keyObj.cooldownUntil = 0;
      }
      
      return true;
    });
  }

  _getRoundRobinKey(availableKeys) {
    if (availableKeys.length === 0) return null;
    
    this.currentIndex = (this.currentIndex + 1) % availableKeys.length;
    return availableKeys[this.currentIndex];
  }

  _getLeastUsedKey(availableKeys) {
    if (availableKeys.length === 0) return null;
    
    return availableKeys.reduce((least, current) => {
      return current.usageCount < least.usageCount ? current : least;
    });
  }

  _getRandomKey(availableKeys) {
    if (availableKeys.length === 0) return null;
    
    const randomIndex = Math.floor(Math.random() * availableKeys.length);
    return availableKeys[randomIndex];
  }

  async _runHealthChecks() {
    const now = Date.now();
    
    for (const keyObj of this.keys) {
      // Auto-recover keys in cooldown
      if (keyObj.cooldownUntil > 0 && keyObj.cooldownUntil <= now) {
        keyObj.status = 'active';
        keyObj.cooldownUntil = 0;
        keyObj.failureCount = 0;
        this.emit('key-recovered', { provider: this.provider });
      }
    }
  }

  _sanitizeKey(key) {
    if (!key || typeof key !== 'string') return '[INVALID]';
    if (key.length <= 8) return '[TOO_SHORT]';
    return key.substring(0, 4) + '...' + key.substring(key.length - 4);
  }
}

module.exports = ApiKeyRotator;
