/**
 * request_queue.js - Priority queue manager for request handling
 * Part of Phase 2 improvements for Kiro Proxy Gateway
 * 
 * Addresses Edge Cases:
 * - EC-3.1: Queue overflow under load
 * - EC-3.2: Request timeout in queue
 * - EC-3.3: Priority request starvation
 */

'use strict';

const EventEmitter = require('events');

class RequestQueue extends EventEmitter {
  constructor(options = {}) {
    super();
    
    this.maxSize = options.maxSize || 1000;
    this.timeout = options.timeout || 300000; // 5 minutes default
    this.concurrency = options.concurrency || 10;
    
    this.queues = {
      high: [],
      normal: [],
      low: []
    };
    
    this.processing = 0;
    this.stats = {
      enqueued: 0,
      processed: 0,
      timedOut: 0,
      rejected: 0,
      avgWaitTime: 0,
      totalWaitTime: 0
    };
    
    this.cleanupInterval = setInterval(() => this._cleanup(), 30000);
  }

  /**
   * Enqueues a request with priority
   * @param {Function} handler - Async function to execute
   * @param {object} options - Priority, timeout, metadata
   * @returns {Promise} Resolves with handler result or rejects
   */
  async enqueue(handler, options = {}) {
    const priority = options.priority || 'normal';
    const timeout = options.timeout || this.timeout;
    const metadata = options.metadata || {};

    // Check queue capacity
    const totalSize = this.size();
    if (totalSize >= this.maxSize) {
      this.stats.rejected++;
      this.emit('overflow', { size: totalSize, maxSize: this.maxSize, metadata });
      throw new Error(`Queue overflow: ${totalSize}/${this.maxSize} requests pending`);
    }

    // Create request wrapper
    const request = {
      id: this._generateId(),
      handler,
      priority,
      timeout,
      metadata,
      enqueuedAt: Date.now(),
      timeoutHandle: null,
      promise: null
    };

    // Create promise that resolves/rejects based on execution
    request.promise = new Promise((resolve, reject) => {
      request.resolve = resolve;
      request.reject = reject;

      // Set timeout
      request.timeoutHandle = setTimeout(() => {
        this._timeoutRequest(request);
      }, timeout);
    });

    // Add to appropriate queue
    this.queues[priority].push(request);
    this.stats.enqueued++;
    this.emit('enqueued', { id: request.id, priority, queueSize: this.size() });

    // Try to process immediately
    this._processNext();

    return request.promise;
  }

  /**
   * Gets total queue size across all priorities
   * @returns {number} Total pending requests
   */
  size() {
    return this.queues.high.length + this.queues.normal.length + this.queues.low.length;
  }

  /**
   * Gets queue statistics
   * @returns {object} Stats object
   */
  getStats() {
    return {
      ...this.stats,
      queueSizes: {
        high: this.queues.high.length,
        normal: this.queues.normal.length,
        low: this.queues.low.length,
        total: this.size()
      },
      processing: this.processing,
      concurrency: this.concurrency
    };
  }

  /**
   * Clears all queues
   */
  clear() {
    for (const priority in this.queues) {
      this.queues[priority].forEach(req => {
        clearTimeout(req.timeoutHandle);
        req.reject(new Error('Queue cleared'));
      });
      this.queues[priority] = [];
    }
    this.emit('cleared');
  }

  /**
   * Gracefully shuts down the queue
   */
  async shutdown() {
    clearInterval(this.cleanupInterval);
    
    // Wait for in-flight requests
    const waitStart = Date.now();
    while (this.processing > 0 && Date.now() - waitStart < 30000) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    this.clear();
    this.emit('shutdown');
  }

  // ── Private Methods ──────────────────────────────────────────────────────────

  _processNext() {
    // Respect concurrency limit
    if (this.processing >= this.concurrency) {
      return;
    }

    // Get next request (priority order: high -> normal -> low)
    const request = this._dequeue();
    if (!request) {
      return;
    }

    this.processing++;
    this.emit('processing', { id: request.id, processing: this.processing });

    // Execute handler
    this._executeRequest(request)
      .then(result => {
        this._completeRequest(request, result);
      })
      .catch(error => {
        this._failRequest(request, error);
      })
      .finally(() => {
        this.processing--;
        this._processNext(); // Process next item
      });
  }

  _dequeue() {
    // Priority order: high -> normal -> low
    if (this.queues.high.length > 0) {
      return this.queues.high.shift();
    }
    if (this.queues.normal.length > 0) {
      return this.queues.normal.shift();
    }
    if (this.queues.low.length > 0) {
      return this.queues.low.shift();
    }
    return null;
  }

  async _executeRequest(request) {
    const startTime = Date.now();
    try {
      const result = await request.handler();
      const duration = Date.now() - startTime;
      this.emit('executed', { id: request.id, duration, metadata: request.metadata });
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.emit('error', { id: request.id, duration, error: error.message, metadata: request.metadata });
      throw error;
    }
  }

  _completeRequest(request, result) {
    clearTimeout(request.timeoutHandle);
    
    const waitTime = Date.now() - request.enqueuedAt;
    this.stats.processed++;
    this.stats.totalWaitTime += waitTime;
    this.stats.avgWaitTime = this.stats.totalWaitTime / this.stats.processed;

    request.resolve(result);
    this.emit('completed', { 
      id: request.id, 
      waitTime, 
      priority: request.priority,
      metadata: request.metadata 
    });
  }

  _failRequest(request, error) {
    clearTimeout(request.timeoutHandle);
    request.reject(error);
    this.emit('failed', { id: request.id, error: error.message, metadata: request.metadata });
  }

  _timeoutRequest(request) {
    // Remove from queue if still waiting
    for (const priority in this.queues) {
      const index = this.queues[priority].indexOf(request);
      if (index !== -1) {
        this.queues[priority].splice(index, 1);
        break;
      }
    }

    this.stats.timedOut++;
    const error = new Error(`Request timeout after ${request.timeout}ms`);
    error.code = 'REQUEST_TIMEOUT';
    request.reject(error);
    
    this.emit('timeout', { 
      id: request.id, 
      timeout: request.timeout,
      waitTime: Date.now() - request.enqueuedAt,
      metadata: request.metadata 
    });
  }

  _cleanup() {
    // Remove stale requests (shouldn't happen with proper timeout handling)
    const now = Date.now();
    let cleaned = 0;

    for (const priority in this.queues) {
      const stale = this.queues[priority].filter(req => {
        return now - req.enqueuedAt > req.timeout;
      });
      
      stale.forEach(req => this._timeoutRequest(req));
      cleaned += stale.length;
    }

    if (cleaned > 0) {
      this.emit('cleanup', { cleaned });
    }
  }

  _generateId() {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

module.exports = RequestQueue;
