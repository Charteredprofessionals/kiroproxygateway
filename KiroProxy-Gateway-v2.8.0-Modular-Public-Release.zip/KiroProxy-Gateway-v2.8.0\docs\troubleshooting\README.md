# Troubleshooting Documentation — KiroProxy Gateway v2.8.0

The canonical, unified troubleshooting manual for KiroProxy Gateway is located at:
👉 **[`docs/troubleshooting.md`](file:///d:/sdlc_studio/projects/kiro-integration/docs/troubleshooting.md)**

---

## What the Canonical Guide Covers
- **Symptom Diagnostic Matrix:** Tool call text leakage, Canvas Bridge empty responses, model selector visibility, EventStream CRC32 prelude errors, rate limit / key rotation failures, and 503 circuit breaker trips.
- **Log Inspection & Signatures:** How to inspect proxy stdout, `logs/kiro_proxy.log`, and Kiro IDE DevTools console.
- **Local Reproduction & Rollback:** Commands to reproduce issues locally and roll back extension patches via `npm run patch:restore`.

---

## Historical Incident Reports
Point-in-time diagnosis logs and historical post-mortems from v2.4 through v2.7 have been archived in:
👉 **[`docs/archive/incident-reports/`](file:///d:/sdlc_studio/projects/kiro-integration/docs/archive/incident-reports/)**