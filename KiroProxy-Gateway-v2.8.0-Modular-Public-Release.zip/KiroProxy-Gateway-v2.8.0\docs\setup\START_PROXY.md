# 🚀 How to Start Kiro Proxy Server

## Problem Identified
The Kiro Proxy Server is **NOT RUNNING** on port 8084, which is why Kilo Gateway and all other providers are failing.

## Quick Start (Choose One)

### Option 1: Start with npm (Recommended)
```powershell
cd d:\sdlc_studio\projects\kiro-integration
npm start
```

### Option 2: Start directly with node
```powershell
cd d:\sdlc_studio\projects\kiro-integration
node scripts/kiro_proxy_server.js
```

### Option 3: Start with launch script (if exists)
```powershell
cd d:\sdlc_studio\projects\kiro-integration
.\launch.bat
```

## What You Should See

When successfully started, you'll see:
```
==========================================================
  🚀 Kiro Native Proxy Gateway v2.7.0
==========================================================
  Running at http://127.0.0.1:8084
  ✅ P0/P1 Fixes: Size limits, timeouts, race conditions
  ✅ Queue Management: Max 100, auto-cleanup
  ✅ Circuit Breaker: HALF_OPEN protection, state logging
  ✅ Rate Limiting: 120 polls/min
==========================================================
[HealthCheck] Running provider health checks...
[HealthCheck] ✅ kilo: healthy (234ms)
[HealthCheck] ✅ cline: healthy (456ms)
[HealthCheck] ✅ openrouter: healthy (678ms)
[HealthCheck] Summary: 6/6 providers healthy
[KiroProxy] Model catalog ready: 479 total models available
```

## Troubleshooting

### Port 8084 Already in Use
If you see: `[ERROR] Port 8084 is in use`

```powershell
# Find what's using port 8084
Get-Process -Id (Get-NetTCPConnection -LocalPort 8084).OwningProcess

# Kill it
taskkill /F /PID <process_id>

# Or kill all node processes
taskkill /F /IM node.exe
```

### Missing Dependencies
If you see module errors:
```powershell
npm install
```

### Configuration Issues
If it starts but providers fail:
1. Check `.env` file has proper values
2. Verify `scripts/kiro_ai_config.json` is configured
3. See `SECURITY_FIXES_REQUIRED.md` for credential setup

## Verify It's Running

```powershell
# Test the health endpoint
Invoke-WebRequest -Uri "http://localhost:8084/health" -UseBasicParsing | Select-Object -ExpandProperty Content | ConvertFrom-Json

# Test the status endpoint
Invoke-WebRequest -Uri "http://localhost:8084/status" -UseBasicParsing | Select-Object -ExpandProperty Content | ConvertFrom-Json
```

## Keep It Running

### Option 1: Run in background (PowerShell)
```powershell
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'd:\sdlc_studio\projects\kiro-integration'; npm start"
```

### Option 2: Use PM2 (if installed)
```powershell
npm install -g pm2
pm2 start scripts/kiro_proxy_server.js --name kiro-proxy
pm2 save
pm2 startup
```

### Option 3: Run as Windows Service
See `docs/guides/WINDOWS_SERVICE_SETUP.md` (if exists)

## Stop the Server

Press `Ctrl+C` in the terminal where it's running, or:
```powershell
# Find and kill the process
taskkill /F /IM node.exe /FI "WINDOWTITLE eq *kiro_proxy*"
```

## Next Steps

Once the server is running:
1. ✅ Verify health: http://localhost:8084/health
2. ✅ Check models: http://localhost:8084/v1/models
3. ✅ Configure Kiro IDE to use: http://localhost:8084
4. ✅ Test with a simple prompt

## Auto-Start on Boot (Optional)

Create a scheduled task:
```powershell
$Action = New-ScheduledTaskAction -Execute "node" -Argument "d:\sdlc_studio\projects\kiro-integration\scripts\kiro_proxy_server.js"
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Principal = New-ScheduledTaskPrincipal -UserId "$env:USERNAME" -LogonType Interactive
Register-ScheduledTask -TaskName "KiroProxyServer" -Action $Action -Trigger $Trigger -Principal $Principal -Description "Kiro AI Gateway Proxy"
```
