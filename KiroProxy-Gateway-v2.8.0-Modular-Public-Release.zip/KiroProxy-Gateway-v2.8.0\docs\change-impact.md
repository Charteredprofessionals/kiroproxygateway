# Change Impact & Blast Radius Matrix — KiroProxy Gateway

This document is the mandatory pre-flight checklist for modifying KiroProxy Gateway. Every change area maps to its upstream coupling, downstream blast radius, and required verification tests.

## Change Impact Quick Reference

| Change Area | Blast Radius | Files to Re-verify | Tests to Run | Classification |
| :--- | :--- | :--- | :--- | :--- |
| **EventStream Framing** (`createEventStreamFrame`) | **CRITICAL**: Breaks all streaming in Kiro IDE. CRC32 mismatch causes immediate IDE connection abort. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `node tests/test_tool_translation_layer.js`<br>`node tests/test_gateway.js` | `[FACT]` |
| **Tool Translation & Parsing** (`extractToolCallsFromResponse`) | **HIGH**: Tools not detected, raw JSON/XML leaks into user chat bubbles, or tools fail to execute. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `node tests/test_bare_json_tool_calls.js`<br>`node tests/test_tool_translation_layer.js` | `[FACT]` |
| **Tool Block Stripping** (`stripToolBlocksFromText`) | **MEDIUM**: Assistant bubble renders raw tool invocation text alongside the interactive tool card. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `node tests/test_bare_json_tool_calls.js` | `[FACT]` |
| **Tool Name Aliases** (lines 4810, 5030, 5345) | **HIGH**: Shell commands (`ls`, `dir`, `cat`) or agent calls rejected by Kiro's strict Zod validators. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `node tests/test_bare_json_tool_calls.js`<br>`node tests/test_kiro_tool_events.js` | `[FACT]` |
| **Provider Fallback Hierarchy** (`dispatchInference`) | **HIGH**: Broken failover order, API key exhaustion, or non-free models invoiced to user. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/utils/global_automode_interceptor.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js) | `node tests/test_kilo_and_custom_providers.js`<br>`node tests/test_provider_inference.js` | `[FACT]` |
| **Dynamic Free Model Discovery** (`autoPopulateFreeModels`) | **MEDIUM**: Model selector dropdown in Kiro IDE becomes empty or displays paid models. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `curl http://127.0.0.1:8084/listAvailableModels`<br>`node tests/test_gateway.js` | `[FACT]` |
| **Extension Patcher** (`patch_kiro_extension.js`) | **CRITICAL**: Kiro IDE fails to launch, crashes agent extension, or locks into offline mode. | [`scripts/patch_kiro_extension.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js) | `npm run patch:check`<br>`node scripts/utils/verify_proxy_mode.js` | `[FACT]` |
| **Gemini Canvas Bridge** (`geminiQueue`, `/poll`) | **HIGH**: Browser userscript stalls, memory leaks in unpolled cancellations, or empty completions. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), `canvas_bridge_dashboard.html` | `node tests/test_canvas_history_preservation.js`<br>`curl http://127.0.0.1:8084/poll` | `[FACT]` |
| **Workflow Compatibility Stubs** (`/runtime/workflows/*`) | **MEDIUM**: IDE hangs in infinite workflow validation loop instead of falling back to direct execution. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `node tests/test_gateway.js` | `[FACT]` |
| **Context Pruning** (`pruneMessages`, `prunePayloadForCanvas`) | **HIGH**: Multi-turn agent loses memory of inspected files; context window truncation errors. | [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | `node tests/test_real_world_agent_scenario.js` | `[FACT]` |

---

## Detailed Blast Radius & Dependency Coupling

### 1. Modifying `createEventStreamFrame` ([`kiro_proxy_server.js:2077-2116`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L2077-L2116))
* **If you change this, also check/update**:
  - `createConverseEvent()` ([`kiro_proxy_server.js:2121`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L2121))
  - `handleConverseStreaming()` streaming frames ([`kiro_proxy_server.js:4768, 4905, 4964`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L4768))
* **Coupling Rules**:
  - The 12-byte prelude layout is immutable: `[TotalLength(4B) | HeadersLength(4B) | PreludeCRC(4B)]`.
  - Prelude CRC32 covers bytes 0–7; Message CRC32 covers the entire frame except the trailing 4 bytes.
  - Header value type `7` (String) is required for `:event-type`, `:content-type`, and `:message-type`.
* **Tests to Run**: `node tests/test_tool_translation_layer.js` (Test 7 verifies EventStream string contract).

---

### 2. Modifying `extractToolCallsFromResponse` ([`kiro_proxy_server.js:2349-2700`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L2349-L2700))
* **If you change this, also check/update**:
  - `sanitizeJsonBackslashes()` ([`kiro_proxy_server.js:2276`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L2276))
  - `stripToolBlocksFromText()` ([`kiro_proxy_server.js:2738`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L2738))
  - `handleBridgeDone()` ([`kiro_proxy_server.js:5413`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L5413))
  - Safety fallback in `handleConverseStreaming()` ([`kiro_proxy_server.js:4700`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L4700))
* **Coupling Rules**:
  - Must support 13 distinct tool formats: Fenced JSON (1), Bare JSON (1b), Claude XML (2), Anthropic XML (3), Kiro Native `<|tool_call>` (4), Qwen `<tool_call>` (4b), Dots `<dots_function_call>` (6), Direct XML `<read_file>` (6b), Function calls wrapper (7), Anthropic `<input>` (8), OpenAI JSON (9), Parameters only (10), Antml (11), and Function syntax (12).
  - Any new tool syntax MUST be mirrored in `stripToolBlocksFromText()` to prevent chat leakage.
  - Windows file paths with single backslashes (`\`) MUST be sanitized before calling `JSON.parse()`.
* **Tests to Run**: `node tests/test_bare_json_tool_calls.js` (9/9 pass) and `node tests/test_tool_translation_layer.js`.

---

### 3. Modifying `dispatchInference` ([`kiro_proxy_server.js:4114-4294`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L4114-L4294))
* **If you change this, also check/update**:
  - `runProviderOtomode()` ([`kiro_proxy_server.js:4050`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L4050))
  - `buildOtomodeFallbackList()` ([`kiro_proxy_server.js:1252`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L1252))
  - `CIRCUIT_BREAKERS` ([`kiro_proxy_server.js:306`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js#L306))
  - `global_automode_interceptor.js` `PROVIDER_PRIORITY_ORDER` ([`global_automode_interceptor.js:37`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/utils/global_automode_interceptor.js#L37))
* **Coupling Rules**:
  - Global Automode must evaluate Tier 1 (Kilo) → Tier 2 (Cline) → Tier 3 (OpenRouter) → Tier 4 (OrcaRouter) → Tier 5 (Gemini) → Tier 6 (Custom Providers).
  - Total fallback timeout is strictly capped at `FALLBACK_TOTAL_TIMEOUT = 180000ms` (3 minutes).
  - Canvas Bridge (`callNgrokGemini`) is excluded from Global Automode to avoid 120s browser DOM hangs.
* **Tests to Run**: `node tests/test_kilo_and_custom_providers.js` (8/8 pass) and `node tests/test_provider_inference.js`.

---

### 4. Modifying `patch_kiro_extension.js` ([`scripts/patch_kiro_extension.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js))
* **If you change this, also check/update**:
  - Backup file `%LOCALAPPDATA%\Programs\Kiro\resources\app\extensions\kiro.kiro-agent\dist\extension.js.original`
  - Probe endpoint `http://127.0.0.1:8084/listAvailableModels`
  - `verify_proxy_mode.js` check #4
* **Coupling Rules**:
  - Patches must be idempotent: running `patch` multiple times must not corrupt or double-patch `extension.js`.
  - Offline fallback must remain dynamic: if port 8084 is offline, `globalThis.__kiroProxyActive` must be `false` to preserve native AWS Cloud connectivity.
* **Tests to Run**: `npm run patch:check` and `npm run patch:restore`.
