// Quick test script to verify tool translation with cline-glm-flash
const http = require('http');

const CONFIG = {
  proxyUrl: 'http://localhost:8084',
  model: 'kilo-free'  // Kilo Gateway default free model
};

async function testToolCall() {
  console.log('Testing tool call with cline-glm-flash...\n');

  const payload = {
    conversationState: {
      conversationId: 'test_' + Date.now(),
      currentMessage: {
        userInputMessage: {
          modelId: CONFIG.model
        }
      }
    },
    messages: [{
      role: 'user',
      content: 'List the files in the current directory'
    }],
    toolConfiguration: {
      tools: [{
        toolSpec: {
          name: 'list_directory',
          description: 'List files in a directory',
          inputSchema: {
            type: 'object',
            properties: {
              path: {
                type: 'string',
                description: 'Path to directory'
              },
              explanation: {
                type: 'string',
                description: 'Why listing this directory'
              }
            },
            required: ['path']
          }
        }
      }]
    }
  };

  const postData = JSON.stringify(payload);

  const options = {
    hostname: 'localhost',
    port: 8084,
    path: '/generateassistantresponse',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData),
      'x-amz-target': 'AWS.KiroRuntimeService.GenerateAssistantResponse'
    }
  };

  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      console.log(`Status: ${res.statusCode}`);
      console.log('Headers:', JSON.stringify(res.headers, null, 2));
      console.log('\nResponse chunks:\n');

      let chunks = [];
      res.on('data', (chunk) => {
        chunks.push(chunk);
        console.log('Chunk received:', chunk.length, 'bytes');
      });

      res.on('end', () => {
        const buffer = Buffer.concat(chunks);
        console.log('\nTotal bytes:', buffer.length);
        console.log('\nRaw response (first 1000 bytes):');
        console.log(buffer.slice(0, 1000).toString());
        resolve();
      });
    });

    req.on('error', (err) => {
      console.error('Request error:', err.message);
      reject(err);
    });

    req.write(postData);
    req.end();
  });
}

testToolCall().catch(console.error);
