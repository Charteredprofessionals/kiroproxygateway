# Unsupported Features - Kiro Proxy Gateway

**Version:** 2.7.0  
**Last Updated:** October 6, 2026

---

## Overview

The Kiro Proxy Gateway is designed to provide **chat completions, model discovery, and MCP tool execution** for free and low-cost AI providers. It is **NOT a complete replacement** for Kiro Cloud's full feature set.

This document explicitly lists features that are **NOT supported** by the proxy gateway.

---

## ❌ Unsupported Features

### 1. Workflow Orchestration

**Status:** NOT IMPLEMENTED

The proxy does not support Kiro IDE's workflow system:

- ❌ `run_workflow` - Cannot create or launch workflows
- ❌ `inspect_workflow` - Cannot query workflow status
- ❌ `update_workflow` - Cannot modify running workflows
- ❌ `validate_workflow` - Cannot validate workflow definitions
- ❌ WorkflowService APIs - All workflow endpoints missing

**Why:** Workflows require persistent state management, multi-agent orchestration, and cloud infrastructure that exceeds the scope of a local proxy.

**Alternative:** Use Kiro Cloud for workflow features, or manually coordinate multi-step tasks.

**Error if attempted:**
```json
{
  "error": "UnsupportedOperation",
  "message": "Workflow operations are not supported by the proxy gateway",
  "recommendation": "Use Kiro Cloud for workflow features"
}
```

---

### 2. Spec Management

**Status:** NOT IMPLEMENTED

The proxy does not support Kiro's structured specification system:

- ❌ Spec creation/editing
- ❌ Requirements → Design → Tasks flow
- ❌ Spec file operations
- ❌ Task tracking and status updates

**Why:** Specs are tightly integrated with Kiro IDE's session management and file system.

**Alternative:** Use Kiro Cloud spec sessions, or manage specifications manually in markdown files.

---

### 3. Direct File Operations (AWS API)

**Status:** NOT IMPLEMENTED

The proxy does not provide direct AWS S3-style file operations:

- ❌ `read_file` as top-level API (only as MCP tool)
- ❌ `write_file` as top-level API (only as MCP tool)
- ❌ `list_directory` as top-level API (only as MCP tool)
- ❌ `delete_file` as top-level API (only as MCP tool)

**Why:** File operations are handled through MCP server integration, not direct AWS-style APIs.

**Alternative:** Use MCP tools for file operations, or use direct Node.js `fs` module access.

**Important:** MCP tools ARE supported for file operations, just not as top-level AWS APIs.

---

### 4. Advanced Session Management

**Status:** PARTIALLY SUPPORTED

The proxy has limited session management capabilities:

- ❌ Persistent session storage
- ❌ Session restoration across restarts
- ❌ Multi-user session isolation
- ❌ Session analytics and metrics

**What IS supported:**
- ✅ In-memory session state during runtime
- ✅ Basic session creation and termination
- ✅ Session-level configuration

**Alternative:** Use Kiro Cloud for persistent sessions, or implement custom session management.

---

### 5. Advanced Authentication

**Status:** BASIC ONLY

The proxy supports basic authentication but lacks advanced features:

- ❌ OAuth2 flows
- ❌ JWT token management
- ❌ Multi-factor authentication
- ❌ Role-based access control
- ❌ SSO integration

**What IS supported:**
- ✅ API key authentication
- ✅ Basic bearer token auth
- ✅ Simple HTTP auth

**Alternative:** Use Kiro Cloud for enterprise auth, or implement custom auth middleware.

---

### 6. Advanced Analytics & Monitoring

**Status:** BASIC ONLY

The proxy provides basic monitoring but lacks advanced analytics:

- ❌ Usage analytics and billing
- ❌ Performance metrics dashboard
- ❌ Real-time monitoring
- ❌ Advanced logging and tracing
- ❌ Cost tracking

**What IS supported:**
- ✅ Basic health checks
- ✅ Simple logging
- ✅ Request/response tracking
- ✅ Error reporting

**Alternative:** Use Kiro Cloud for analytics, or implement custom monitoring solutions.

---

### 7. Advanced Configuration Management

**Status:** BASIC ONLY

The proxy has simple configuration management:

- ❌ Dynamic configuration updates
- ❌ Configuration versioning
- ❌ Configuration validation
- ❌ Configuration templates

**What IS supported:**
- ✅ Static configuration files
- ✅ Environment variables
- ✅ Basic GUI configuration

**Alternative:** Use Kiro Cloud for advanced config, or implement custom config management.

---

### 8. Advanced Error Handling

**Status:** BASIC ONLY

The proxy handles basic errors but lacks advanced features:

- ❌ Automatic retry with exponential backoff
- ❌ Circuit breaker patterns
- ❌ Error categorization and routing
- ❌ Advanced error recovery

**What IS supported:**
- ✅ Basic error responses
- ✅ Simple retry logic
- ✅ Error logging

**Alternative:** Implement custom error handling middleware.

---

### 9. Advanced Networking

**Status:** BASIC ONLY

The proxy has basic networking capabilities:

- ❌ Load balancing
- ❌ Connection pooling
- ❌ Advanced routing rules
- ❌ Network health checks
- ❌ Failover clustering

**What IS supported:**
- ✅ Basic HTTP proxying
- ✅ Simple load balancing (round-robin)
- ✅ Basic health checks

**Alternative:** Use Kiro Cloud for advanced networking, or implement custom load balancing.

---

### 10. Advanced Security

**Status:** BASIC ONLY

The proxy has basic security features:

- ❌ Advanced encryption
- ❌ Security scanning
- ❌ Compliance checking
- ❌ Advanced threat detection

**What IS supported:**
- ✅ Basic HTTPS support
- ✅ Simple API key validation
- ✅ Basic rate limiting

**Alternative:** Use Kiro Cloud for advanced security, or implement custom security measures.

---

## Workarounds and Alternatives

| Feature | Workaround | Alternative |
|---------|------------|-------------|
| **Workflows** | Manual task coordination | Kiro Cloud workflows |
| **Spec Management** | Markdown files + manual tracking | Kiro Cloud spec sessions |
| **File Operations** | MCP tools (`read_file`, `fs_write` as tool calls) | Local `fs` module access |
| **Git Operations** | Local `git` CLI commands | Kiro Cloud Git integration |
| **Authentication** | Environment variables for API keys | Kiro Cloud enterprise auth |
| **Analytics** | Custom logging scripts | Kiro Cloud analytics dashboard |
| **Configuration** | GUI config + environment variables | Kiro Cloud configuration management |

---

## Future Support

Features that **MAY** be added in future versions:

### Short-term (Next 3-6 months)
- 🔄 Basic workflow support (single-agent, linear tasks)
- 🔄 Simple spec tracking (markdown-based)
- 🔄 Enhanced MCP server management

### Medium-term (6-12 months)
- 🔄 Multi-user session management
- 🔄 Usage analytics (non-billing)
- 🔄 Advanced workflow features

### Long-term (12+ months)
- 🔄 Full workflow orchestration parity
- 🔄 Cloud backend integration
- 🔄 Distributed execution

**Note:** These are aspirational and not commitments.

---

## Reporting Issues

If you encounter an error related to unsupported features:

1. **Check this document** to confirm the feature is unsupported
2. **Review logs** for detailed error messages
3. **Use alternatives** listed above
4. **File an issue** if you believe a feature should be added

**Do NOT** file bugs for features explicitly listed as unsupported unless you have a compelling use case and proposed implementation.

---

## Documentation

- **Full Feature List:** See [AUDIT_REPORT.md](../archive/AUDIT_REPORT.md)
- **Supported Providers:** See [README.md](../README.md)
- **Edge Cases:** See [EDGE_CASE_AUDIT_AND_IMPROVEMENT_PLAN.md](../archive/EDGE_CASE_AUDIT_AND_IMPROVEMENT_PLAN.md)
- **Integration Guide:** See [KIRO_IDE_INTEGRATION_GUIDE.md](../setup/KIRO_IDE_INTEGRATION_GUIDE.md)

---

**Last Updated:** October 6, 2026  
**Version:** 2.7.0