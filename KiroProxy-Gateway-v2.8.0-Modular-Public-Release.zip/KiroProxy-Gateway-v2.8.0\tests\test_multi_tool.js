// Test script to verify multi-tool extraction from various formats

// Simulate the stripToolBlocksFromText function
function stripToolBlocksFromText(text) {
  if (!text) return '';
  let cleaned = text;
  
  // Remove JSON tool blocks (with code fences) - improved to handle multiline
  cleaned = cleaned.replace(/```json\s*\{[\s\S]*?(?:"tool"|"name")\s*:\s*"[^"]+"\s*,?\s*(?:"arguments"|"input"|"parameters")\s*:\s*\{[\s\S]*?\}\s*\}\s*```/gi, '');
  
  // FIX: Remove BARE JSON tool objects (without code fences)
  // Handles nested objects with escaped quotes
  // Pattern: {"tool":"name","arguments":{...with possible nesting...}}
  cleaned = cleaned.replace(/\{\s*(?:"tool"|"name")\s*:\s*"[^"]+"\s*,\s*(?:"arguments"|"input"|"parameters")\s*:\s*\{(?:[^{}]|\{[^{}]*\})*\}\s*(?:,\s*"[^"]+"\s*:\s*(?:"(?:[^"\\]|\\.)*"|true|false|null|[\d.]+))?\s*\}/gi, '');
  
  // Remove XML invoke blocks
  cleaned = cleaned.replace(/<invoke\s+name="[^"]+">([\s\S]*?)<\/invoke>/gi, '');
  
  // Remove Anthropic tool_use blocks
  cleaned = cleaned.replace(/<tool_use>[\s\S]*?<\/tool_use>/gi, '');
  
  // Remove Kiro native tool_call blocks (including DSML dialect)
  cleaned = cleaned.replace(/<[\|\s]*(?:DSML[\|\s]*)?tool_call[\|\s]*>[\s\S]*?<[\|\/\s]*(?:DSML[\|\s]*)?tool_call[\|\/\s]*>/gi, '');
  
  // Remove bare tool invocation markers
  cleaned = cleaned.replace(/\[tool_call:\s*\w+[\s\S]*?\]/gi, '');
  
  // Clean up excessive newlines (3+ → 2)
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n').trim();
  
  return cleaned;
}

console.log('Testing Multi-Tool Extraction\n' + '='.repeat(50) + '\n');

// Test 1: Multiple bare JSON tools
const test1 = `I'll help you with that. First, let me read the file.

{"tool":"read_file","arguments":{"path":"test.js","explanation":"Reading test file"}}

Now I'll list the directory.

{"tool":"list_directory","arguments":{"path":".","explanation":"Listing current directory"}}

Done!`;

console.log('Test 1: Multiple bare JSON tools');
console.log('Input length:', test1.length);
const cleaned1 = stripToolBlocksFromText(test1);
console.log('Output:', cleaned1);
console.log('Expected: "I\'ll help you with that. First, let me read the file.\\n\\nNow I\'ll list the directory.\\n\\nDone!"');
console.log('Match:', cleaned1.includes('Done!') && !cleaned1.includes('tool'));
console.log('');

// Test 2: Multiple JSON code blocks
const test2 = `Here are the tools:

\`\`\`json
{"tool":"read_file","arguments":{"path":"file1.js"}}
\`\`\`

And another one:

\`\`\`json
{"tool":"fs_write","arguments":{"path":"file2.js","text":"content"}}
\`\`\`

All set!`;

console.log('Test 2: Multiple JSON code blocks');
console.log('Input length:', test2.length);
const cleaned2 = stripToolBlocksFromText(test2);
console.log('Output:', cleaned2);
console.log('Expected: "Here are the tools:\\n\\nAnd another one:\\n\\nAll set!"');
console.log('Match:', cleaned2.includes('All set!') && !cleaned2.includes('tool'));
console.log('');

// Test 3: Mixed formats
const test3 = `Let me do three things:

{"tool":"read_file","arguments":{"path":"a.js"}}

<invoke name="list_directory">{"path":"."}</invoke>

\`\`\`json
{"tool":"execute_pwsh","arguments":{"command":"npm test"}}
\`\`\`

Done with all three!`;

console.log('Test 3: Mixed formats (bare JSON + XML + code block)');
console.log('Input length:', test3.length);
const cleaned3 = stripToolBlocksFromText(test3);
console.log('Output:', cleaned3);
console.log('Expected: "Let me do three things:\\n\\nDone with all three!"');
console.log('Match:', cleaned3.includes('Done with all three!') && !cleaned3.includes('tool'));
console.log('');

// Test 4: Edge case - nested JSON
const test4 = `Here's a tool with nested objects:

{"tool":"fs_write","arguments":{"path":"config.json","text":"{\\"key\\":\\"value\\",\\"nested\\":{\\"foo\\":\\"bar\\"}}"}}

Should strip cleanly.`;

console.log('Test 4: Nested JSON in arguments');
console.log('Input length:', test4.length);
const cleaned4 = stripToolBlocksFromText(test4);
console.log('Output:', cleaned4);
console.log('Expected: "Here\'s a tool with nested objects:\\n\\nShould strip cleanly."');
console.log('Match:', cleaned4.includes('Should strip cleanly') && !cleaned4.includes('tool'));
console.log('');

console.log('='.repeat(50));
console.log('All tests completed!');
