# Testing Strategy and Test Suite Matrix — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary Files:** [`tests/`](file:///d:/sdlc_studio/projects/kiro-integration/tests/), [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)  
**Total Test Suites:** 17 suites in `tests/` + 4-tier E2E runner (57 automated assertions).

---

## 1. Test Suite Organization and Module Guard Matrix

| Test Suite File | Type & Target | Modules / Areas Guarded | Execution Command | Current Status |
| :--- | :--- | :--- | :--- | :--- |
| **E2E 4-Tier Master Runner**<br>[`tests/e2e/e2e_runner.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/e2e/e2e_runner.js)<br>• `tier1_features.test.js`<br>• `tier2_boundaries.test.js`<br>• `tier3_combinations.test.js`<br>• `tier4_scenarios.test.js` | Full Opaque-Box E2E Integration (HTTP/EventStream) | • Tier 1: Free inference, SSE streaming, metrics<br>• Tier 2: Canvas Bridge, CORS, Ngrok queue<br>• Tier 3: Kiro IDE Smithy converse, steering, limits<br>• Tier 4: Rebranding, AWS header compliance | `node tests/e2e/e2e_runner.js` | **PASS: 57/57 (100%)** |
| **Main Gateway Suite**<br>[`tests/test_gateway.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_gateway.js) | Black-box HTTP Integration | Core HTTP routing, `/health`, `/status`, `/v1/models`, `/runtime/workflows/*`, `/metrics`, `/canvas`, `/poll` | `node tests/test_gateway.js` | **PASS: 19/19 (100%)** |
| **Validators Unit Suite**<br>[`tests/validators.test.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/validators.test.js) | Pure In-Process Unit Test | `scripts/utils/validators.js` (`validateToolCall`, `validateApiKey`, `validateChatRequest`, `validateModelId`, `validateQueueConfig`) | `node tests/validators.test.js` | **PASS: 23/23 (100%)** |
| **Edge Cases & Failure Modes**<br>[`tests/test_edge_cases.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_edge_cases.js) | HTTP Boundary Integration | `/v1/chat/completions` input sanitization, 10MB payload limit, temperature/token boundaries | `node tests/test_edge_cases.js` | **PASS: 12/12 (100%)** |
| **Bare JSON Tool Calls**<br>[`tests/test_bare_json_tool_calls.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_bare_json_tool_calls.js) | Unit Test (`eval` slice) | Bare/unfenced JSON tool parsing (Format 1b), Windows backslash path escaping in `scripts/kiro_proxy_server.js` | `node tests/test_bare_json_tool_calls.js` | **PASS: 9/9 (100%)** |
| **Tool Translation Layer**<br>[`tests/test_tool_translation_layer.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_tool_translation_layer.js) | Unit Test (`vm` slice) | AWS Smithy tool extraction, `userInputMessageContext.tools`, 3-Spec Method prompt, balanced JSON brace extraction | `node tests/test_tool_translation_layer.js` | **PASS: 7/7 (100%)** |
| **Canvas History Preservation**<br>[`tests/test_canvas_history_preservation.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_canvas_history_preservation.js) | In-Process Unit Test (Duplicated copy) | Canvas Bridge payload truncation (`prunePayloadForCanvas`, 1500 char budget, reverse-turn pruning) | `node tests/test_canvas_history_preservation.js` | **PASS: 8/8 (100%)** *(Tests local clone)* |
| **Function Calls Format**<br>[`tests/test_function_calls_format.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_function_calls_format.js) | In-Process Regex Unit Test | `<function_calls>` and `<dots_function_call>` XML tool stripping | `node tests/test_function_calls_format.js` | **PASS: 5/5 (100%)** *(Tests local clone)* |
| **Custom Providers Suite**<br>[`tests/test_custom_providers.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_custom_providers.js) | HTTP Integration | Custom providers config (`/api/config`), model prefixes, Groq/GLM/Abhyast catalog ingestion | `node tests/test_custom_providers.js` | **FAIL: 4 pass, 3 fail** *(Flawed test regex on slugs with `_`)* |
| **Reliability Layer Suite**<br>[`tests/test_reliability_layer.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_reliability_layer.js) | HTTP Integration (v2.5.0 Legacy) | Circuit breakers, health engine, exponential backoff metrics | `node tests/test_reliability_layer.js` | **FAIL: 7 pass, 8 fail** *(v2.5 schema drift against v2.8)* |
| **Kilo & Custom Providers**<br>[`tests/test_kilo_and_custom_providers.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_kilo_and_custom_providers.js) | Live Network Integration | Kilo API live completion, Custom Groq live completion, config file check | `node tests/test_kilo_and_custom_providers.js` | **PASS** *(Requires upstream network)* |
| **Real World Agent Scenario**<br>[`tests/test_real_world_agent_scenario.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_real_world_agent_scenario.js) | Live Inference Integration | Kiro IDE multi-turn coding session, tool definition acceptance, 3 concurrent requests | `node tests/test_real_world_agent_scenario.js` | **PASS** *(Requires live server)* |
| **Kiro Tool Events**<br>[`tests/test_kiro_tool_events.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_kiro_tool_events.js) | Live Inference Integration | EventStream `toolUseEvent.input` string serialization contract | `node tests/test_kiro_tool_events.js` | **PASS** *(Hang hazard if socket delays)* |
| **Master Test Runner**<br>[`tests/run_all_tests.js`](file:///d:/sdlc_studio/projects/kiro-integration/tests/run_all_tests.js) | CLI Test Runner | Orchestrates test execution | `node tests/run_all_tests.js` | **FRAGMENTED** *(Only runs 2 suites)* |

---

## 2. What Is Covered vs What Is Not Covered

### Strongly Covered Areas
- **EventStream Binary Formatting:** Covered by `tier1_features.test.js` and `test_kiro_tool_events.js`.
- **Bare JSON Tool Extraction:** Covered by 9 unit tests in `test_bare_json_tool_calls.js`.
- **Smithy Tool Extraction:** Covered by 7 unit tests in `test_tool_translation_layer.js`.
- **HTTP Endpoint Routing & CORS:** Covered by 19 tests in `test_gateway.js` and `tier2_boundaries.test.js`.
- **Payload Boundaries & Sanitization:** Covered by 12 tests in `test_edge_cases.js`.

### Critical Coverage Gaps & Fragile Tests
- **`[FACT]` Monolith Lack of `module.exports`:** `scripts/kiro_proxy_server.js` exports nothing. Tests either parse the code as a string and execute substrings using `eval()` or `vm.runInNewContext()`, or test copy-pasted implementations (`test_canvas_history_preservation.js`).
- **`[FACT]` Obsolete Assertions in `test_reliability_layer.js`:** 8 assertions fail because the test checks v2.5.0 responses (e.g. `res.body.health.providers`) instead of v2.8.0 (`res.body.providers`).
- **`[FACT]` Live Inference Flakiness:** Tests making real upstream calls (`test_kilo_and_custom_providers.js`, `test_real_world_agent_scenario.js`) intermittently fail when upstream providers rate-limit or experience network outages.
- **`[FACT]` Missing Live Circuit Breaker Trip Verification:** No automated test simulates 5 consecutive 503 errors and verifies the state transition from `CLOSED` → `OPEN` → `HALF_OPEN`.

---

## 3. How to Safely Verify a Change

Follow this verification procedure before committing any change:

```bash
# Step 1: Run fast in-process unit tests (no server required)
node tests/validators.test.js
node tests/test_bare_json_tool_calls.js
node tests/test_tool_translation_layer.js

# Step 2: Ensure proxy server is running locally on port 8084
curl http://localhost:8084/health

# Step 3: Run core black-box gateway test suite
node tests/test_gateway.js

# Step 4: Run comprehensive 4-tier E2E test suite (57 tests)
node tests/e2e/e2e_runner.js

# Step 5: Check extension patch status
npm run patch:check
```
