# Guides Documentation

This section contains user-facing guides for using the KiroProxy Gateway with Kiro IDE.

## 📄 Available Guides

- **[Proxy Mode Restored](PROXY_MODE_RESTORED.md)** - Workflow compatibility layer
- **[Kiro IDE New UI Compatibility](KIRO_IDE_NEW_UI_COMPATIBILITY.md)** - UI integration
- **[Workflows and Proxy Mode](WORKFLOWS_AND_PROXY_MODE.md)** - Workflow handling
- **[Focus Mode Compatibility](FOCUS_MODE_COMPATIBILITY.md)** - Focus features
- **[Proxy Mode Workflow Methodology](PROXY_MODE_WORKFLOW_METHODOLOGY.md)** - Workflow approach
- **[Unsupported Features](../UNSUPPORTED_FEATURES.md)** - Known limitations

## 🎯 Purpose

These guides help users understand how the proxy works with Kiro IDE's various modes and features.

---

**Part of KiroProxy Gateway Documentation**