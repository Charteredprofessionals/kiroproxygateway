/**
 * test_kilo_and_custom_providers.js
 * 
 * Specifically tests Kilo API and Custom provider functionality
 */

const http = require('http');

const PROXY_HOST = '127.0.0.1';
const PROXY_PORT = 8084;
const TIMEOUT = 45000;

// Colors
const RESET = '\x1b[0m';
const GREEN = '\x1b[32m';
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const BLUE = '\x1b[34m';
const CYAN = '\x1b[36m';

function log(msg, color = RESET) {
  console.log(`${color}${msg}${RESET}`);
}

function makeRequest(options, body = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ statusCode: res.statusCode, headers: res.headers, body: parsed });
        } catch (e) {
          resolve({ statusCode: res.statusCode, headers: res.headers, body: data });
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(TIMEOUT, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });

    if (body) req.write(typeof body === 'string' ? body : JSON.stringify(body));
    req.end();
  });
}

function makeStreamingRequest(options, body = null) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    
    const req = http.request(options, (res) => {
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        resolve({ 
          statusCode: res.statusCode, 
          headers: res.headers, 
          chunks,
          fullBuffer: Buffer.concat(chunks)
        });
      });
    });

    req.on('error', reject);
    req.setTimeout(TIMEOUT, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });

    if (body) req.write(typeof body === 'string' ? body : JSON.stringify(body));
    req.end();
  });
}

let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    await fn();
    log(`✅ ${name}`, GREEN);
    passed++;
  } catch (error) {
    log(`❌ ${name}`, RED);
    log(`   Error: ${error.message}`, RED);
    failed++;
  }
}

// ============================================================================
// TEST 1: Health check shows provider details
// ============================================================================
async function testHealthEndpoint() {
  const response = await makeRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/health',
    method: 'GET'
  });

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }

  const health = response.body;
  
  if (!health.providers) {
    throw new Error('No providers in health response');
  }

  const kiloHealth = health.providers.kilo;
  const customHealth = health.providers['custom-groq'];

  log(`   ℹ️ Kilo status: ${kiloHealth?.status || 'unknown'}`, CYAN);
  log(`   ℹ️ Custom-Groq status: ${customHealth?.status || 'unknown'}`, CYAN);
  log(`   ℹ️ Total providers: ${Object.keys(health.providers).length}`, CYAN);
}

// ============================================================================
// TEST 2: Model list includes Kilo models
// ============================================================================
async function testKiloModelsAvailable() {
  const response = await makeRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/listAvailableModels',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {});

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }

  const models = response.body.models || [];
  const kiloModels = models.filter(m => m.modelId.startsWith('kilo-'));
  
  if (kiloModels.length === 0) {
    throw new Error('No Kilo models found');
  }

  log(`   ℹ️ Kilo models found: ${kiloModels.length}`, CYAN);
  log(`   ℹ️ Examples: ${kiloModels.slice(0, 3).map(m => m.modelId).join(', ')}`, CYAN);
}

// ============================================================================
// TEST 3: Model list includes Custom models
// ============================================================================
async function testCustomModelsAvailable() {
  const response = await makeRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/listAvailableModels',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {});

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }

  const models = response.body.models || [];
  const customModels = models.filter(m => m.modelId.startsWith('custom-'));
  
  if (customModels.length === 0) {
    throw new Error('No Custom models found');
  }

  log(`   ℹ️ Custom models found: ${customModels.length}`, CYAN);
  log(`   ℹ️ Examples: ${customModels.slice(0, 3).map(m => m.modelId).join(', ')}`, CYAN);
}

// ============================================================================
// TEST 4: Kilo API inference test
// ============================================================================
async function testKiloInference() {
  const requestBody = {
    messages: [{ role: 'user', content: 'Say "Kilo API working" in exactly 3 words.' }],
    model: 'kilo-free',
    max_tokens: 20
  };

  const response = await makeStreamingRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/generateAssistantResponse',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-amzn-requestid': 'test-kilo-inference-001'
    }
  }, requestBody);

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }

  if (response.fullBuffer.length === 0) {
    throw new Error('Empty response from Kilo');
  }

  log(`   ℹ️ Response size: ${response.fullBuffer.length} bytes`, CYAN);
  log(`   ℹ️ Kilo API is responding`, GREEN);
}

// ============================================================================
// TEST 5: Custom provider (Groq) inference test
// ============================================================================
async function testCustomGroqInference() {
  const requestBody = {
    messages: [{ role: 'user', content: 'Say "Custom Groq working" in exactly 3 words.' }],
    model: 'custom-groq',
    max_tokens: 20
  };

  const response = await makeStreamingRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/generateAssistantResponse',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-amzn-requestid': 'test-custom-inference-001'
    }
  }, requestBody);

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }

  if (response.fullBuffer.length === 0) {
    throw new Error('Empty response from Custom Groq');
  }

  log(`   ℹ️ Response size: ${response.fullBuffer.length} bytes`, CYAN);
  log(`   ℹ️ Custom Groq API is responding`, GREEN);
}

// ============================================================================
// TEST 6: Kilo with tool definitions
// ============================================================================
async function testKiloWithTools() {
  const requestBody = {
    messages: [{ role: 'user', content: 'Test tool support' }],
    model: 'kilo-free',
    max_tokens: 100,
    tools: [
      {
        name: 'test_tool',
        description: 'A test tool',
        input_schema: {
          type: 'object',
          properties: {
            param: { type: 'string' }
          }
        }
      }
    ]
  };

  const response = await makeStreamingRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/generateAssistantResponse',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-amzn-requestid': 'test-kilo-tools-001'
    }
  }, requestBody);

  if (response.statusCode !== 200) {
    throw new Error(`Expected 200, got ${response.statusCode}`);
  }

  log(`   ℹ️ Kilo accepts tool definitions`, GREEN);
}

// ============================================================================
// TEST 7: Check configuration files exist
// ============================================================================
async function testConfigurationFiles() {
  const fs = require('fs');
  const path = require('path');
  
  const configPath = path.join(__dirname, '..', 'config', 'kiro_ai_config.json');
  
  if (!fs.existsSync(configPath)) {
    throw new Error('Configuration file not found');
  }

  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  
  // Check for Kilo keys
  const hasKiloKeys = config.kilo?.apiKeys && config.kilo.apiKeys.length > 0;
  
  // Check for custom providers
  const hasCustom = config.customProviders && config.customProviders.length > 0;
  
  if (!hasKiloKeys) {
    log(`   ⚠️ No Kilo API keys configured`, YELLOW);
  } else {
    log(`   ℹ️ Kilo API keys: ${config.kilo.apiKeys.length}`, CYAN);
  }
  
  if (!hasCustom) {
    log(`   ⚠️ No custom providers configured`, YELLOW);
  } else {
    log(`   ℹ️ Custom providers: ${config.customProviders.length}`, CYAN);
    config.customProviders.forEach(p => {
      log(`   ℹ️   - ${p.name} (${p.baseUrl})`, CYAN);
    });
  }
}

// ============================================================================
// TEST 8: Verify model metadata
// ============================================================================
async function testModelMetadata() {
  const response = await makeRequest({
    hostname: PROXY_HOST,
    port: PROXY_PORT,
    path: '/listAvailableModels',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {});

  const models = response.body.models || [];
  
  // Check Kilo model metadata
  const kiloModel = models.find(m => m.modelId === 'kilo-free');
  if (kiloModel) {
    log(`   ℹ️ Kilo-free metadata:`, CYAN);
    log(`      Provider: ${kiloModel.provider}`, CYAN);
    log(`      Pricing: ${kiloModel.pricingTier || 'free'}`, CYAN);
    log(`      Context: ${kiloModel.contextWindow || 'unknown'}`, CYAN);
  }
  
  // Check Custom model metadata
  const customModel = models.find(m => m.modelId === 'custom-groq');
  if (customModel) {
    log(`   ℹ️ Custom-groq metadata:`, CYAN);
    log(`      Provider: ${customModel.provider}`, CYAN);
    log(`      Pricing: ${customModel.pricingTier || 'custom'}`, CYAN);
  }
}

// ============================================================================
// MAIN TEST RUNNER
// ============================================================================
(async () => {
  console.log('═'.repeat(70));
  log('  Kilo API & Custom Provider Verification Tests', BLUE);
  console.log('═'.repeat(70));
  console.log();

  log('🔍 Configuration & Discovery...', BLUE);
  await test('1. Health Endpoint Shows Providers', testHealthEndpoint);
  await test('2. Configuration Files Exist', testConfigurationFiles);
  await test('3. Kilo Models Available', testKiloModelsAvailable);
  await test('4. Custom Models Available', testCustomModelsAvailable);
  await test('5. Model Metadata Complete', testModelMetadata);
  
  console.log();
  log('🚀 Live Inference Tests...', BLUE);
  await test('6. Kilo API Inference', testKiloInference);
  await test('7. Custom Groq Inference', testCustomGroqInference);
  await test('8. Kilo with Tool Definitions', testKiloWithTools);

  console.log();
  console.log('═'.repeat(70));
  log('  Test Summary', BLUE);
  console.log('═'.repeat(70));
  log(`✅ Passed:  ${passed}`, GREEN);
  log(`❌ Failed:  ${failed}`, failed > 0 ? RED : GREEN);
  log(`📊 Total:   ${passed + failed}`, CYAN);
  log(`📈 Success: ${Math.round(passed / (passed + failed) * 100)}%`, passed === passed + failed ? GREEN : YELLOW);

  if (failed > 0) {
    console.log();
    log('⚠️  Some tests failed. Review details above.', YELLOW);
    process.exit(1);
  } else {
    console.log();
    log('🎉 All Kilo API & Custom provider tests passed!', GREEN);
    console.log();
    log('✅ VERIFIED:', GREEN);
    log('  • Kilo API configured and responding', CYAN);
    log('  • Kilo models available and working', CYAN);
    log('  • Custom providers configured', CYAN);
    log('  • Custom models available and working', CYAN);
    log('  • Tool definitions supported', CYAN);
    console.log();
    log('📌 KILO API & CUSTOM PROVIDERS: FULLY OPERATIONAL ✅', GREEN);
    process.exit(0);
  }
})();
