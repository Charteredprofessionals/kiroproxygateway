@echo off
setlocal EnableDelayedExpansion
:: ============================================================
::  test_gateway.bat — KiroProxy Gateway Test Suite v2.8.0
::  Tests all endpoints, validates responses, checks models.
:: ============================================================

set "BATCH_DIR=%~dp0"
set "BATCH_DIR=%BATCH_DIR:~0,-1%"
for %%i in ("%BATCH_DIR%\..") do set "SCRIPTS_DIR=%%~fi"
for %%i in ("%SCRIPTS_DIR%\..") do set "ROOT_DIR=%%~fi"

set "PROXY=http://127.0.0.1:8084"
set PASS=0
set FAIL=0

echo.
echo  ============================================================
echo    KiroProxy Gateway — Test Suite v2.8.0
echo  ============================================================
echo.

:: ── T01: Server health ────────────────────────────────────────
echo  [T01] Server health endpoint...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$h=Invoke-RestMethod '%PROXY%/health' -TimeoutSec 5;if($h.status-eq'ok'){'PASS: v'+$h.version}else{'FAIL: status='+$h.status}}catch{'FAIL: '+$_.Exception.Message}"') do set R01=%%r
if "!R01:~0,4!"=="PASS" ( echo    [PASS] !R01! & set /a PASS+=1 ) else ( echo    [FAIL] !R01! & set /a FAIL+=1 )

:: ── T02: Models endpoint ──────────────────────────────────────
echo  [T02] Model catalog — count and free-only check...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$m=Invoke-RestMethod '%PROXY%/listAvailableModels' -TimeoutSec 5;$total=$m.models.Count;$free=($m.models|Where-Object{$_.rateMultiplier-eq 0}).Count;$paid=($m.models|Where-Object{$_.rateMultiplier-gt 0}).Count;if($paid-gt 0){'FAIL: '+$paid+' PAID models in list'}else{'PASS: '+$total+' models, all free'}}catch{'FAIL: '+$_.Exception.Message}"') do set R02=%%r
if "!R02:~0,4!"=="PASS" ( echo    [PASS] !R02! & set /a PASS+=1 ) else ( echo    [FAIL] !R02! & set /a FAIL+=1 )

:: ── T03: Minimum model count ──────────────────────────────────
echo  [T03] Model catalog — minimum 20 models...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$m=Invoke-RestMethod '%PROXY%/listAvailableModels' -TimeoutSec 5;$c=$m.models.Count;if($c-ge 20){'PASS: '+$c+' models'}else{'FAIL: only '+$c+' models (expected 20+)'}}catch{'FAIL: '+$_.Exception.Message}"') do set R03=%%r
if "!R03:~0,4!"=="PASS" ( echo    [PASS] !R03! & set /a PASS+=1 ) else ( echo    [FAIL] !R03! & set /a FAIL+=1 )

:: ── T04: OpenAI models endpoint ───────────────────────────────
echo  [T04] OpenAI-compatible /v1/models...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$m=Invoke-RestMethod '%PROXY%/v1/models' -TimeoutSec 5;if($m.object-eq'list' -and $m.data.Count-gt 0){'PASS: '+$m.data.Count+' models'}else{'FAIL: unexpected format'}}catch{'FAIL: '+$_.Exception.Message}"') do set R04=%%r
if "!R04:~0,4!"=="PASS" ( echo    [PASS] !R04! & set /a PASS+=1 ) else ( echo    [FAIL] !R04! & set /a FAIL+=1 )

:: ── T05: Canvas Bridge /poll ──────────────────────────────────
echo  [T05] Canvas Bridge /poll endpoint...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$p=Invoke-RestMethod '%PROXY%/poll' -TimeoutSec 8;if($p -ne $null){'PASS: poll returned valid JSON'}else{'FAIL: null response'}}catch{'FAIL: '+$_.Exception.Message}"') do set R05=%%r
if "!R05:~0,4!"=="PASS" ( echo    [PASS] !R05! & set /a PASS+=1 ) else ( echo    [FAIL] !R05! & set /a FAIL+=1 )

:: ── T06: Workflow stubs (should return gracefully) ────────────
echo  [T06] Workflow compatibility stubs...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$b='{}';$h=@{'Content-Type'='application/json'};$r=Invoke-RestMethod -Method POST '%PROXY%/runtime/workflows/run' -Body $b -Headers $h -TimeoutSec 5;if($r.status-eq'not_supported'){'PASS: workflow stub returns not_supported'}else{'FAIL: unexpected response: '+($r|ConvertTo-Json -Compress)}}catch{'FAIL: '+$_.Exception.Message}"') do set R06=%%r
if "!R06:~0,4!"=="PASS" ( echo    [PASS] !R06! & set /a PASS+=1 ) else ( echo    [FAIL] !R06! & set /a FAIL+=1 )

:: ── T07: AWS converse endpoint ────────────────────────────────
echo  [T07] AWS converse endpoint...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$b='{\"messages\":[{\"role\":\"user\",\"content\":[{\"text\":\"hi\"}]}],\"modelId\":\"auto\"}';$h=@{'Content-Type'='application/json';'x-amz-target'='AmazonBedrockFrontendService.Converse'};$r=Invoke-RestMethod -Method POST '%PROXY%/converse' -Body $b -Headers $h -TimeoutSec 10;if($r){'PASS: converse responded'}else{'FAIL: null response'}}catch{'FAIL: '+$_.Exception.Message}"') do set R07=%%r
if "!R07:~0,4!"=="PASS" ( echo    [PASS] !R07! & set /a PASS+=1 ) else ( echo    [FAIL] !R07! & set /a FAIL+=1 )

:: ── T08: Ngrok tunnel live ────────────────────────────────────
echo  [T08] Ngrok tunnel status...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$h=Invoke-RestMethod 'http://127.0.0.1:8084/health' -TimeoutSec 5;if($h.tunnel -and $h.tunnel -ne 'localhost'){'PASS: '+$h.tunnel}else{'WARN: no tunnel (local only)'}}catch{'FAIL: '+$_.Exception.Message}"') do set R08=%%r
if "!R08:~0,4!"=="PASS" ( echo    [PASS] !R08! & set /a PASS+=1 ) else ( echo    [WARN] !R08! )

:: ── T09: Extension patch status ──────────────────────────────
echo  [T09] Kiro IDE extension patch...
for /f "delims=" %%r in ('powershell -NoProfile -Command "cd '%ROOT_DIR%'; $o = node scripts\patch_kiro_extension.js --check 2>&1 | Out-String; if($o -match 'Patch 1.*APPLIED'){'PASS: Patch 1 applied'}else{'FAIL: Patch 1 not applied'}"') do set R09=%%r
if "!R09:~0,4!"=="PASS" ( echo    [PASS] !R09! & set /a PASS+=1 ) else ( echo    [FAIL] !R09! & set /a FAIL+=1 )

:: ── T10: Chat completion (auto model) ────────────────────────
echo  [T10] Chat completion via auto model...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$b='{\"model\":\"auto\",\"messages\":[{\"role\":\"user\",\"content\":\"say ok\"}]}';$h=@{'Content-Type'='application/json'};$r=Invoke-RestMethod -Method POST '%PROXY%/v1/chat/completions' -Body $b -Headers $h -TimeoutSec 30;if($r.choices -and $r.choices.Count -gt 0){'PASS: got response from '+$r.model}else{'FAIL: no choices in response'}}catch{'FAIL: '+$_.Exception.Message}"') do set R10=%%r
if "!R10:~0,4!"=="PASS" ( echo    [PASS] !R10! & set /a PASS+=1 ) else ( echo    [FAIL] !R10! & set /a FAIL+=1 )

:: ── T11: Provider objects include status field ────────────────
echo  [T11] Health endpoint — provider objects have status field...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$h=Invoke-RestMethod '%PROXY%/health' -TimeoutSec 5;$p=$h.providers.kilo;if($p.status){'PASS: providers have status objects (kilo='+$p.status+', latency='+$p.latency+'ms)'}else{'FAIL: providers missing status object'}}catch{'FAIL: '+$_.Exception.Message}"') do set R11=%%r
if "!R11:~0,4!"=="PASS" ( echo    [PASS] !R11! & set /a PASS+=1 ) else ( echo    [FAIL] !R11! & set /a FAIL+=1 )

:: ── T12: Models include pricing field ────────────────────────
echo  [T12] Models have pricing field...
for /f "delims=" %%r in ('powershell -NoProfile -Command "try{$m=Invoke-RestMethod '%PROXY%/listAvailableModels' -TimeoutSec 5;$first=$m.models[0];if($first.pricing -and $first.pricing.prompt -ne $null){'PASS: pricing present (prompt='+$first.pricing.prompt+')'}else{'FAIL: missing pricing field'}}catch{'FAIL: '+$_.Exception.Message}"') do set R12=%%r
if "!R12:~0,4!"=="PASS" ( echo    [PASS] !R12! & set /a PASS+=1 ) else ( echo    [FAIL] !R12! & set /a FAIL+=1 )

:: ── Summary ───────────────────────────────────────────────────
echo.
echo  ============================================================
set /a TOTAL=%PASS%+%FAIL%
echo    Results: %PASS%/%TOTAL% passed
if %FAIL% GTR 0 (
    echo    Status : SOME TESTS FAILED
) else (
    echo    Status : ALL TESTS PASSED
)
echo  ============================================================
echo.
pause
endlocal