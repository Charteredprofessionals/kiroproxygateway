/**
 * src/resilience/key_rotator.js - Multi-provider API key rotator & fallback
 * Pure CommonJS exportable module
 */

'use strict';

const providerCurrentKeyIndex = {
  kilo: 0,
  cline: 0,
  openrouter: 0,
  orcarouter: 0,
  gemini: 0
};

const providerKeyFailures = {
  kilo: {},
  cline: {},
  openrouter: {},
  orcarouter: {},
  gemini: {}
};

/**
 * Get current active key for a provider
 * @param {string} provider - Provider name
 * @param {Object} cfg - Current config object
 * @returns {string|null}
 */
function getProviderKey(provider, cfg) {
  const arrayKey = `${provider}ApiKeys`;
  const keys = cfg[arrayKey] || [];
  
  if (!keys || keys.length === 0) return null;
  
  const idx = providerCurrentKeyIndex[provider] || 0;
  return keys[Math.min(idx, keys.length - 1)];
}

/**
 * Rotate to next available key on failure (401 / 429)
 * @param {string} provider - Provider name
 * @param {Object} cfg - Current config object
 * @returns {boolean} True if rotated, false if no more keys available
 */
function rotateProviderKey(provider, cfg) {
  const arrayKey = `${provider}ApiKeys`;
  const keys = cfg[arrayKey] || [];
  
  if (!keys || keys.length <= 1) return false;
  
  const currentIdx = providerCurrentKeyIndex[provider] || 0;
  if (currentIdx < keys.length - 1) {
    providerCurrentKeyIndex[provider] = currentIdx + 1;
    console.log(`[KiroProxy] Rotating ${provider} to fallback key ${providerCurrentKeyIndex[provider] + 1}/${keys.length}`);
    return true;
  }
  
  return false;
}

module.exports = {
  providerCurrentKeyIndex,
  providerKeyFailures,
  getProviderKey,
  rotateProviderKey
};
