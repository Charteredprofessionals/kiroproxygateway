# Changelog Migration Note

**Date:** 2026-10-08

## Situation

Two different changelogs were found during workspace organization:

1. **Root `CHANGELOG.md`** (now `CHANGELOG_ROOT.md`)
   - Format: Keep a Changelog standard
   - Focus: v2.7.0 release
   - Entries: High-level feature additions (Gemini auto-population, tool translation)

2. **`docs/updates/CHANGELOG.md`** (existing)
   - Format: Custom emoji-rich format
   - Focus: v2.7.1 rebranding + fallback sequence
   - Entries: Detailed technical changes (patches, routing, bridge isolation)

## Decision

**Keep both** - they document different aspects:
- `CHANGELOG_ROOT.md` → Keep in root as canonical release changelog
- `docs/updates/CHANGELOG.md` → Keep as detailed technical changelog

## Action Items

1. Merge both into single comprehensive changelog (future task)
2. Establish single source of truth for version history
3. Document which changelog format to follow for future releases

## References

- Keep a Changelog: https://keepachangelog.com/
- Semantic Versioning: https://semver.org/
