/**
 * src/resilience/errors.js - Structured ProxyError class
 * Pure CommonJS exportable module
 */

'use strict';

class ProxyError extends Error {
  constructor(code, message, remediation = '', context = {}) {
    super(message);
    this.name = 'ProxyError';
    this.code = code;
    this.remediation = remediation;
    this.context = context;
  }

  toJSON() {
    return {
      error: {
        code: this.code,
        message: this.message,
        remediation: this.remediation,
        context: this.context
      }
    };
  }
}

module.exports = {
  ProxyError
};
