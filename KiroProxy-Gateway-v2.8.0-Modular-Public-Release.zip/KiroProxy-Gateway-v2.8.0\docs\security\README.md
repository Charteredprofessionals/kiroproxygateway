# Security Documentation

This section contains security policies and guidelines.

## 📄 Available Documents

- **[Security Policy](SECURITY.md)** - Security policies and reporting

## 🎯 Purpose

These documents describe security practices, vulnerability reporting, and compliance information for the KiroProxy Gateway.

---

**Part of KiroProxy Gateway Documentation**