/**
 * src/protocol/smithy_parser.js - AWS Bedrock Smithy request payload & context parser
 * Pure CommonJS exportable module
 */

'use strict';

/**
 * Extract text from string or structured content array
 */
function extractTextFromContent(c) {
  if (!c) return '';
  if (typeof c === 'string') return c;
  if (Array.isArray(c)) {
    return c.map(x => x.text || (typeof x === 'string' ? x : JSON.stringify(x))).join('\n');
  }
  return JSON.stringify(c);
}

/**
 * Extract tool execution results from userInputMessageContext
 */
function extractToolResults(ctx) {
  if (!ctx || !Array.isArray(ctx.toolResults)) return '';
  let res = '';
  for (const tr of ctx.toolResults) {
    const text = extractTextFromContent(tr.content);
    const toolName = tr.toolName || tr.name || tr.toolUseId || 'tool';
    const status = tr.status || 'success';
    res += `\n[Tool Result (${toolName}): status=${status}]\n${text}\n`;
  }
  return res;
}

/**
 * Extract Kiro IDE tool definitions from all Smithy & Bedrock payload paths:
 * 1. body.conversationState.currentMessage.userInputMessage.userInputMessageContext.tools
 * 2. body.toolConfiguration.tools
 * 3. body.tools
 * 4. body.conversationState.history[i].userInputMessage.userInputMessageContext.tools
 */
function extractKiroToolsFromPayload(body) {
  if (!body || typeof body !== 'object') return [];
  const cs = body.conversationState;
  const currentCtxTools = cs?.currentMessage?.userInputMessage?.userInputMessageContext?.tools;
  if (Array.isArray(currentCtxTools) && currentCtxTools.length > 0) {
    return currentCtxTools;
  }
  if (Array.isArray(body.toolConfiguration?.tools) && body.toolConfiguration.tools.length > 0) {
    return body.toolConfiguration.tools;
  }
  if (Array.isArray(body.tools) && body.tools.length > 0) {
    return body.tools;
  }
  if (Array.isArray(cs?.history)) {
    for (let i = cs.history.length - 1; i >= 0; i--) {
      const hTools = cs.history[i]?.userInputMessage?.userInputMessageContext?.tools;
      if (Array.isArray(hTools) && hTools.length > 0) {
        return hTools;
      }
    }
  }
  return [];
}

/**
 * Extract rich workspace context from Kiro IDE's Smithy UserInputMessageContext
 */
function extractWorkspaceContext(ctx, includeEnvAndEditor = false) {
  if (!ctx || typeof ctx !== 'object') return '';
  const parts = [];

  if (includeEnvAndEditor) {
    const envLines = [];
    if (ctx.envState) {
      if (ctx.envState.operatingSystem) envLines.push(`OS: ${ctx.envState.operatingSystem}`);
      if (ctx.envState.currentWorkingDirectory) envLines.push(`Working Directory: ${ctx.envState.currentWorkingDirectory}`);
    }
    if (ctx.editorState) {
      if (Array.isArray(ctx.editorState.workspaceFolders) && ctx.editorState.workspaceFolders.length > 0) {
        envLines.push(`Workspace Folders: ${ctx.editorState.workspaceFolders.join(', ')}`);
      }
      if (ctx.editorState.document?.relativeFilePath) {
        const doc = ctx.editorState.document;
        envLines.push(`Active Open File: ${doc.relativeFilePath}`);
        if (typeof doc.text === 'string' && doc.text.trim().length > 0) {
          const snippet = doc.text.length > 4000 ? doc.text.slice(0, 4000) + '\n...[truncated]' : doc.text;
          envLines.push(`Active File Content (${doc.relativeFilePath}):\n\`\`\`\n${snippet}\n\`\`\``);
        }
      }
    }
    if (envLines.length > 0) {
      parts.push(`\n[Workspace Environment]\n${envLines.join('\n')}\n`);
    }
  }

  if (Array.isArray(ctx.additionalContext) && ctx.additionalContext.length > 0) {
    for (const ac of ctx.additionalContext) {
      if (!ac) continue;
      const name = ac.name || 'context';
      const desc = ac.description ? ` (${ac.description})` : '';
      const inner = typeof ac.innerContext === 'string'
        ? ac.innerContext
        : (ac.innerContext ? JSON.stringify(ac.innerContext) : '');
      if (inner.trim()) {
        const clipped = inner.length > 6000 ? inner.slice(0, 6000) + '\n...[truncated]' : inner;
        parts.push(`\n[Additional Context: ${name}${desc}]\n${clipped}\n`);
      }
    }
  }

  return parts.join('');
}

function extractToolMetadata(tool) {
  if (!tool || typeof tool !== 'object') {
    return { name: 'unknown', description: '', schema: { type: 'object', properties: {} } };
  }
  const spec = tool.toolSpecification || tool.toolSpec || tool.function || tool;
  const name = spec.name || tool.name || 'unknown';
  const description = spec.description || tool.description || '';
  
  let rawSchema = spec.parameters || spec.input_schema || spec.inputSchema || tool.parameters || tool.input_schema || tool.inputSchema || {};
  while (rawSchema && typeof rawSchema === 'object' && rawSchema.json && typeof rawSchema.json === 'object') {
    rawSchema = rawSchema.json;
  }
  if (!rawSchema || typeof rawSchema !== 'object' || Array.isArray(rawSchema)) {
    rawSchema = { type: 'object', properties: {} };
  }
  return { name, description, schema: rawSchema };
}

/**
 * Extract messages array from Kiro conversationState and system prompt
 */
function extractMessagesFromKiroPayload(body, requestedModel = '') {
  const messages = [];
  const cs = body.conversationState;

  const isNgrokPath = requestedModel.startsWith('ngrok-') || requestedModel === 'ngrok-gemini-flash';
  const kiroTools = extractKiroToolsFromPayload(body);

  let combinedSystemPrompt = body.systemPrompt || '';
  if (isNgrokPath) {
    if (kiroTools.length > 0) {
      const compactToolGuide = 'When invoking tools, respond ONLY with a JSON block: {"tool": "<name>", "arguments": {...}}. Never send empty arguments.';
      combinedSystemPrompt = (combinedSystemPrompt ? combinedSystemPrompt + '\n\n' : '') + compactToolGuide;
      if (combinedSystemPrompt.length > 250) {
        combinedSystemPrompt = combinedSystemPrompt.slice(0, 250);
      }
    }
  } else {
    // Core Kiro IDE Development Agent System Prompt
    const coreToolNames = new Set([
      'fs_write', 'str_replace', 'read_file', 'list_directory', 'grep_search',
      'file_search', 'execute_pwsh', 'invoke_sub_agent', 'validate_spec_format',
      'task_list', 'task_update', 'task_get'
    ]);
    let dynamicToolsSection = '';
    if (kiroTools.length > 0) {
      const extraLines = [];
      for (const rawTool of kiroTools) {
        const { name, description, schema } = extractToolMetadata(rawTool);
        if (name && name !== 'unknown' && !coreToolNames.has(name)) {
          const propKeys = schema?.properties ? Object.keys(schema.properties).join(', ') : '';
          extraLines.push(`- ${name}: ${description || 'Workspace/MCP tool'}${propKeys ? `. Arguments: {${propKeys}}` : ''}`);
        }
      }
      if (extraLines.length > 0) {
        dynamicToolsSection = '\n' + extraLines.join('\n');
      }
    }

    const toolGuide = `You are an autonomous software engineering agent operating natively inside Kiro IDE. Do NOT act like a passive chatbot — proactively inspect files, write code, run commands, and execute tasks using your workspace tools.

You have access to the following environment tools:
- fs_write: Write or create a file. Arguments: {"path": "path/to/file", "text": "full content"}
- str_replace: Edit an existing file by replacing text. Arguments: {"path": "path/to/file", "oldStr": "exact text to replace", "newStr": "replacement text"}
- read_file: Read file content. Arguments: {"path": "path/to/file"}
- list_directory: List files in a directory. Arguments: {"path": "path/to/dir"}
- grep_search: Search files with regex. Arguments: {"query": "regex"}
- file_search: Search files by name pattern. Arguments: {"query": "filename"}
- execute_pwsh: Execute PowerShell / terminal command. Arguments: {"command": "..."} (REQUIRED: non-empty command string)
- invoke_sub_agent: Run a specialized subagent. Arguments: {"name": "general-task-execution" or "context-gatherer", "prompt": "...", "explanation": "..."}
- validate_spec_format: Validate a spec document. Arguments: {"filePath": "path/to/requirements.md"}
- task_list: List tasks. Arguments: {"tasksFilePath": "path/to/tasks.md", "status": "ready"|"in_progress"|"completed"}
- task_update: Update task status. Arguments: {"tasksFilePath": "path/to/tasks.md", "taskId": "1", "status": "completed"}
- task_get: Inspect task details. Arguments: {"tasksFilePath": "path/to/tasks.md", "taskId": "1"}${dynamicToolsSection}

To call a tool, you MUST use: <|tool_call>call:TOOL_NAME{ARGS}<tool_call|>
(Or invoke the tool via native function calling with valid JSON arguments. Never send empty arguments.)

KIRO NATIVE 3-SPEC METHOD (Spec-Driven Development):
When the user asks to create a specification or use the 3-spec method:
1. Always create the directory: .kiro/specs/<feature-name>/
2. Step 1 (Requirements): Write .kiro/specs/<feature-name>/requirements.md
   - Document user stories, acceptance criteria, non-functional requirements.
   - Run validate_spec_format { "filePath": ".kiro/specs/<feature-name>/requirements.md" }
3. Step 2 (Design): Write .kiro/specs/<feature-name>/design.md
   - Document architecture, component changes, data models, error handling.
   - Run validate_spec_format { "filePath": ".kiro/specs/<feature-name>/design.md" }
4. Step 3 (Tasks): Write .kiro/specs/<feature-name>/tasks.md
   - Create the task checklist using standard markdown:
     - [ ] 1. Task Name
       Description of changes, files to touch, and verification test.
   - Run validate_spec_format { "filePath": ".kiro/specs/<feature-name>/tasks.md" }
   - This activates Kiro's interactive Task Runner in the IDE UI!

DOCUMENTATION & MARKDOWN STANDARD:
When writing markdown specifications, bug fixes, architecture proposals, or reports, follow Native Kiro Executive Format:
1. Executive Header Block (Title, Date, Status Badge, Build Status)
2. Root Cause / Architecture Overview
3. Itemized Fixes / Changes (Problem/Context, Solution code snippet, Result)
4. Verification Results (Commands, 0 errors, pass counts)
5. Impact Summary (Before vs After)
6. Testing Checklist (Task list with - [ ] checkboxes)
7. Technical Notes
8. Executive Sign-Off table`;

    combinedSystemPrompt = (combinedSystemPrompt ? combinedSystemPrompt + '\n\n' : '') + toolGuide;
  }
  if (combinedSystemPrompt) messages.push({ role: 'system', content: combinedSystemPrompt });

  if (cs) {
    if (Array.isArray(cs.history)) {
      for (const item of cs.history) {
        if (item.userInputMessage) {
          let text = extractTextFromContent(item.userInputMessage.content);
          if (!isNgrokPath) {
            text += extractWorkspaceContext(item.userInputMessage.userInputMessageContext, false);
          }
          text += extractToolResults(item.userInputMessage.userInputMessageContext);
          if (text.trim()) messages.push({ role: 'user', content: text.trim() });
        } else if (item.assistantResponseMessage) {
          let text = extractTextFromContent(item.assistantResponseMessage.content);
          if (Array.isArray(item.assistantResponseMessage.toolUses)) {
            for (const tu of item.assistantResponseMessage.toolUses) {
              const inp = typeof tu.input === 'string' ? tu.input : JSON.stringify(tu.input || {});
              text += `\n<|tool_call>call:${tu.name}${inp}<tool_call|>\n`;
            }
          }
          if (text.trim()) messages.push({ role: 'assistant', content: text.trim() });
        }
      }
    }

    if (cs.currentMessage?.userInputMessage) {
      let text = extractTextFromContent(cs.currentMessage.userInputMessage.content);
      if (!isNgrokPath) {
        text += extractWorkspaceContext(cs.currentMessage.userInputMessage.userInputMessageContext, true);
      }
      text += extractToolResults(cs.currentMessage.userInputMessage.userInputMessageContext);
      if (text.trim()) messages.push({ role: 'user', content: text.trim() });
    }
  }

  if (messages.length === 0 && Array.isArray(body.prompt)) {
    const text = body.prompt.map(p => p.text || '').join('\n');
    if (text) messages.push({ role: 'user', content: text });
  }

  if (messages.length === 0) {
    messages.push({ role: 'user', content: 'Hello' });
  }

  return messages;
}

const MAX_BODY_SIZE = 10 * 1024 * 1024; // 10MB limit
const BODY_TIMEOUT = 30000; // 30s timeout

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    
    const timeout = setTimeout(() => {
      req.destroy();
      reject(new Error('Request body timeout after 30s'));
    }, BODY_TIMEOUT);
    
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY_SIZE) {
        clearTimeout(timeout);
        req.destroy();
        reject(new Error(`Request body exceeds ${MAX_BODY_SIZE} bytes limit`));
        return;
      }
      chunks.push(chunk);
    });
    
    req.on('end', () => {
      clearTimeout(timeout);
      try {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf-8'));
        resolve(body);
      } catch (e) {
        reject(new Error(`Invalid JSON in request body: ${e.message}`));
      }
    });
    
    req.on('error', (err) => {
      clearTimeout(timeout);
      reject(new Error(`Request error: ${err.message}`));
    });
  });
}

function sendAwsResponse(res, statusCode, body, reqId, extraHeaders = {}) {
  const payload = typeof body === 'string' ? body : JSON.stringify(body);
  const defaultHeaders = {
    'Content-Type': 'application/x-amz-json-1.1',
    'x-amzn-requestid': reqId || ('req_' + Date.now()),
    'x-amzn-kiro-profile-arn': 'arn:aws:kiro:us-east-1:123456789012:profile/default',
    'x-amzn-kiro-ratelimit-retry-after': '0',
    'Date': new Date().toUTCString(),
    'Server': 'Amazon.com',
    'Connection': 'keep-alive',
    ...extraHeaders
  };
  res.writeHead(statusCode, defaultHeaders);
  res.end(payload);
}

function sendAwsError(res, statusCode, errorType, message, reqId) {
  sendAwsResponse(res, statusCode, {
    __type: `com.amazon.kiro.runtimeservice#${errorType}`,
    message: message
  }, reqId, {
    'x-amzn-errortype': errorType
  });
}

module.exports = {
  extractTextFromContent,
  extractToolResults,
  extractKiroToolsFromPayload,
  extractWorkspaceContext,
  extractToolMetadata,
  extractMessagesFromKiroPayload,
  readBody,
  sendAwsResponse,
  sendAwsError
};
