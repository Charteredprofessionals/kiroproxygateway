# KiroProxy Gateway — Documentation Index

**Version:** 2.8.0  
**Last Updated:** October 10, 2026  
**Status:** ✅ Production Ready

---

## 📖 Getting Started

| Document | Purpose | Status |
|----------|---------|--------|
| **[README.md](../README.md)** | Main project overview & quick start | ✅ Updated |
| **[AGENTS.md](../AGENTS.md)** | AI agent quick reference | ✅ Updated |
| **[QUICK_START_v2.md](guides/QUICK_START_v2.md)** | 5-minute setup guide | ✅ Updated |
| **[CONFIGURATION_GUI.md](../CONFIGURATION_GUI.md)** | Configuration setup | ✅ Updated |

---

## 🏗️ Architecture

| Document | Purpose | Status |
|----------|---------|--------|
| **[AUTO_FALLBACK_SYSTEM.md](architecture/AUTO_FALLBACK_SYSTEM.md)** | Dual-layer smart fallback (Otomode + Global Automode + AUTO) | ✅ Updated v2.8.0 |
| **[KIRO_GATEWAY_ARCHITECTURE_GUIDE.md](architecture/KIRO_GATEWAY_ARCHITECTURE_GUIDE.md)** | System design & components | ✅ Updated |
| **[SYSTEM_MAP.md](ai-maintenance/system-map.md)** | Architecture diagram & module responsibilities | ✅ Updated |
| **[RISK_MITIGATION_ROADMAP.md](architecture/RISK_MITIGATION_ROADMAP.md)** | Refactoring plan for 4 risk areas | ✅ Updated |

---

## 🔧 AI Maintenance

| Document | Purpose | Status |
|----------|---------|--------|
| **[CHANGE_IMPACT.md](ai-maintenance/change-impact.md)** | If you change X, what else breaks? | ✅ Updated |
| **[INVARIANTS_AND_GOTCHAS.md](ai-maintenance/invariants-and-gotchas.md)** | Hard rules, global state, fragile areas | ✅ Updated |
| **[MULTI_TOOL_SUPPORT.md](ai-maintenance/MULTI_TOOL_SUPPORT.md)** | Multi-tool execution guide (8 formats) | ✅ Updated |
| **[API_CONTRACTS.md](ai-maintenance/api-contracts.md)** | Request/response formats | ✅ Updated |
| **[CONFIG_AND_ENV.md](ai-maintenance/config-and-env.md)** | All env vars & config fields | ✅ Updated |
| **[TESTING.md](ai-maintenance/testing.md)** | Test organization & coverage | ✅ Updated |
| **[TROUBLESHOOTING.md](ai-maintenance/troubleshooting.md)** | Symptom → cause → fix | ✅ Updated |
| **[OPEN_QUESTIONS.md](ai-maintenance/open-questions.md)** | Unknowns needing human confirmation | ✅ Updated |

---

## 🚀 Configuration & Deployment

| Document | Purpose | Status |
|----------|---------|--------|
| **[QUICK_START.md](setup/QUICK_START.md)** | Quick setup guide | ✅ Updated |
| **[KIRO_IDE_INTEGRATION.md](setup/KIRO_IDE_INTEGRATION.md)** | Kiro IDE integration guide | ✅ Updated |
| **[GEMINI_CANVAS_BRIDGE.md](setup/GEMINI_CANVAS_BRIDGE.md)** | Ngrok Canvas Bridge setup | ✅ Updated |

---

## 📊 Project Status

| Document | Purpose | Status |
|----------|---------|--------|
| **[PROJECT_FINALIZED.md](PROJECT_FINALIZED.md)** | Project completion & audit report | ✅ Updated v2.8.0 |
| **[PROJECT_STATUS_v2.8.0.md](../PROJECT_STATUS_v2.8.0.md)** | v2.8.0 status report | ✅ Updated |
| **[CHANGELOG.md](../CHANGELOG.md)** | Version history | ✅ Updated |
| **[RELEASE_NOTES.md](../RELEASE_NOTES.md)** | Release details | ✅ Updated |

---

## 🧪 Testing

| Document | Purpose | Status |
|----------|---------|--------|
| **[TEST_READY.md](../TEST_READY.md)** | Test coverage & readiness | ✅ Updated |
| **[TEST_INFRA.md](../TEST_INFRA.md)** | Test infrastructure | ✅ Updated |

---

## 🔒 Security & Compliance

| Document | Purpose | Status |
|----------|---------|--------|
| **[SECURITY.md](../SECURITY.md)** | Security best practices | ✅ Updated |
| **[CONTRIBUTING.md](../CONTRIBUTING.md)** | Contribution guidelines | ✅ Updated |

---

## 🐛 Known Issues

### P0 (Critical) - All Fixed ✅
- ✅ Otomode array exhaustion (v2.8.0)
- ✅ Unprotected array access (v2.8.0)
- ✅ Queue race conditions (v2.8.0)
- ✅ Memory leaks (v2.8.0)
- ✅ Silent failures (v2.8.0)

### P1 (Medium Priority) - 6 Remaining
- Missing API key fallback
- Unprotected Map access
- Rate limit false negatives
- Unhandled stream errors
- Missing upstream validation
- Hardcoded model override

### P2 (Technical Debt) - 4 Remaining
- Global state mutation
- Incomplete error context
- Duplicate model handling
- Health check race conditions

---

## 📊 Statistics

| Metric | Value |
|--------|-------|
| **Version** | 2.8.0 |
| **Models** | 193 free models |
| **Providers** | 9 (7 official + 2 custom) |
| **Tests** | 80+ passing |
| **Documentation Files** | 30+ |
| **Last Updated** | October 10, 2026 |

---

## 🎯 Quick Links

- **[Main README](../README.md)** - Start here!
- **[Documentation Index](README.md)** - All documentation
- **[Architecture Guide](architecture/KIRO_GATEWAY_ARCHITECTURE_GUIDE.md)** - System design
- **[Troubleshooting](ai-maintenance/troubleshooting.md)** - Debug guide
- **[CHANGELOG](../CHANGELOG.md)** - Version history

---

**Built with ❤️ for the Kiro IDE community**
