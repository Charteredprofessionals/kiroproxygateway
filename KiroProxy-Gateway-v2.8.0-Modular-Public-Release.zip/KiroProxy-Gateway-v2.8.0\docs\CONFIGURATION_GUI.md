# Configuration GUI - Quick Start Guide

## 🚀 Accessing the GUI

Open your browser and navigate to:
```
http://localhost:8084/config
```

> **Note:** Server must be running first. Start it with:
> ```bash
> node scripts/kiro_proxy_server.js
> # OR
> npm start
> # OR
> scripts\batch\launch.bat
> ```

---

## 📖 Features Overview

### 1️⃣ Overview Dashboard
**View at a glance:**
- Total API keys configured
- Active providers count
- Custom providers count
- Real-time provider health status

### 2️⃣ API Keys Management
**Add multiple API keys for automatic rotation:**

#### Kilo Gateway
```
Get your key from: https://api.kilo.ai
Format: sk-kilo-xxxxxxxxxxxxxxxx
```

#### Cline API
```
Get your key from: https://api.cline.bot
Format: cline-xxxxxxxxxxxxxxxx
```

#### OpenRouter
```
Get your key from: https://openrouter.ai/keys
Format: sk-or-v1-xxxxxxxxxxxxxxxx
```

#### OrcaRouter
```
Get your key from: https://api.orcarouter.ai
Format: orca-xxxxxxxxxxxxxxxx
```

#### Google Gemini
```
Get your key from: https://makersuite.google.com/app/apikey
Format: AIzaSy-xxxxxxxxxxxxxxxx
```

**How to add a key:**
1. Navigate to "🔑 API Keys" tab
2. Enter your API key in the input field
3. Click "➕ Add Key"
4. Key is immediately saved and available for rotation

**Benefits of multiple keys:**
- Automatic rotation on rate limits
- Higher combined throughput
- Failover protection
- No manual switching needed

### 3️⃣ Custom AI Providers
**Integrate ANY OpenAI-compatible API:**

#### Supported Providers
- Groq
- Together AI
- Ollama (local)
- DeepSeek
- Fireworks AI
- Perplexity
- Any OpenAI-compatible endpoint

#### Example: Adding Groq

1. Navigate to "⚙️ Custom Providers" tab
2. Fill in the form:
   ```
   Provider Name: Groq
   Base URL: https://api.groq.com/openai/v1
   API Key: gsk_xxxxxxxxxxxxx
   Default Model ID: llama-3.3-70b-versatile
   Priority: High
   ```
3. Click "➕ Add Custom Provider"

#### Example: Adding Ollama (Local)

```
Provider Name: Ollama Local
Base URL: http://localhost:11434/v1
API Key: ollama
Default Model ID: llama3.2
Priority: Medium
```

#### Priority Levels
- **High:** Tried first in AUTO mode
- **Medium:** Tried after high-priority providers
- **Low:** Tried last (backup providers)

### 4️⃣ Provider Health Monitoring
**Real-time status of all providers:**

- 🟢 **Healthy:** Provider responding normally
- 🔴 **Unhealthy:** Provider down or timing out
- **Latency:** Response time in milliseconds

Updates automatically every 30 seconds.

### 5️⃣ Export & Import Configuration

#### Export Configuration
1. Navigate to "💾 Export/Import" tab
2. Click "⬇️ Download Configuration"
3. Saves as: `kiro-gateway-config-YYYY-MM-DD.json`

**What's included:**
- All API keys (all providers)
- Custom provider configurations
- Settings and preferences

#### Import Configuration
1. Navigate to "💾 Export/Import" tab
2. Click "Choose File" and select a `.json` config file
3. Click "⬆️ Import Configuration"
4. Configuration is merged with existing setup

**Use cases:**
- Backup your configuration
- Share setup between machines
- Restore after reinstall
- Team configuration sharing

---

## 🎯 Common Workflows

### Adding Your First API Key

```
1. Start the server: npm start
2. Open GUI: http://localhost:8084/config
3. Go to "🔑 API Keys" tab
4. Select a provider (e.g., Kilo Gateway)
5. Paste your API key
6. Click "➕ Add Key"
7. Done! Key is active immediately
```

### Setting Up Multi-Key Rotation

```
1. Add multiple keys for same provider:
   - Add Kilo key #1
   - Add Kilo key #2
   - Add Kilo key #3

2. Gateway automatically rotates on:
   - Rate limit errors (429)
   - Authentication failures (401)
   - Timeout errors

3. Monitor rotation in server logs:
   [KiroProxy] Rotating to next Kilo key (index 1 → 2)
```

### Integrating Custom Provider

```
Example: Adding DeepSeek

1. Get API key from DeepSeek
2. Open GUI: http://localhost:8084/config
3. Go to "⚙️ Custom Providers" tab
4. Fill in:
   Name: DeepSeek
   Base URL: https://api.deepseek.com/v1
   API Key: sk-xxxxxx
   Model: deepseek-chat
   Priority: High
5. Click "➕ Add Custom Provider"
6. Provider appears in list
7. Test: Send a request using model "deepseek-chat"
```

### Backup & Restore

```
Backup:
1. Open GUI → Export/Import tab
2. Click "⬇️ Download Configuration"
3. Save file to secure location

Restore:
1. Open GUI → Export/Import tab
2. Click "Choose File"
3. Select your backup file
4. Click "⬆️ Import Configuration"
5. All keys and providers restored
```

---

## 📁 Configuration File Location

Configuration is stored at:
```
~/.kiro/kiro_ai_config.json
```

**Windows:** `C:\Users\YourName\.kiro\kiro_ai_config.json`
**Linux/Mac:** `/home/yourname/.kiro/kiro_ai_config.json`

### Manual Editing (Advanced)

You can manually edit this file:

```json
{
  "kiloApiKeys": [
    "sk-kilo-key1",
    "sk-kilo-key2"
  ],
  "clineApiKeys": [
    "cline-key1"
  ],
  "openrouterApiKeys": [],
  "orcarouterApiKeys": [
    "orca-key1"
  ],
  "geminiApiKeys": [],
  "customProviders": [
    {
      "name": "Groq",
      "baseUrl": "https://api.groq.com/openai/v1",
      "apiKey": "gsk_xxxxx",
      "defaultModel": "llama-3.3-70b-versatile",
      "priority": "high",
      "enabled": true
    }
  ]
}
```

> **Warning:** Server must be restarted after manual edits.

---

## 🔐 Security Best Practices

### API Key Security
- ✅ Keys stored locally in `~/.kiro/`
- ✅ Keys masked in GUI (only shows first 8 + last 4 chars)
- ✅ No keys sent to external servers
- ⚠️ Exported config contains full keys - secure your exports!

### Recommendations
1. **Don't share exports** containing API keys
2. **Backup exports** to encrypted storage
3. **Use environment variables** for CI/CD
4. **Rotate keys regularly**
5. **Monitor usage** via provider dashboards

---

## 🐛 Troubleshooting

### GUI Won't Load
```
Problem: http://localhost:8084/config shows "Can't reach page"
Solution: 
1. Check if server is running:
   curl http://localhost:8084/health
2. Start server if needed:
   npm start
3. Check port 8084 isn't blocked by firewall
```

### Keys Not Saving
```
Problem: Added key but it disappears after reload
Solution:
1. Check file permissions on ~/.kiro/
2. Ensure directory exists:
   mkdir -p ~/.kiro
3. Check server logs for errors
```

### Provider Shows Unhealthy
```
Problem: Provider marked red in health monitoring
Solution:
1. Check API key is valid
2. Verify provider endpoint is accessible:
   curl https://api.provider.com/health
3. Check network/firewall settings
4. Review server logs for error details
```

### Custom Provider Not Working
```
Problem: Custom provider added but not responding
Solution:
1. Verify Base URL format:
   ✅ https://api.example.com/v1
   ❌ https://api.example.com/v1/
   ❌ https://api.example.com
2. Test endpoint directly:
   curl https://api.example.com/v1/models \
     -H "Authorization: Bearer YOUR_KEY"
3. Check model ID is correct
4. Enable provider if disabled
```

---

## 🎨 GUI Screenshots

### Overview Dashboard
Shows real-time statistics and provider health monitoring.

### API Keys Tab
Individual sections for each provider with add/remove functionality.

### Custom Providers Tab
Form for adding custom OpenAI-compatible providers with priority control.

### Export/Import Tab
Download and upload configuration with live preview.

---

## 📞 Support

### Getting Help
- Check server logs: `tail -f logs/server.log`
- Review health endpoint: `curl http://localhost:8084/health`
- Test model listing: `curl http://localhost:8084/listAvailableModels`

### Common Issues
- **Port already in use:** Change PORT in `.env` file
- **Config not persisting:** Check `~/.kiro/` permissions
- **Keys not rotating:** Ensure multiple keys added for same provider

---

## 🚀 Advanced Features

### Environment Variables
Override config file with environment variables:
```bash
export KILO_API_KEY="sk-kilo-xxxxx"
export CLINE_API_KEY="cline-xxxxx"
export PORT=8084
```

### API Integration
Use the configuration API programmatically:

```javascript
// GET current config
const config = await fetch('http://localhost:8084/api/config').then(r => r.json());

// POST new config
await fetch('http://localhost:8084/api/config', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    kiloApiKeys: ['sk-kilo-key1', 'sk-kilo-key2'],
    customProviders: [...]
  })
});
```

### Automation Scripts
```powershell
# Backup configuration daily
$config = Invoke-RestMethod 'http://localhost:8084/api/config'
$config | ConvertTo-Json | Out-File "backup-$(Get-Date -F yyyy-MM-dd).json"
```

---

## 📝 Changelog

### v2.7.0 (Current)
- ✨ Initial release of Configuration GUI
- ✨ Multi-key API management with rotation
- ✨ Custom provider addition
- ✨ Real-time health monitoring
- ✨ Export/Import functionality
- ✨ Provider priority system

---

## 🙏 Feedback

Found a bug? Have a feature request?
- Open an issue in the repository
- Check existing documentation
- Review server logs for details

---

**Happy configuring! 🎉**
