/**
 * tests/test_tool_translation_layer.js
 * Comprehensive unit audit verifying:
 * 1. Kiro IDE Smithy Tool extraction ({ toolSpecification: { name, description, inputSchema: { json: ... } } })
 * 2. AWS Bedrock toolSpec, Anthropic, and OpenAI function tool extraction
 * 3. Nested Smithy payload tool extraction (body.conversationState.currentMessage.userInputMessage.userInputMessageContext.tools)
 * 4. Balanced JSON brace extraction (PowerShell script blocks { $_... } and nested JS functions inside fs_write)
 * 5. Normal markdown code blocks do NOT trigger fake generated_file_1.js fs_write calls
 * 6. Salted SHA-256 GetFeatureConfiguration key computation ("kiro-feature-config-key-salt-3e9b1d7a")
 * 7. EventStream toolUseEvent input contract (MUST BE stringified JSON)
 */

'use strict';

const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

console.log('╔══════════════════════════════════════════════════════════════════╗');
console.log('║   KiroProxy AWS Smithy Protocol & Tool Translation Audit Suite   ║');
console.log('╚══════════════════════════════════════════════════════════════════╝\n');

// Pure CommonJS imports directly from modular src/ components
const {
  extractToolMetadata,
  extractBalancedJson,
  extractToolArguments,
  extractToolCallsFromResponse,
  stripToolBlocksFromText
} = require('../src/translators/tool_extractor');
const {
  sanitizeSchemaForUpstream,
  sanitizeJsonBackslashes
} = require('../src/translators/sanitizer');
const {
  translateToolsToUpstream
} = require('../src/translators/tool_translator');
const {
  extractTextFromContent,
  extractToolResults,
  extractKiroToolsFromPayload,
  extractWorkspaceContext,
  extractMessagesFromKiroPayload
} = require('../src/protocol/smithy_parser');

// 1. Test Kiro IDE Native Smithy toolSpecification extraction
console.log('[Test 1] Testing Kiro IDE Native Smithy toolSpecification extraction:');
const kiroSmithyTool = {
  toolSpecification: {
    name: 'execute_pwsh',
    description: 'Execute PowerShell command in workspace',
    inputSchema: {
      json: {
        type: 'object',
        properties: {
          command: { type: 'string', description: 'PowerShell command' }
        },
        required: ['command']
      }
    }
  }
};
const mSmithy = extractToolMetadata(kiroSmithyTool);
assert.strictEqual(mSmithy.name, 'execute_pwsh');
assert.strictEqual(mSmithy.schema.properties.command.type, 'string');
console.log('  ✅ Extracted Smithy toolSpecification: execute_pwsh with unwrapped .inputSchema.json');

const bedrockTool = {
  toolSpec: {
    name: 'execute_pwsh',
    description: 'Execute PowerShell command',
    inputSchema: {
      json: {
        type: 'object',
        properties: { command: { type: 'string' } },
        required: ['command']
      }
    }
  }
};
const mBedrock = extractToolMetadata(bedrockTool);
assert.strictEqual(mBedrock.name, 'execute_pwsh');
assert.strictEqual(mBedrock.schema.properties.command.type, 'string');
console.log('  ✅ Extracted Bedrock toolSpec: execute_pwsh with schema');

const anthropicTool = {
  name: 'str_replace',
  description: 'Replace text in file',
  input_schema: {
    type: 'object',
    properties: { path: { type: 'string' }, oldStr: { type: 'string' }, newStr: { type: 'string' } },
    required: ['path', 'oldStr', 'newStr']
  }
};
const mAnthropic = extractToolMetadata(anthropicTool);
assert.strictEqual(mAnthropic.name, 'str_replace');
assert.strictEqual(mAnthropic.schema.properties.oldStr.type, 'string');
console.log('  ✅ Extracted Anthropic tool: str_replace with schema');

const openAiTool = {
  type: 'function',
  function: {
    name: 'read_file',
    description: 'Read file contents',
    parameters: {
      type: 'object',
      properties: { path: { type: 'string' } },
      required: ['path']
    }
  }
};
const mOpenAi = extractToolMetadata(openAiTool);
assert.strictEqual(mOpenAi.name, 'read_file');
assert.strictEqual(mOpenAi.schema.properties.path.type, 'string');
console.log('  ✅ Extracted OpenAI tool: read_file with schema');

// 2. Test Nested Smithy Payload Tool Extraction (userInputMessageContext.tools)
console.log('[Test 2] Testing Kiro IDE GenerateAssistantResponseRequest payload tool extraction:');
const kiroRequestPayload = {
  conversationState: {
    conversationId: 'conv_test_001',
    history: [],
    currentMessage: {
      userInputMessage: {
        content: 'Create a new Express server in src/server.js',
        modelId: 'kilo-auto-free',
        userInputMessageContext: {
          envState: {
            operatingSystem: 'windows',
            currentWorkingDirectory: 'd:\\sdlc_studio\\projects\\kiro-integration'
          },
          editorState: {
            workspaceFolders: ['d:\\sdlc_studio\\projects\\kiro-integration'],
            document: {
              relativeFilePath: 'package.json',
              text: '{"name": "kiro-integration"}'
            }
          },
          additionalContext: [
            {
              name: 'product.md',
              description: 'Steering file',
              innerContext: 'Always write modular Node.js code.'
            }
          ],
          tools: [kiroSmithyTool]
        }
      }
    }
  },
  systemPrompt: 'Native Kiro System Prompt'
};

const extractedTools = extractKiroToolsFromPayload(kiroRequestPayload);
assert.strictEqual(extractedTools.length, 1);
assert.strictEqual(extractedTools[0].toolSpecification.name, 'execute_pwsh');
const upstreamOpenAiTools = translateToolsToUpstream(extractedTools, 'openai');
assert.strictEqual(upstreamOpenAiTools[0].type, 'function');
assert.strictEqual(upstreamOpenAiTools[0].function.name, 'execute_pwsh');
assert.strictEqual(upstreamOpenAiTools[0].function.parameters.properties.command.type, 'string');
console.log('  ✅ Extracted tools from userInputMessageContext.tools and translated to OpenAI function schema');

// 3. Test System Prompt & Workspace Context Extraction
console.log('[Test 3] Testing Kiro Agent System Prompt, 3-Spec Method & Workspace Context injection:');
const extractedMsgs = extractMessagesFromKiroPayload(kiroRequestPayload, 'kilo-auto-free');
assert.strictEqual(extractedMsgs[0].role, 'system');
assert(extractedMsgs[0].content.includes('KIRO NATIVE 3-SPEC METHOD'), 'Must include 3-Spec Method');
assert(extractedMsgs[0].content.includes('validate_spec_format'), 'Must include validate_spec_format tool');
assert(extractedMsgs[0].content.includes('invoke_sub_agent'), 'Must include invoke_sub_agent tool');
assert.strictEqual(extractedMsgs[1].role, 'user');
assert(extractedMsgs[1].content.includes('Working Directory: d:\\sdlc_studio\\projects\\kiro-integration'), 'Must include envState working directory');
assert(extractedMsgs[1].content.includes('Active Open File: package.json'), 'Must include editorState active file');
assert(extractedMsgs[1].content.includes('Always write modular Node.js code.'), 'Must include additionalContext steering content');
console.log('  ✅ System prompt includes 12 Kiro tools + 3-Spec Method + Workspace envState/editorState/additionalContext');

// 4. Test Balanced JSON Extraction on PowerShell script blocks and nested JS code
console.log('[Test 4] Testing balanced JSON extraction for nested braces in tool calls:');
const nestedPwshResponse = `I will inspect running node processes now.\n<|tool_call>call:execute_pwsh{"command": "Get-Process | Where-Object { $_.ProcessName -eq 'node' } | Select-Object Id, ProcessName"}<tool_call|>`;
const detectedPwsh = extractToolCallsFromResponse(nestedPwshResponse, upstreamOpenAiTools);
assert.strictEqual(detectedPwsh.length, 1);
assert.strictEqual(detectedPwsh[0].name, 'execute_pwsh');
assert.strictEqual(
  detectedPwsh[0].args.command,
  "Get-Process | Where-Object { $_.ProcessName -eq 'node' } | Select-Object Id, ProcessName"
);
const strippedPwshText = stripToolBlocksFromText(nestedPwshResponse);
assert.strictEqual(strippedPwshText, 'I will inspect running node processes now.');
console.log('  ✅ Extracted PowerShell command with { $_.ProcessName } script block without truncation');

const nestedJsResponse = `Writing server file:\n<|tool_call>call:fs_write{"path": "src/app.js", "text": "function start() {\\n  const cfg = { port: 8080 };\\n  return cfg;\\n}"}<tool_call|>`;
const detectedJs = extractToolCallsFromResponse(nestedJsResponse, []);
assert.strictEqual(detectedJs.length, 1);
assert.strictEqual(detectedJs[0].name, 'fs_write');
assert.strictEqual(detectedJs[0].args.path, 'src/app.js');
assert(detectedJs[0].args.text.includes('const cfg = { port: 8080 };'));
console.log('  ✅ Extracted fs_write with nested JS object & function braces without truncation');

// 5. Test that normal markdown code snippets do NOT hijack into generated_file_1.js
console.log('[Test 5] Testing that explanatory markdown code blocks do NOT trigger fake fs_write:');
const explanationResponse = 'Here is an example of how to use Express:\n```js\nconst app = express();\n```\nLet me know if you want me to write this to a file.';
const detectedExplanation = extractToolCallsFromResponse(explanationResponse, upstreamOpenAiTools);
assert.strictEqual(detectedExplanation.length, 0, 'Explanatory code blocks must not create fake fs_write tool calls');
console.log('  ✅ Normal markdown code blocks are not hijacked into generated_file_1.js');

// 6. Test Salted SHA-256 GetFeatureConfiguration Key Contract
console.log('[Test 6] Testing ExperimentConfigService (vMi) salted SHA-256 feature flag key:');
const salt = 'kiro-feature-config-key-salt-3e9b1d7a';
const expectedSystemFieldHash = crypto.createHash('sha256').update(salt + 'system_field_injection').digest('hex');
assert.strictEqual(expectedSystemFieldHash.length, 64);
console.log(`  ✅ Salted SHA-256 key for system_field_injection: ${expectedSystemFieldHash.slice(0, 16)}...`);

// 7. Test Kiro IDE EventStream input contract (stringified JSON)
console.log('[Test 7] Testing Kiro IDE EventStream toolUseEvent stringified input contract:');
const eventPayload = {
  toolUseId: 'tool-123',
  name: 'execute_pwsh',
  input: JSON.stringify(detectedPwsh[0].args),
  stop: true
};
assert.strictEqual(typeof eventPayload.input, 'string');
assert.strictEqual(JSON.parse(eventPayload.input).command, detectedPwsh[0].args.command);
console.log('  ✅ EventStream toolUseEvent input is valid stringified JSON');

console.log('\n🎉 ALL 7 AWS SMITHY PROTOCOL & TOOL TRANSLATION AUDIT TESTS PASSED!\n');
