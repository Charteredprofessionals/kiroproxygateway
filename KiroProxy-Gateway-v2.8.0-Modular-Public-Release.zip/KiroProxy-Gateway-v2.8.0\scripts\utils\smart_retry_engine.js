/**
 * Smart Retry Engine with Cross-Provider Fallback
 * 
 * Replaces fragmented executeWithRetry logic with unified retry/fallback system:
 * - Exponential backoff with jitter
 * - Cross-provider fallback (not just intra-provider)
 * - Expanded retryable error classification
 * - Per-provider retry budgets
 * 
 * @module smart_retry_engine
 */

const RETRYABLE_ERRORS = [
  'TIMEOUT', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND', 'ECONNREFUSED',
  'RATE_LIMIT', 'quota', 'capacity', 'overloaded',
  '429', '500', '502', '503', '504'
];

const PROVIDER_RETRY_BUDGETS = {
  kilo: { maxAttempts: 3, maxTimeMs: 30000 },
  cline: { maxAttempts: 3, maxTimeMs: 30000 },
  openrouter: { maxAttempts: 3, maxTimeMs: 30000 },
  orcarouter: { maxAttempts: 3, maxTimeMs: 30000 },
  gemini: { maxAttempts: 3, maxTimeMs: 30000 },
  ngrok: { maxAttempts: 3, maxTimeMs: 45000 },
  custom: { maxAttempts: 2, maxTimeMs: 30000 }
};

/**
 * Calculate exponential backoff with jitter
 * @param {number} attempt - Current attempt number (1-indexed)
 * @param {boolean} isRateLimit - Whether error is rate limit
 * @returns {number} Delay in milliseconds
 */
function calculateBackoff(attempt, isRateLimit = false) {
  const baseDelay = isRateLimit ? 2000 : 1000;
  const maxDelay = isRateLimit ? 16000 : 8000;
  
  // Exponential backoff: baseDelay * 2^(attempt-1)
  const exponentialDelay = baseDelay * Math.pow(2, attempt - 1);
  
  // Cap at max delay
  const cappedDelay = Math.min(exponentialDelay, maxDelay);
  
  // Add jitter: ±20% randomization to prevent thundering herd
  const jitter = cappedDelay * 0.2 * (Math.random() * 2 - 1);
  
  return Math.floor(cappedDelay + jitter);
}

/**
 * Check if error is retryable
 * @param {Error} error - Error object
 * @returns {boolean} True if retryable
 */
function isRetryableError(error) {
  const errorStr = String(error.code || error.message || error.statusCode || '').toLowerCase();
  return RETRYABLE_ERRORS.some(code => errorStr.includes(String(code).toLowerCase()));
}

/**
 * Check if error is rate limit
 * @param {Error} error - Error object
 * @returns {boolean} True if rate limit
 */
function isRateLimitError(error) {
  const errorStr = String(error.code || error.message || error.statusCode || '');
  return errorStr.includes('429') || 
         errorStr.includes('RATE_LIMIT') || 
         errorStr.toLowerCase().includes('rate limit') ||
         errorStr.toLowerCase().includes('quota');
}

/**
 * Execute operation with smart retry logic
 * 
 * @param {Function} operation - Async function to execute
 * @param {string} providerName - Provider name for budget tracking
 * @param {Object} options - Retry options
 * @param {number} options.maxAttempts - Override max attempts
 * @param {number} options.maxTimeMs - Override max time budget
 * @param {Function} options.onRetry - Callback on retry (attempt, delay, error)
 * @returns {Promise<any>} Operation result
 */
async function executeWithSmartRetry(operation, providerName, options = {}) {
  const budget = PROVIDER_RETRY_BUDGETS[providerName] || PROVIDER_RETRY_BUDGETS.custom;
  const maxAttempts = options.maxAttempts || budget.maxAttempts;
  const maxTimeMs = options.maxTimeMs || budget.maxTimeMs;
  const startTime = Date.now();
  
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const result = await operation();
      
      // Success - log and return
      if (attempt > 1) {
        console.log(`[SmartRetry] ✅ ${providerName} succeeded on attempt ${attempt}/${maxAttempts}`);
      }
      
      return result;
      
    } catch (err) {
      lastError = err;
      const elapsed = Date.now() - startTime;
      
      // Check if error is retryable
      if (!isRetryableError(err)) {
        console.log(`[SmartRetry] ❌ ${providerName} non-retryable error: ${err.message}`);
        throw err;
      }
      
      // Check if we've exhausted attempts
      if (attempt >= maxAttempts) {
        console.log(`[SmartRetry] ❌ ${providerName} exhausted ${maxAttempts} attempts`);
        throw err;
      }
      
      // Check if we've exhausted time budget
      if (elapsed >= maxTimeMs) {
        console.log(`[SmartRetry] ❌ ${providerName} exhausted time budget (${elapsed}ms >= ${maxTimeMs}ms)`);
        throw err;
      }
      
      // Calculate backoff
      const isRateLimit = isRateLimitError(err);
      const delay = calculateBackoff(attempt, isRateLimit);
      const remainingBudget = maxTimeMs - elapsed;
      const actualDelay = Math.min(delay, remainingBudget - 100); // Leave 100ms for operation
      
      if (actualDelay <= 0) {
        console.log(`[SmartRetry] ❌ ${providerName} insufficient time budget for retry`);
        throw err;
      }
      
      // Log retry
      const errorType = isRateLimit ? 'RATE_LIMIT' : 'ERROR';
      console.log(`[SmartRetry] ${providerName} attempt ${attempt}/${maxAttempts} failed (${errorType}): ${err.message}`);
      console.log(`[SmartRetry] Retrying in ${actualDelay}ms (${Math.floor(remainingBudget/1000)}s budget remaining)...`);
      
      // Callback
      if (options.onRetry) {
        options.onRetry(attempt, actualDelay, err);
      }
      
      // Wait before retry
      await new Promise(resolve => setTimeout(resolve, actualDelay));
    }
  }
  
  // Should never reach here, but just in case
  throw lastError;
}

/**
 * Execute with cross-provider fallback
 * 
 * Tries multiple providers in sequence, each with full retry budget.
 * Used by global-automode routing.
 * 
 * @param {Array<{provider: string, operation: Function}>} providerOps - Array of provider operations
 * @param {Object} options - Fallback options
 * @returns {Promise<any>} First successful result
 */
async function executeWithCrossProviderFallback(providerOps, options = {}) {
  const errors = [];
  
  for (let i = 0; i < providerOps.length; i++) {
    const { provider, operation } = providerOps[i];
    
    console.log(`[CrossProviderFallback] Trying provider ${i + 1}/${providerOps.length}: ${provider}`);
    
    try {
      const result = await executeWithSmartRetry(operation, provider, options);
      console.log(`[CrossProviderFallback] ✅ Success with provider ${provider}`);
      return result;
      
    } catch (err) {
      console.warn(`[CrossProviderFallback] ❌ Provider ${provider} failed: ${err.message}`);
      errors.push({ provider, error: err });
      
      // Continue to next provider
      if (i < providerOps.length - 1) {
        console.log(`[CrossProviderFallback] Falling back to next provider...`);
        // Small delay between provider switches
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  }
  
  // All providers failed
  console.error(`[CrossProviderFallback] ❌ All ${providerOps.length} providers exhausted`);
  const errorSummary = errors.map(e => `${e.provider}: ${e.error.message}`).join('; ');
  const finalError = new Error(`All providers failed: ${errorSummary}`);
  finalError.code = 'ALL_PROVIDERS_EXHAUSTED';
  finalError.providerErrors = errors;
  throw finalError;
}

module.exports = {
  executeWithSmartRetry,
  executeWithCrossProviderFallback,
  calculateBackoff,
  isRetryableError,
  isRateLimitError,
  RETRYABLE_ERRORS,
  PROVIDER_RETRY_BUDGETS
};
