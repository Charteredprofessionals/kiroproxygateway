/**
 * verify_proxy_mode.js - Verify proxy mode configuration
 * 
 * Checks that:
 * 1. .kiro/config.json exists and marks mode as "proxy"
 * 2. .kiro/steering/proxy-mode.md exists with workflow disable instructions
 * 3. Proxy server is running on port 8084
 * 4. Extension is patched for dual-mode operation
 */

'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');

const checks = {
  passed: 0,
  failed: 0,
  warnings: 0,
  results: []
};

function check(name, testFn, isWarning = false) {
  try {
    const result = testFn();
    if (result === true) {
      checks.passed++;
      checks.results.push({ status: '✅', name, message: 'OK' });
      console.log(`✅ ${name}`);
    } else {
      if (isWarning) {
        checks.warnings++;
        checks.results.push({ status: '⚠️ ', name, message: result });
        console.warn(`⚠️  ${name}: ${result}`);
      } else {
        checks.failed++;
        checks.results.push({ status: '❌', name, message: result });
        console.error(`❌ ${name}: ${result}`);
      }
    }
  } catch (err) {
    checks.failed++;
    checks.results.push({ status: '❌', name, message: err.message });
    console.error(`❌ ${name}: ${err.message}`);
  }
}

function checkAsync(name, testFn, isWarning = false) {
  return testFn()
    .then(result => {
      if (result === true) {
        checks.passed++;
        checks.results.push({ status: '✅', name, message: 'OK' });
        console.log(`✅ ${name}`);
      } else {
        if (isWarning) {
          checks.warnings++;
          checks.results.push({ status: '⚠️ ', name, message: result });
          console.warn(`⚠️  ${name}: ${result}`);
        } else {
          checks.failed++;
          checks.results.push({ status: '❌', name, message: result });
          console.error(`❌ ${name}: ${result}`);
        }
      }
    })
    .catch(err => {
      checks.failed++;
      checks.results.push({ status: '❌', name, message: err.message });
      console.error(`❌ ${name}: ${err.message}`);
    });
}

console.log('\n=== Kiro Proxy Mode Verification ===\n');

// ── Check 1: .kiro/config.json ───────────────────────────────────────────────

check('.kiro/config.json exists', () => {
  const configPath = path.join(process.cwd(), '.kiro', 'config.json');
  if (!fs.existsSync(configPath)) {
    return 'File not found';
  }
  return true;
});

check('.kiro/config.json mode is "proxy"', () => {
  const configPath = path.join(process.cwd(), '.kiro', 'config.json');
  if (!fs.existsSync(configPath)) {
    return 'File not found';
  }
  
  const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  if (config.mode !== 'proxy') {
    return `Mode is "${config.mode}", expected "proxy"`;
  }
  return true;
});

check('.kiro/config.json disables workflows', () => {
  const configPath = path.join(process.cwd(), '.kiro', 'config.json');
  if (!fs.existsSync(configPath)) {
    return 'File not found';
  }
  
  const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  if (config.features?.workflows !== false) {
    return 'workflows feature is not explicitly disabled';
  }
  return true;
});

// ── Check 2: .kiro/steering/proxy-mode.md ────────────────────────────────────

check('.kiro/steering/proxy-mode.md exists', () => {
  const steeringPath = path.join(process.cwd(), '.kiro', 'steering', 'proxy-mode.md');
  if (!fs.existsSync(steeringPath)) {
    return 'File not found';
  }
  return true;
});

check('proxy-mode.md contains workflow guidance', () => {
  const steeringPath = path.join(process.cwd(), '.kiro', 'steering', 'proxy-mode.md');
  if (!fs.existsSync(steeringPath)) {
    return 'File not found';
  }
  
  const content = fs.readFileSync(steeringPath, 'utf-8');
  if (!content.includes('Workflow Tools') || !content.includes('run_workflow')) {
    return 'Missing workflow guidance';
  }
  return true;
});

check('proxy-mode.md has auto inclusion frontmatter', () => {
  const steeringPath = path.join(process.cwd(), '.kiro', 'steering', 'proxy-mode.md');
  if (!fs.existsSync(steeringPath)) {
    return 'File not found';
  }
  
  const content = fs.readFileSync(steeringPath, 'utf-8');
  if (!content.includes('inclusion: auto')) {
    return 'Missing "inclusion: auto" frontmatter';
  }
  return true;
});

// ── Check 3: Proxy Server Status ─────────────────────────────────────────────

async function checkProxyServer() {
  await checkAsync('Proxy server responding on port 8084', () => {
    return new Promise((resolve) => {
      const req = http.get('http://127.0.0.1:8084/health', (res) => {
        if (res.statusCode === 200) {
          resolve(true);
        } else {
          resolve(`Server returned ${res.statusCode}`);
        }
      });
      
      req.on('error', (err) => {
        if (err.code === 'ECONNREFUSED') {
          resolve('Server not running (run: node scripts/kiro_proxy_server.js)');
        } else {
          resolve(err.message);
        }
      });
      
      req.on('timeout', () => {
        req.destroy();
        resolve('Server timeout');
      });
      
      req.setTimeout(3000);
      req.end();
    });
  });

  await checkAsync('Proxy /listAvailableModels endpoint', () => {
    return new Promise((resolve) => {
      const req = http.get('http://127.0.0.1:8084/listAvailableModels', (res) => {
        if (res.statusCode === 200) {
          resolve(true);
        } else {
          resolve(`Endpoint returned ${res.statusCode}`);
        }
      });
      
      req.on('error', () => resolve('Endpoint not reachable'));
      req.setTimeout(3000);
      req.end();
    });
  }, true); // Warning only
}

// ── Check 4: Extension Patch Status ──────────────────────────────────────────

check('Extension patcher script exists', () => {
  const patcherPath = path.join(process.cwd(), 'scripts', 'patch_kiro_extension.js');
  if (!fs.existsSync(patcherPath)) {
    return 'patch_kiro_extension.js not found';
  }
  return true;
});

check('Extension patch includes dual-mode support', () => {
  const patcherPath = path.join(process.cwd(), 'scripts', 'patch_kiro_extension.js');
  if (!fs.existsSync(patcherPath)) {
    return 'patch_kiro_extension.js not found';
  }
  
  const content = fs.readFileSync(patcherPath, 'utf-8');
  if (!content.includes('whgwListModels') || !content.includes('__kiroProxyActive')) {
    return 'Patcher missing dual-mode patches';
  }
  return true;
});

// ── Check 5: Documentation ───────────────────────────────────────────────────

check('UNSUPPORTED_FEATURES.md exists', () => {
  const docPath = path.join(process.cwd(), 'docs', 'guides', 'UNSUPPORTED_FEATURES.md');
  const legacyPath = path.join(process.cwd(), 'docs', 'UNSUPPORTED_FEATURES.md');
  if (!fs.existsSync(docPath) && !fs.existsSync(legacyPath)) {
    return 'Documentation file not found';
  }
  return true;
}, true);

check('WHY_WORKFLOWS_FAIL_IN_PROXY.md exists', () => {
  const docPath = path.join(process.cwd(), 'docs', 'troubleshooting', 'WHY_WORKFLOWS_FAIL_IN_PROXY.md');
  const legacyPath = path.join(process.cwd(), 'docs', 'WHY_WORKFLOWS_FAIL_IN_PROXY.md');
  if (!fs.existsSync(docPath) && !fs.existsSync(legacyPath)) {
    return 'Explanation doc not found';
  }
  return true;
}, true);

// ── Run async checks ─────────────────────────────────────────────────────────

checkProxyServer().then(() => {
  console.log('\n=== Summary ===');
  console.log(`✅ Passed:   ${checks.passed}`);
  console.log(`❌ Failed:   ${checks.failed}`);
  console.log(`⚠️  Warnings: ${checks.warnings}`);
  console.log(`📊 Total:    ${checks.passed + checks.failed + checks.warnings}`);

  if (checks.failed === 0) {
    console.log('\n🎉 Proxy mode configuration is correct!');
    console.log('\nNext steps:');
    console.log('1. Restart Kiro IDE to load new steering files');
    console.log('2. Run: node scripts/patch_kiro_extension.js (if not done)');
    console.log('3. Test with a simple task (no workflows should be attempted)');
    process.exit(0);
  } else {
    console.log('\n❌ Some checks failed. Review errors above.');
    process.exit(1);
  }
});
