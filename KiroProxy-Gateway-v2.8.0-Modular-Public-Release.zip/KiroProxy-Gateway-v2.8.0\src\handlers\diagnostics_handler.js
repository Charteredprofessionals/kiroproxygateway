/**
 * src/handlers/diagnostics_handler.js - AWS ControlPlane, Diagnostics & Catch-All Handler
 * Handles /health, /status, /config, /metrics, ListAvailableModels, GetFeatureConfiguration,
 * GetProfile, GetUsageLimits, and the Universal AWS Cloud Catch-All
 * Pure CommonJS exportable module
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { sendAwsResponse } = require('../protocol/smithy_parser');
const { MODELS, autoPopulateFreeModels, fetchCustomProviderModels } = require('../config/catalog');
const { loadCustomConfig, CONFIG_PATHS } = require('../config/index');
const { HEALTH_STATUS, getTunnelUrl } = require('../resilience/health');
const { CIRCUIT_BREAKERS, isCircuitOpen } = require('../resilience/circuit_breaker');
const { METRICS, getMetricsSnapshot } = require('../resilience/metrics');
const { geminiQueue, pendingGeminiRequests } = require('../providers/canvas_bridge');

async function handleDiagnosticsRoutes(req, res, urlPath, method, amzTarget, reqId, body = {}) {
  // 1. Prometheus Metrics
  if (urlPath === '/metrics') {
    const metrics = getMetricsSnapshot();
    res.writeHead(200, { 'Content-Type': 'text/plain', 'Server': 'Amazon.com' });
    let output = '# KiroProxy Gateway Metrics\n';
    output += `# HELP kiro_proxy_uptime_seconds Proxy uptime in seconds\n`;
    output += `kiro_proxy_uptime_seconds ${Math.floor(metrics.uptime / 1000)}\n`;

    for (const [provider, stats] of Object.entries(metrics.providers)) {
      output += `# HELP kiro_provider_calls_total Total provider calls\n`;
      output += `kiro_provider_calls_total{provider="${provider}"} ${stats.total}\n`;
      output += `# HELP kiro_provider_success_total Successful provider calls\n`;
      output += `kiro_provider_success_total{provider="${provider}"} ${stats.success}\n`;
      output += `# HELP kiro_provider_latency_p50 P50 latency in milliseconds\n`;
      output += `kiro_provider_latency_p50{provider="${provider}"} ${stats.p50}\n`;
      output += `# HELP kiro_provider_latency_p99 P99 latency in milliseconds\n`;
      output += `kiro_provider_latency_p99{provider="${provider}"} ${stats.p99}\n`;
    }
    res.end(output);
    return true;
  }

  // 2. AWS KiroRuntimeService: GetFeatureConfiguration
  if (urlPath.includes('featureconfiguration') || amzTarget.includes('getfeatureconfiguration')) {
    const FEATURE_SALT = 'kiro-feature-config-key-salt-3e9b1d7a';
    const hashFlag = (flag) => crypto.createHash('sha256').update(FEATURE_SALT + flag).digest('hex');
    const rawFlags = {
      system_field_injection: true,
      system_prompt_migration: true,
      steering_supervisor: true,
      cgs_delegation_v2: true,
      user_agent_refactoring_enabled: true,
      empty_response_retry: true,
      truncated_response_retry: true,
      stream_error_retry: true,
      stall_tool_continuation: true,
      create_response_api: false,
      kiroInfraSafetyMonitor: false,
      kuts_telemetry: false
    };
    const configuration = {};
    for (const [flag, val] of Object.entries(rawFlags)) {
      configuration[hashFlag(flag)] = val;
      configuration[flag] = val;
    }
    sendAwsResponse(res, 200, {
      configuration,
      featureEvaluations: [
        { feature: 'system_field_injection', variation: 'treatment' },
        { feature: 'system_prompt_migration', variation: 'treatment' },
        { feature: 'steering_supervisor', variation: 'treatment' },
        { feature: 'user_agent_refactoring_enabled', variation: 'treatment' },
        { feature: 'fta_vibe', variation: 'treatment' },
        { feature: 'cgs_delegation_v2', variation: 'treatment' },
        { feature: 'empty_response_retry', variation: 'treatment' }
      ]
    }, reqId, { 'Content-Type': 'application/json' });
    return true;
  }

  // 3. AWS KiroControlPlaneBearerService: GetProfile
  if (urlPath.includes('getprofile') || amzTarget.includes('getprofile')) {
    sendAwsResponse(res, 200, {
      profileArn: 'arn:aws:kiro:us-east-1:123456789012:profile/default',
      profileName: 'default',
      status: 'ACTIVE',
      userContext: {
        userId: 'usr_default',
        email: 'developer@kiro.local'
      }
    }, reqId);
    return true;
  }

  // 4. AWS KiroControlPlaneBearerService: ListAvailableModels
  if (urlPath.includes('listavailablemodels') || amzTarget.includes('listavailablemodels')) {
    console.log(`[KiroProxy] ⭐ ListAvailableModels requested from ${req.socket.remoteAddress} (${MODELS.models.length} models)`);
    autoPopulateFreeModels();

    const modelsWithPricing = {
      ...MODELS,
      models: MODELS.models.map(m => ({
        ...m,
        pricing: {
          prompt: String(m.rateMultiplier || 0),
          completion: String(m.rateMultiplier || 0),
          unit: m.rateUnit || 'credit'
        }
      }))
    };

    sendAwsResponse(res, 200, modelsWithPricing, reqId);
    return true;
  }

  // 5. OpenAI-Compatible Model Catalog: GET /v1/models
  if (urlPath === '/v1/models' || urlPath === '/api/v1/models') {
    autoPopulateFreeModels();

    const freeModels = MODELS.models.filter(m => m.rateMultiplier === 0.0);
    console.log(`[/v1/models] Returning ${freeModels.length} free models (filtered from ${MODELS.models.length} total)`);

    const list = freeModels.map(m => ({
      id: m.modelId,
      object: 'model',
      created: Math.floor(Date.now() / 1000),
      owned_by: m.provider || 'kiro-proxy',
      name: m.modelName,
      description: m.description
    }));

    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(JSON.stringify({ object: 'list', data: list }));
    return true;
  }

  // 5b. Refresh Provider Health & Model Catalog: POST /api/health/refresh
  if (urlPath === '/api/health/refresh' && method === 'POST') {
    const { runHealthChecks } = require('../resilience/health');
    await runHealthChecks().catch(() => {});
    await autoPopulateFreeModels(true).catch(() => {});
    res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify({
      success: true,
      modelCount: MODELS.models.length,
      providers: HEALTH_STATUS.providers
    }));
    return true;
  }

  // 5c. Reset Circuit Breakers: POST /api/circuit/reset
  if (urlPath === '/api/circuit/reset' && method === 'POST') {
    for (const key of Object.keys(CIRCUIT_BREAKERS)) {
      CIRCUIT_BREAKERS[key].state = 'CLOSED';
      CIRCUIT_BREAKERS[key].failures = 0;
    }
    res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify({ success: true, circuitBreakers: CIRCUIT_BREAKERS }));
    return true;
  }

  // 6. Configuration Management: GET /api/config
  if (urlPath === '/api/config' && method === 'GET') {
    const cfg = loadCustomConfig();
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(JSON.stringify({
      kiloApiKeys: cfg.kiloApiKeys || [],
      clineApiKeys: cfg.clineApiKeys || [],
      openrouterApiKeys: cfg.openrouterApiKeys || [],
      orcarouterApiKeys: cfg.orcarouterApiKeys || [],
      geminiApiKeys: cfg.geminiApiKeys || [],
      customProviders: cfg.customProviders || [],
      providerPriorityOrder: cfg.providerPriorityOrder || ['kilo', 'cline', 'openrouter', 'orcarouter', 'gemini', 'custom'],
      providerBaseUrls: cfg.providerBaseUrls || {
        kilo: ['https://api.kilo.ai/api/gateway'],
        cline: ['https://api.cline.bot/api/v1'],
        openrouter: ['https://openrouter.ai/api/v1'],
        orcarouter: ['https://api.orcarouter.ai/v1'],
        gemini: ['https://generativelanguage.googleapis.com/v1beta']
      },
      envConfigured: {
        kilo: true, // Zero-key cloud inference active by default
        cline: Boolean(process.env.CLINE_API_KEY),
        openrouter: Boolean(process.env.OPENROUTER_API_KEY || process.env.AI_API_KEY),
        orcarouter: Boolean(process.env.ORCAROUTER_API_KEY || process.env.ORCAROUTER_API_KEY_2),
        gemini: Boolean(process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY_2),
        ngrok: Boolean(process.env.NGROK_AUTHTOKEN || process.env.NGROK_TOKEN)
      }
    }));
    return true;
  }

  // 7. Configuration Management: POST /api/config
  if (urlPath === '/api/config' && method === 'POST') {
    try {
      const newConfig = { ...body };
      delete newConfig.envConfigured;
      const configPath = CONFIG_PATHS.CONFIG_FILE;

      // Prevent .env secrets from leaking into kiro_ai_config.json on disk
      const envSecrets = new Set(
        [
          process.env.KILO_API_KEY,
          process.env.CLINE_API_KEY,
          process.env.OPENROUTER_API_KEY,
          process.env.AI_API_KEY,
          process.env.ORCAROUTER_API_KEY,
          process.env.ORCAROUTER_API_KEY_2,
          process.env.GEMINI_API_KEY,
          process.env.GEMINI_API_KEY_2,
          process.env.GROQ_API_KEY
        ].filter(Boolean)
      );

      for (const arrKey of ['kiloApiKeys', 'clineApiKeys', 'openrouterApiKeys', 'orcarouterApiKeys', 'geminiApiKeys']) {
        if (Array.isArray(newConfig[arrKey])) {
          newConfig[arrKey] = newConfig[arrKey].filter(k => k && !envSecrets.has(k));
        }
      }

      if (Array.isArray(newConfig.customProviders)) {
        newConfig.customProviders = newConfig.customProviders.map(cp => {
          const baseUrls = [
            ...(Array.isArray(cp.baseUrls) ? cp.baseUrls : []),
            ...(cp.baseUrl ? [cp.baseUrl] : [])
          ].map(u => String(u).trim()).filter(Boolean);
          const uniqueUrls = [...new Set(baseUrls)];

          const apiKeys = [
            ...(Array.isArray(cp.apiKeys) ? cp.apiKeys : []),
            ...(cp.apiKey ? [cp.apiKey] : [])
          ].map(k => String(k).trim()).filter(Boolean);
          const uniqueKeys = [...new Set(apiKeys)];

          return {
            ...cp,
            baseUrls: uniqueUrls,
            baseUrl: uniqueUrls[0] || '',
            apiKeys: uniqueKeys,
            apiKey: uniqueKeys[0] || ''
          };
        });
      }

      let existingConfig = {};
      try {
        if (fs.existsSync(configPath)) {
          existingConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        }
      } catch (err) {
        console.warn('[Config] Could not read existing config:', err.message);
      }

      const merged = { ...existingConfig, ...newConfig };
      const configDir = path.dirname(configPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }

      fs.writeFileSync(configPath, JSON.stringify(merged, null, 2));
      console.log('[Config] Configuration updated successfully in project config');

      fetchCustomProviderModels();
      console.log('[Config] Custom provider catalog refreshed');

      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      });
      res.end(JSON.stringify({ success: true }));
    } catch (err) {
      console.error('[Config] Save error:', err.message);
      res.writeHead(500, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      });
      res.end(JSON.stringify({ error: err.message }));
    }
    return true;
  }

  // 8. Configuration GUI: GET /config or /config.html
  if (urlPath === '/config' || urlPath === '/config.html') {
    const candidatePaths = [
      path.join(__dirname, '..', '..', 'public', 'config.html'),
      path.join(__dirname, '..', '..', 'public', 'config', 'index.html')
    ];
    for (const htmlPath of candidatePaths) {
      if (fs.existsSync(htmlPath)) {
        res.writeHead(200, {
          'Content-Type': 'text/html',
          'Cache-Control': 'no-cache'
        });
        res.end(fs.readFileSync(htmlPath));
        return true;
      }
    }
  }

  // 9. AWS KiroControlPlaneBearerService: GetUsageLimits
  if (urlPath.includes('usagelimits') || amzTarget.includes('usagelimits')) {
    sendAwsResponse(res, 200, {
      nextDateReset: '2026-10-01T00:00:00.000Z',
      usageLimit: 10000,
      usageLimitWithPrecision: 10000.0,
      totalUsageLimit: 10000,
      currentUsage: 0,
      rateUnit: 'credit',
      rateMultiplier: 0.0,
      unit: 'INVOCATIONS',
      status: 'ACTIVE',
      usageBreakdownList: [{
        currentUsage: 0,
        usageLimit: 10000,
        overageCharges: 0,
        currency: 'USD',
        resourceType: 'CREDIT',
        displayName: 'Unlimited Free Credits',
        unit: 'INVOCATIONS'
      }],
      subscriptionInfo: {
        type: 'Q_DEVELOPER_STANDALONE_FREE',
        subscriptionTitle: 'KIRO UNLIMITED FREE'
      },
      overageConfiguration: { overageStatus: 'DISABLED' },
      tokenLimits: { maxTokens: 128000, remainingTokens: 128000 }
    }, reqId);
    return true;
  }

  // 10. AWS KiroWebBearerService: Config Manifest & Contents
  if (urlPath.includes('getconfigmanifest')) {
    sendAwsResponse(res, 200, {
      status: 'noChanges',
      versionId: 'v1',
      files: [],
      manifest: { version: '1.0', entries: [] }
    }, reqId);
    return true;
  }

  if (urlPath.includes('getconfigcontents')) {
    sendAwsResponse(res, 200, { contents: {} }, reqId);
    return true;
  }

  // 11. Health Check Endpoint (GET /health)
  if (urlPath === '/health' || urlPath === '/api/health' || urlPath === '/api/hello') {
    const totalProviders = Object.keys(HEALTH_STATUS.providers).length;
    const healthyCount = Object.values(HEALTH_STATUS.providers).filter(p => p.status === 'healthy').length;
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      message: 'KiroProxy Active',
      proxy: 'KiroProxy Gateway',
      version: '2.8.0',
      modelCount: MODELS.models.length,
      providersHealthy: `${healthyCount}/${totalProviders}`,
      providers: HEALTH_STATUS.providers,
      tunnel: getTunnelUrl() || 'localhost',
      endpoints: {
        health: '/health',
        status: '/status',
        config: '/config',
        models: '/v1/models',
        messages: '/v1/messages',
        chatCompletions: '/v1/chat/completions',
        poll: '/poll',
        chunk: '/chunk',
        done: '/done',
        cancel: '/cancel'
      },
      bridgeQueue: {
        depth: geminiQueue.length,
        pending: pendingGeminiRequests.size
      }
    }));
    return true;
  }

  // 12. Status Endpoint (GET /status)
  if (urlPath === '/status' || urlPath === '/v1/status') {
    const allProviders = Object.keys(METRICS.providerCalls);
    const status = {
      proxy: 'KiroProxy Gateway',
      version: '2.8.0',
      uptime: process.uptime(),
      tunnel: getTunnelUrl() || 'localhost',
      health: {},
      circuitBreakers: {},
      metrics: {},
      summary: {
        totalRequests: 0,
        totalSuccesses: 0,
        totalFailures: 0
      }
    };

    for (const provider of allProviders) {
      const m = METRICS.providerCalls[provider];
      if (!m) continue;

      status.health[provider] = {
        status: isCircuitOpen(provider) ? 'circuit_open' : 'healthy',
        latency: m.latencies.length > 0 ? m.latencies[m.latencies.length - 1] : null
      };

      status.circuitBreakers[provider] = CIRCUIT_BREAKERS[provider]?.state || 'CLOSED';

      status.metrics[provider] = {
        total: m.total,
        success: m.success,
        failure: m.failure,
        successRate: m.total > 0 ? ((m.success / m.total) * 100).toFixed(2) + '%' : '0%'
      };

      status.summary.totalRequests += m.total;
      status.summary.totalSuccesses += m.success;
      status.summary.totalFailures += m.failure;
    }

    if (status.summary.totalRequests > 0) {
      status.summary.overallSuccessRate =
        ((status.summary.totalSuccesses / status.summary.totalRequests) * 100).toFixed(2) + '%';
    }

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(status, null, 2));
    return true;
  }

  return false;
}

function handleAwsCatchAll(req, res, reqId, shouldLog = true) {
  if (shouldLog) {
    console.log(`[KiroProxy] AWS Catch-all handler for ${req.method} ${req.url}`);
  }
  sendAwsResponse(res, 200, {
    __type: 'com.amazon.kiro.runtimeservice#Success',
    status: 'ok',
    proxy: 'KiroProxy Gateway v2.8.0 (Dual-Layer Smart Fallback)',
    message: 'Acknowledged by Amazon Kiro Runtime Service'
  }, reqId);
}

module.exports = {
  handleDiagnosticsRoutes,
  handleAwsCatchAll
};
