# 🚀 KiroProxy Gateway v2.8.0 — Quick Start Guide

**Zero-Cost, Resilient AI Gateway for Kiro IDE with 6-Tier Auto-Fallback**

---

## ⚡ 1-Minute Quick Start

### 1. Launch KiroProxy Gateway
From the project root:
```cmd
start.bat
```
*(Or run `npm start` / `node scripts/kiro_proxy_server.js` directly)*

### 2. Patch Kiro IDE Extension
```cmd
npm run patch
```
*(Or run `node scripts/patch_kiro_extension.js` directly)*

### 3. Reload Kiro IDE Window
In Kiro IDE:
1. Press <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>P</kbd>
2. Select **`Developer: Reload Window`**

### 4. Chat & Code
In Kiro IDE model selector, pick `global-automode` or any specific model (`kilo-deepseek-v3`, `cline-glm-flash`, `ngrok-gemini-flash`) and start coding!

---

## 🔄 How the 6-Tier Fallback Works

When you send a prompt with model `global-automode` or if an upstream provider is busy or rate-limited, KiroProxy Gateway automatically cascades through:

```
1. Kilo Gateway (https://api.kilo.ai - zero-key free cloud models)
   └─→ ❌ Failed / 429? → Failover

2. Cline API Free Tier (agentic coding models)
   └─→ ❌ Failed / 429? → Failover

3. OpenRouter Free Tier (:free slug models)
   └─→ ❌ Failed / 429? → Failover

4. OrcaRouter Free Tier (multi-key rotating models)
   └─→ ❌ Failed / 429? → Failover

5. Gemini API Direct (Google AI Studio key)
   └─→ ❌ Failed / 429? → Failover

6. Custom Providers (Groq, GLM, Abhyast-Gemini configured in GUI / config)
   └─→ ✅ 200 OK → Streams response back to Kiro IDE!
```

---

## 🌐 Zero-Cost Gemini via Canvas Bridge

To use Google Gemini via web browser session without API keys or usage billing:
1. Open and sign into **[gemini.google.com](https://gemini.google.com)** in your browser.
2. In the same browser, open **`http://127.0.0.1:8084/canvas`**.
3. Install or activate the userscript (`scripts/userscript.js`).
4. In Kiro IDE, select model **`ngrok-gemini-flash`**.

---

## ⚙️ Configuration Management GUI

Open your browser to:
```
http://127.0.0.1:8084/config
```
Use this visual dashboard to add API keys, configure custom OpenAI-compatible providers, test latency, and monitor health across all 9 providers.

---

## 🔍 Health & Diagnostic Check

```cmd
curl http://127.0.0.1:8084/health
```

Expected output:
```json
{
  "status": "ok",
  "message": "KiroProxy Active",
  "version": "2.8.0",
  "modelCount": 189,
  "providersHealthy": "9/9"
}
```
