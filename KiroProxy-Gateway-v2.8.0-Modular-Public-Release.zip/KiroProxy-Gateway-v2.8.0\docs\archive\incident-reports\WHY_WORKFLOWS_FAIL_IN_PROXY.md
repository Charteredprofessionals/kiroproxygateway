# Why Workflows Are Initiated (and Fail) When Using Proxy

**Date:** October 6, 2026  
**Issue:** Kiro IDE tries to use `run_workflow` even when connected to proxy that doesn't support it

---

## The Root Cause

### Architecture Layers

```
┌─────────────────────────────────────────┐
│   User: "Fix this bug"                  │
└────────────────┬────────────────────────┘
                 ↓
┌─────────────────────────────────────────┐
│   Kiro IDE Agent (AI Assistant)         │
│   • Reads steering files                │
│   • Sees: "Always delegate to workflows"│
│   • Decides: "I should use run_workflow"│
└────────────────┬────────────────────────┘
                 ↓
┌─────────────────────────────────────────┐
│   Kiro IDE Extension (Patched)          │
│   • Routes models → localhost:8084      │
│   • Routes chat → localhost:8084        │
│   • Routes tools → localhost:8084       │
└────────────────┬────────────────────────┘
                 ↓
┌─────────────────────────────────────────┐
│   Kiro Proxy Gateway (localhost:8084)   │
│   ✅ GenerateAssistantResponse          │
│   ✅ ListAvailableModels                │
│   ✅ InvokeMCP                           │
│   ❌ run_workflow (NOT IMPLEMENTED)     │
└────────────────┬────────────────────────┘
                 ↓
               ERROR ❌
```

### The Problem

**Workflows are NOT initiated by the proxy** - they're initiated by the **Kiro IDE's AI agent** following instructions in its context/steering files.

The proxy just receives the `run_workflow` request and rejects it because it doesn't implement that API.

---

## Why This Happens

### 1. **Steering File Instructions**

The default Kiro IDE setup includes steering files that say:

```markdown
## Default behavior: always delegate implementation to workflows

When the user asks you to implement a feature, fix a bug, or investigate:
1. Formulate the workflow prompt
2. **Always** create and launch the workflow with run_workflow
3. Stay lightweight, delegate substantive work
```

**These instructions are for Kiro Cloud mode**, where workflow APIs ARE available.

### 2. **Extension Only Patches Network Layer**

The `patch_kiro_extension.js` script modifies:
- Model discovery endpoint (routes to proxy)
- Chat completions endpoint (routes to proxy)
- MCP tool invocations (routes to proxy)

**It does NOT modify:**
- Agent's decision-making logic
- Steering file loading
- Tool availability detection
- Workflow capability checks

### 3. **No Runtime Feature Detection**

The IDE doesn't currently check "does my backend support workflows?" before trying to use them.

It assumes:
- If you're using Kiro → workflows available
- Extension patches don't disable workflow instructions

---

## The Solution: Three Approaches

### ✅ Approach 1: Steering File Override (Recommended)

**Already implemented in this project:**

1. **Created `.kiro/steering/proxy-mode.md`**
   - Explicitly disables workflow usage
   - Provides direct execution instructions
   - Auto-included when proxy is active

2. **Created `.kiro/config.json`**
   - Marks mode as "proxy"
   - Declares workflows: false
   - Lists proxy-mode.md in alwaysInclude

**How it works:**
```
Kiro IDE Agent loads context
  ↓
Reads .kiro/config.json (mode: proxy)
  ↓
Loads .kiro/steering/proxy-mode.md
  ↓
Sees: "NEVER use run_workflow in proxy mode"
  ↓
Uses direct execution instead ✅
```

### ⚠️ Approach 2: Extension Patch Enhancement

Modify `patch_kiro_extension.js` to inject a feature flag:

```javascript
// Add to extension.js after patching
globalThis.__kiroFeatures = {
  workflows: false,
  specs: false,
  cloudConfig: false
};
```

**Pros:** Agent can check capabilities at runtime  
**Cons:** Requires deeper extension modification  

### ❌ Approach 3: Proxy Stub Endpoints

Make proxy return "not supported" responses:

```javascript
// In kiro_proxy_server.js
app.post('/runtime/workflows/run', (req, res) => {
  res.status(501).json({
    error: 'NotImplemented',
    message: 'Workflows not supported in proxy mode',
    recommendation: 'Use direct execution or Kiro Cloud'
  });
});
```

**Pros:** Clear error messages  
**Cons:** Doesn't prevent the attempt, just handles failure  

---

## Current Status: FIXED ✅

**With the steering file approach:**

1. ✅ `.kiro/steering/proxy-mode.md` created
2. ✅ `.kiro/config.json` configures proxy mode
3. ✅ Instructions explicitly disable workflows
4. ✅ Direct execution guidance provided

**The IDE agent will now:**
- Load proxy-mode steering on startup
- See explicit "NEVER use run_workflow" instruction
- Use direct file/command tools instead
- Work within proxy capabilities

---

## Testing the Fix

### Before Fix:
```
User: "Fix the bug in utils.js"
  ↓
Agent: "I'll create a workflow to investigate..."
  ↓
Agent calls run_workflow(...)
  ↓
Proxy: "Error: run_workflow not supported"
  ↓
FAILURE ❌
```

### After Fix:
```
User: "Fix the bug in utils.js"
  ↓
Agent: "I'll examine the file directly..." (proxy-mode steering active)
  ↓
Agent calls read_file("utils.js")
  ↓
Agent calls str_replace(...) to fix
  ↓
Agent calls execute_pwsh("npm test")
  ↓
SUCCESS ✅
```

---

## Verification Steps

1. **Restart Kiro IDE** (to load new steering files)
2. **Check context loaded:**
   - Agent should reference "proxy mode" in responses
   - No workflow attempts should be made
3. **Test a simple task:**
   ```
   "Add a comment to scripts/kiro_proxy_server.js line 1"
   ```
   Should work directly without workflow attempts

4. **Monitor logs:**
   ```powershell
   # No "run_workflow" errors should appear
   node scripts/kiro_proxy_server.js
   ```

---

## Why Other Solutions Won't Work

### ❌ "Just add run_workflow to the proxy"
**Won't work** - requires state management, job orchestration, multi-agent coordination (months of work)

### ❌ "Make the extension block run_workflow calls"
**Won't work** - extension operates at network layer, after agent already decided to use workflows

### ❌ "Update Kiro IDE itself"
**Won't work** - you don't have access to modify the IDE's core code

### ✅ "Change agent's instructions via steering"
**WORKS** - agents follow their context/instructions, so correct instructions = correct behavior

---

## Long-term Solution

**Ideal implementation** (requires Kiro team):

1. **Feature detection API**
   ```javascript
   GET /capabilities
   {
     "workflows": false,
     "specs": false,
     "mcp": true,
     "streaming": true
   }
   ```

2. **Extension capability check**
   ```javascript
   const caps = await fetch('/capabilities');
   if (!caps.workflows) {
     globalThis.__kiroFeatures.workflows = false;
   }
   ```

3. **Agent runtime check**
   ```javascript
   if (!globalThis.__kiroFeatures.workflows) {
     // Use direct execution instead
   }
   ```

**For now:** Steering file override is the pragmatic solution.

---

## Summary

**Q: Why are workflows initiated when using proxy?**  
**A:** The Kiro IDE's AI agent follows steering file instructions that say "always use workflows" - these instructions are for cloud mode.

**Q: Why doesn't the proxy just support workflows?**  
**A:** Workflows require infrastructure (state storage, job orchestration, multi-agent) that exceeds proxy scope.

**Q: How do we fix it?**  
**A:** Override the instructions with proxy-specific steering files that disable workflow usage and enable direct execution.

**Status:** ✅ **FIXED** with `.kiro/steering/proxy-mode.md`

---

**Next Steps:**
1. Restart Kiro IDE
2. Verify proxy-mode steering is loaded
3. Test direct execution works
4. No more workflow errors! 🎉
