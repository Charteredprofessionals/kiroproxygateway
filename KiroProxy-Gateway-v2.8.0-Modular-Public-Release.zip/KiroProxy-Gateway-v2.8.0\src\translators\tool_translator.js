/**
 * src/translators/tool_translator.js - Upstream tool schema translation
 * Filters proprietary workflow tools (INV-08) and translates to provider schema format
 * Pure CommonJS exportable module
 */

'use strict';

const { extractToolMetadata } = require('./tool_extractor');
const { sanitizeSchemaForUpstream } = require('./sanitizer');

const FORBIDDEN_TOOLS_IN_PROXY = [
  'run_workflow', 'inspect_workflow', 'update_workflow', 'validate_workflow',
  'workflow_run', 'workflow_inspect', 'workflow_update', 'workflow_validate'
];

/**
 * Translate Kiro IDE tools to upstream provider format
 * Handles Anthropic, OpenAI, Gemini, and custom provider formats
 * @param {Array} kiroTools - Kiro IDE tool definitions
 * @param {string} providerType - 'openai' | 'anthropic' | 'gemini'
 * @returns {Array|undefined}
 */
function translateToolsToUpstream(kiroTools, providerType = 'openai') {
  if (!kiroTools || !Array.isArray(kiroTools) || kiroTools.length === 0) {
    return undefined;
  }
  
  const filteredTools = kiroTools.filter(rawTool => {
    const { name } = extractToolMetadata(rawTool);
    if (FORBIDDEN_TOOLS_IN_PROXY.includes(name.toLowerCase())) {
      console.warn(`[KiroProxy] ⚠️ Suppressing forbidden workflow tool in proxy mode: ${name}`);
      console.warn(`[KiroProxy] 💡 Proxy mode does not support workflows. Use direct tool execution instead.`);
      return false;
    }
    return true;
  });
  
  if (filteredTools.length === 0) {
    return undefined;
  }
  
  return filteredTools.map(rawTool => {
    const { name, description, schema } = extractToolMetadata(rawTool);
    const sanitizedSchema = sanitizeSchemaForUpstream(schema, providerType);
    
    // Anthropic format: { name, description, input_schema }
    if (providerType === 'anthropic') {
      return {
        name,
        description,
        input_schema: sanitizedSchema
      };
    }
    
    // Gemini format: { name, description, parameters }
    if (providerType === 'gemini') {
      return {
        name,
        description,
        parameters: sanitizedSchema
      };
    }
    
    // OpenAI format (default)
    return {
      type: 'function',
      function: {
        name,
        description,
        parameters: sanitizedSchema
      }
    };
  });
}

module.exports = {
  FORBIDDEN_TOOLS_IN_PROXY,
  translateToolsToUpstream
};
