# Changelog

All notable changes to KiroProxy Gateway will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.8.0] - 2026-10-09

### Added
- ✨ **Abhyast-Gemini Custom Provider**: New permanent ngrok static tunnel exposing 9 Gemini models
  - Base URL: `https://corset-decipher-vocation.ngrok-free.dev/api/v1`
  - API Key: `sk-devgw-master-key`
  - Models: otomode, gemini-3.8-flash, gemini-3.1-flash-lite, gemini-2.5-flash, gemini-2.5-pro, gemini-2.0-flash, gemini-2.0-flash-lite, gemini-1.5-pro, gemini-1.5-flash
  - Model prefix: `custom-abhyast-gemini-*`
  - Auto-populate: Enabled
  - Free only: Yes
- 🔄 **Enhanced Model Catalog**: Expanded to 193 models across 9 providers
- 📝 **Template Updates**: Added Abhyast-Gemini to config template with example configuration
- 📚 **Documentation Updates**: AGENTS.md, README.md, and template configuration updated

### Changed
- 📊 **Provider Count**: Increased from 8 to 9 providers (added Abhyast-Gemini)
- 🔢 **Model Count**: Increased from 186 to 193 total models
- 📖 **Custom Provider Examples**: Now includes 4 custom providers (Groq, GLM, Cloudflare-Gemini, Abhyast-Gemini)

### Verified
- ✅ **Provider Health**: 9/9 providers healthy (including new Abhyast-Gemini)
- ✅ **Model Discovery**: Auto-population working for Abhyast-Gemini (9 models discovered)
- ✅ **Chat Completions**: Tested and working with `custom-abhyast-gemini-gemini-3_8-flash`
- ✅ **Permanent Tunnel**: ngrok static tunnel verified (no expiration)

## [2.7.0] - 2026-10-08

### Added
- ✨ **Gemini Auto-Population**: Models dynamically fetched from Google Generative AI API every 5 minutes
- 🛠️ **Tool Translation Layer**: GeminiGateway-style tool translation supporting 5 formats (JSON, Claude XML, Anthropic, Kiro, code blocks)
- 🔄 **Multi-Tool Support**: Unique IDs and proper AWS EventStream emission for multiple tools
- 📊 **Provider Integration**: 6/7 providers integrated with translation layer (86% coverage)
- 🔧 **Universal Native Cloud Reliability**: Retry, circuit breaker, metrics for ALL providers
- 🎯 **Kilo API & Custom Provider Tests**: Comprehensive test suite for Kilo and custom providers
- 📝 **Real-World Agent Scenario Tests**: 8 tests simulating actual Kiro IDE workflows
- 🌐 **Ngrok Provider Testing**: Infrastructure and queue system verification
- 📋 **Comprehensive Documentation**: Complete verification reports and compatibility checklists

### Changed
- 🔄 **Model Catalog**: Expanded to 176 models across 7 providers
- ⚡ **Translation Engine**: 4 functions, 267 lines, 15 unit tests passing
- 🎨 **Enhanced Tool Emission**: Multi-tool support, unique IDs, dynamic stopReason
- 📈 **Test Coverage**: 27/27 tests passing (100% core), 8/8 scenarios passing

### Fixed
- 🐛 **Tool Definition Handling**: Gateway now correctly accepts complex tool schemas
- 🔧 **EventStream Format**: AWS Bedrock compliance with CRC32 checksums
- 🌐 **Provider Health**: All 7 providers healthy and operational
- 📦 **Concurrent Requests**: Proper handling of simultaneous requests

### Verified
- ✅ **Tool Execution**: All tool types accepted and processed
- ✅ **Multi-Turn Capabilities**: Context preserved, concurrent requests handled
- ✅ **Workflow Fallback**: Gracefully disabled in proxy mode (correct behavior)
- ✅ **Provider Status**: 7/7 healthy (Kilo, Gemini, Cline, OpenRouter, OrcaRouter, Ngrok, Custom-Groq)
- ✅ **Free Models Only**: All 176 models verified with `rateMultiplier: 0.0`
- ✅ **Kiro IDE Compatibility**: 100% compatible, extension patches active

## [2.6.0] - 2026-09-XX

### Added
- Universal Reliability Layer for all providers
- Circuit breaker implementation with state logging
- Enhanced error handling and retry logic
- Metrics endpoint for Prometheus monitoring

### Changed
- Improved timeout handling across all providers
- Enhanced queue management with auto-cleanup
- Better rate limiting implementation

### Fixed
- Race conditions in request handling
- Size limit issues with large responses
- Circuit breaker HALF_OPEN protection

## [2.5.0] - 2026-08-XX

### Added
- Native proxy reliability features
- Enhanced Canvas Bridge functionality
- Improved health check system
- Better provider status tracking

### Changed
- Optimized model discovery process
- Enhanced error messaging
- Improved logging system

### Fixed
- Provider connectivity issues
- Model catalog sync problems
- Health endpoint accuracy

## [2.4.0] - 2026-07-XX

### Added
- Custom provider support (Groq, Ollama, DeepSeek)
- Enhanced configuration GUI
- Batch script utilities
- Extension patcher improvements

### Changed
- Simplified setup process
- Better API key management
- Improved documentation structure

### Fixed
- Extension patch compatibility
- Configuration file loading
- Provider initialization errors

## [2.3.0] - 2026-06-XX

### Added
- OrcaRouter integration
- Enhanced ngrok support
- Canvas Bridge dashboard
- Queue polling system

### Changed
- Streamlined provider architecture
- Improved model filtering
- Enhanced free-model verification

### Fixed
- Ngrok tunnel stability
- Canvas Bridge connection handling
- Provider health check accuracy

## [2.2.0] - 2026-05-XX

### Added
- OpenRouter free tier integration
- Enhanced model catalog
- Better error responses
- Provider failover logic

### Changed
- Improved auto-routing algorithm
- Enhanced free model filtering
- Better logging format

### Fixed
- Model discovery bugs
- Provider timeout issues
- Health check failures

## [2.1.0] - 2026-04-XX

### Added
- Cline API integration
- Multi-provider fallback chain
- Enhanced health monitoring
- Better test coverage

### Changed
- Improved provider abstraction
- Enhanced error handling
- Better documentation

### Fixed
- Provider switching bugs
- Model catalog issues
- Configuration loading problems

## [2.0.0] - 2026-03-XX

### Added
- Complete rewrite with modern architecture
- Kilo Gateway integration
- Auto-fallback routing
- Comprehensive test suite

### Changed
- New provider architecture
- Improved configuration system
- Enhanced logging

### Breaking Changes
- Configuration file format changed
- API endpoint structure updated
- Provider naming conventions modified

## [1.0.0] - 2026-02-XX

### Added
- Initial release
- Basic proxy functionality
- Gemini API support
- Simple configuration system

---

## Legend

- ✨ New Feature
- 🔄 Changed
- 🐛 Bug Fix
- 🔧 Technical Improvement
- 📝 Documentation
- 🎯 Testing
- ⚡ Performance
- 🛠️ Tooling
- 🌐 Integration
- 📊 Monitoring
- 🎨 UI/UX
- 📈 Enhancement
- 📋 Organization
- ✅ Verification

---

## Upgrade Notes

### From 2.6.0 to 2.7.0

**Required Actions:**
1. Run `npm install` to update dependencies
2. No configuration changes needed
3. Extension patches automatically updated

**New Features:**
- Gemini models auto-populate - no manual updates needed
- Tool translation layer active for all providers
- Enhanced test suite available

**Breaking Changes:**
None

### From 2.5.0 to 2.6.0

**Required Actions:**
1. Update configuration file format (if customized)
2. Review circuit breaker settings
3. Check provider timeout values

**New Features:**
- Universal reliability layer
- Circuit breaker protection
- Prometheus metrics

**Breaking Changes:**
None

---

## Support

For issues, questions, or contributions:
- **Issues:** https://github.com/yourusername/kiro-integration/issues
- **Discussions:** https://github.com/yourusername/kiro-integration/discussions
- **Documentation:** See `docs/` directory
