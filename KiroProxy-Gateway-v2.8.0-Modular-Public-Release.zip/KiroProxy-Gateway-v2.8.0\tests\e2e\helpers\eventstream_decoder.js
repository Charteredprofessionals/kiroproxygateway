/**
 * eventstream_decoder.js - AWS Bedrock EventStream Binary Protocol Decoder
 * 
 * Independently validates and parses binary EventStream frames produced by
 * AWS Bedrock converse streaming endpoints (/generateAssistantResponse,
 * /model/.../converse-stream).
 * 
 * Wire Format:
 * [0..3]   Total Message Length (UInt32BE)
 * [4..7]   Headers Length (UInt32BE)
 * [8..11]  Prelude CRC32 (UInt32BE) calculated on bytes 0..7
 * [12..]   Headers Buffer
 * [...]    Payload Buffer
 * [End-4]  Message CRC32 (UInt32BE) calculated on all bytes preceding CRC
 */

'use strict';

const zlib = require('zlib');

class EventStreamDecoder {
  /**
   * Decodes a buffer containing one or more AWS EventStream binary frames.
   * @param {Buffer} buffer - Raw received binary buffer
   * @returns {Array<Object>} List of decoded frames
   */
  static decodeFrames(buffer) {
    if (!Buffer.isBuffer(buffer)) {
      buffer = Buffer.from(buffer);
    }

    const frames = [];
    let offset = 0;

    while (offset < buffer.length) {
      if (offset + 12 > buffer.length) {
        break; // Incomplete prelude
      }

      const totalLen = buffer.readUInt32BE(offset);
      const headersLen = buffer.readUInt32BE(offset + 4);
      const preludeCrc = buffer.readUInt32BE(offset + 8);

      // Verify prelude CRC
      const preludeSlice = buffer.slice(offset, offset + 8);
      const computedPreludeCrc = zlib.crc32(preludeSlice);
      const preludeCrcValid = (preludeCrc === computedPreludeCrc);

      if (offset + totalLen > buffer.length) {
        // Frame is truncated or buffer boundary reached
        break;
      }

      // Verify message CRC
      const msgSlice = buffer.slice(offset, offset + totalLen - 4);
      const messageCrc = buffer.readUInt32BE(offset + totalLen - 4);
      const computedMsgCrc = zlib.crc32(msgSlice);
      const messageCrcValid = (messageCrc === computedMsgCrc);

      // Extract headers
      const headersStart = offset + 12;
      const headersEnd = headersStart + headersLen;
      const headersBuf = buffer.slice(headersStart, headersEnd);
      const headers = this.parseHeaders(headersBuf);

      // Extract payload
      const payloadStart = headersEnd;
      const payloadEnd = offset + totalLen - 4;
      const payloadBuf = buffer.slice(payloadStart, payloadEnd);
      const payloadText = payloadBuf.toString('utf-8');

      let payloadJson = null;
      try {
        payloadJson = payloadText ? JSON.parse(payloadText) : null;
      } catch (e) {
        // Raw text or binary
      }

      frames.push({
        totalLen,
        headersLen,
        preludeCrcValid,
        messageCrcValid,
        preludeCrc,
        messageCrc,
        headers,
        payloadText,
        payloadJson,
        payloadBuf
      });

      offset += totalLen;
    }

    return frames;
  }

  /**
   * Parse binary headers block according to AWS EventStream spec
   */
  static parseHeaders(headersBuf) {
    const headers = {};
    let offset = 0;

    while (offset < headersBuf.length) {
      const keyLen = headersBuf.readUInt8(offset);
      offset += 1;
      const key = headersBuf.slice(offset, offset + keyLen).toString('utf-8');
      offset += keyLen;

      const headerType = headersBuf.readUInt8(offset);
      offset += 1;

      if (headerType === 7) {
        // String value (Type 7)
        const valLen = headersBuf.readUInt16BE(offset);
        offset += 2;
        const val = headersBuf.slice(offset, offset + valLen).toString('utf-8');
        offset += valLen;
        headers[key] = val;
      } else if (headerType === 0) {
        // True
        headers[key] = true;
      } else if (headerType === 1) {
        // False
        headers[key] = false;
      } else if (headerType === 2) {
        // Byte
        headers[key] = headersBuf.readInt8(offset);
        offset += 1;
      } else if (headerType === 3) {
        // Short
        headers[key] = headersBuf.readInt16BE(offset);
        offset += 2;
      } else if (headerType === 4) {
        // Integer
        headers[key] = headersBuf.readInt32BE(offset);
        offset += 4;
      } else if (headerType === 5) {
        // Long (64-bit BigInt)
        headers[key] = headersBuf.readBigInt64BE(offset);
        offset += 8;
      } else {
        // Unknown type, skip or break
        break;
      }
    }

    return headers;
  }
}

module.exports = { EventStreamDecoder };
