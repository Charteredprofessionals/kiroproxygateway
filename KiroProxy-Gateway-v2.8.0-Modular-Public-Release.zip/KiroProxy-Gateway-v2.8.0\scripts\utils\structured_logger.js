/**
 * Structured Logger for KiroProxy Gateway
 * 
 * Provides consistent, structured logging with:
 * - Log levels (DEBUG, INFO, WARN, ERROR)
 * - Correlation IDs for request tracing
 * - JSON output option for log aggregation
 * - Performance timing helpers
 * - Provider-specific context
 * 
 * @module structured_logger
 */

const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

const LEVEL_NAMES = ['DEBUG', 'INFO', 'WARN', 'ERROR'];
const LEVEL_EMOJI = ['🔍', '📘', '⚠️', '❌'];
const LEVEL_COLORS = ['\x1b[36m', '\x1b[32m', '\x1b[33m', '\x1b[31m']; // Cyan, Green, Yellow, Red
const RESET_COLOR = '\x1b[0m';

class StructuredLogger {
  constructor(options = {}) {
    this.minLevel = LOG_LEVELS[options.level || 'INFO'];
    this.jsonOutput = options.jsonOutput || false;
    this.includeTimestamp = options.includeTimestamp !== false;
    this.colorize = options.colorize !== false && !this.jsonOutput;
  }

  /**
   * Log a message at specified level
   */
  log(level, component, message, context = {}) {
    const levelNum = typeof level === 'string' ? LOG_LEVELS[level] : level;
    
    if (levelNum < this.minLevel) return;
    
    const logEntry = {
      timestamp: new Date().toISOString(),
      level: LEVEL_NAMES[levelNum],
      component,
      message,
      ...context
    };
    
    if (this.jsonOutput) {
      console.log(JSON.stringify(logEntry));
    } else {
      const emoji = LEVEL_EMOJI[levelNum];
      const color = this.colorize ? LEVEL_COLORS[levelNum] : '';
      const reset = this.colorize ? RESET_COLOR : '';
      
      let output = `${emoji} ${color}[${component}]${reset} ${message}`;
      
      // Add context if present
      if (Object.keys(context).length > 0) {
        const contextStr = Object.entries(context)
          .filter(([k]) => k !== 'correlationId') // Don't duplicate correlation ID
          .map(([k, v]) => `${k}=${JSON.stringify(v)}`)
          .join(' ');
        if (contextStr) {
          output += ` ${color}|${reset} ${contextStr}`;
        }
      }
      
      console.log(output);
    }
  }

  debug(component, message, context) {
    this.log(LOG_LEVELS.DEBUG, component, message, context);
  }

  info(component, message, context) {
    this.log(LOG_LEVELS.INFO, component, message, context);
  }

  warn(component, message, context) {
    this.log(LOG_LEVELS.WARN, component, message, context);
  }

  error(component, message, context) {
    this.log(LOG_LEVELS.ERROR, component, message, context);
  }

  /**
   * Create a timer for measuring operation duration
   */
  startTimer(component, operation, context = {}) {
    const startTime = Date.now();
    
    return {
      end: (additionalContext = {}) => {
        const duration = Date.now() - startTime;
        this.info(component, `${operation} completed`, {
          ...context,
          ...additionalContext,
          durationMs: duration
        });
        return duration;
      },
      
      fail: (error, additionalContext = {}) => {
        const duration = Date.now() - startTime;
        this.error(component, `${operation} failed`, {
          ...context,
          ...additionalContext,
          durationMs: duration,
          error: error.message || String(error)
        });
        return duration;
      }
    };
  }

  /**
   * Log retry attempt
   */
  retry(component, provider, attempt, maxAttempts, error, delayMs, context = {}) {
    const isRateLimit = String(error).includes('429') || String(error).includes('rate limit');
    this.warn(component, `Retry attempt ${attempt}/${maxAttempts}`, {
      provider,
      errorType: isRateLimit ? 'RATE_LIMIT' : 'ERROR',
      error: error.message || String(error),
      retryDelayMs: delayMs,
      ...context
    });
  }

  /**
   * Log provider call
   */
  providerCall(provider, model, success, latencyMs, context = {}) {
    const level = success ? LOG_LEVELS.INFO : LOG_LEVELS.WARN;
    const message = success ? `Provider call succeeded` : `Provider call failed`;
    
    this.log(level, 'Provider', message, {
      provider,
      model,
      success,
      latencyMs,
      ...context
    });
  }

  /**
   * Log otomode model switch
   */
  otomodeSwitch(provider, fromModel, toModel, reason, remainingModels, context = {}) {
    this.info('Otomode', `Switching model due to ${reason}`, {
      provider,
      fromModel,
      toModel,
      remainingModels,
      ...context
    });
  }

  /**
   * Log otomode exhaustion
   */
  otomodeExhausted(provider, totalModels, context = {}) {
    this.error('Otomode', `All models exhausted for provider`, {
      provider,
      totalModels,
      ...context
    });
  }

  /**
   * Log circuit breaker state change
   */
  circuitBreakerStateChange(provider, oldState, newState, context = {}) {
    const level = newState === 'OPEN' ? LOG_LEVELS.ERROR : LOG_LEVELS.INFO;
    this.log(level, 'CircuitBreaker', `State changed: ${oldState} → ${newState}`, {
      provider,
      oldState,
      newState,
      ...context
    });
  }

  /**
   * Log tool execution
   */
  toolExecution(toolName, success, durationMs, context = {}) {
    const level = success ? LOG_LEVELS.INFO : LOG_LEVELS.ERROR;
    const message = success ? `Tool executed` : `Tool execution failed`;
    
    this.log(level, 'Tool', message, {
      toolName,
      success,
      durationMs,
      ...context
    });
  }

  /**
   * Log custom provider discovery
   */
  customProviderDiscovery(providerName, modelsDiscovered, totalModels, context = {}) {
    this.info('CustomProvider', `Discovery completed`, {
      provider: providerName,
      modelsDiscovered,
      totalModels,
      ...context
    });
  }

  /**
   * Log request received
   */
  requestReceived(method, path, correlationId, context = {}) {
    this.info('HTTP', `${method} ${path}`, {
      correlationId,
      ...context
    });
  }

  /**
   * Log response sent
   */
  responseSent(statusCode, durationMs, correlationId, context = {}) {
    const level = statusCode >= 400 ? LOG_LEVELS.WARN : LOG_LEVELS.INFO;
    this.log(level, 'HTTP', `Response sent`, {
      statusCode,
      durationMs,
      correlationId,
      ...context
    });
  }
}

// Create default logger instance
const defaultLogger = new StructuredLogger({
  level: process.env.LOG_LEVEL || 'INFO',
  jsonOutput: process.env.LOG_FORMAT === 'json',
  colorize: process.env.NO_COLOR !== '1'
});

// Export both class and default instance
module.exports = StructuredLogger;
module.exports.logger = defaultLogger;
module.exports.LOG_LEVELS = LOG_LEVELS;

// Convenience methods on module.exports
module.exports.debug = (component, message, context) => defaultLogger.debug(component, message, context);
module.exports.info = (component, message, context) => defaultLogger.info(component, message, context);
module.exports.warn = (component, message, context) => defaultLogger.warn(component, message, context);
module.exports.error = (component, message, context) => defaultLogger.error(component, message, context);
module.exports.startTimer = (component, operation, context) => defaultLogger.startTimer(component, operation, context);
