# KiroProxy Gateway — Enterprise Architecture & Integration Guide

**Date:** October 2026  
**Status:** ✅ PRODUCTION READY (v2.7.0 Dual-Mode & 5-Tier Fallback Edition)  
**Verification:** Live Multi-Provider Suite Passing (100% Operational)

---

## 🔍 System Overview & Executive Summary

**KiroProxy Gateway** enables zero-cost, enterprise-grade AI development inside **Kiro IDE** (GUI) and **Kiro CLI** (Terminal).

By locally intercepting AWS Bedrock cloud runtime inference endpoints and emulating AWS EventStream frames, Kiro IDE retains **100% of its native IDE superpowers** — including Spec-Driven Development, subagents, filesystem diffing, interactive task checklists, and steering supervisors — while replacing paid AWS Bedrock cloud dependencies with free upstream models.

> [!IMPORTANT]
> **Naming Distinction:**
> - **KiroProxy Gateway:** This local proxy server, repository, batch launchers, and Kiro IDE extension patcher running on `http://127.0.0.1:8084`.
> - **Kilo Gateway:** The external upstream AI service (`https://api.kilo.ai`) providing free inference on Gemma 4 26B without API keys.

---

## 🏗️ Technical Architecture & The Core Moving Parts

```
========================= YOUR LOCAL MACHINE =========================
  🖥️  KIRO IDE (GUI)                     ⌨️  KIRO CLI (Terminal)
  ─────────────────────────────────────────────────────────────────
  ✅ Spec-Driven Dev (3-Spec)             ✅ Interactive Terminal REPL
  ✅ Task Runner & Checklist UI           ✅ Local Shell / PowerShell
  ✅ Subagents (general, context)         ✅ MCP Tool Client (mcp.json)
  ✅ File Editor & Diff Reviews           ✅ Git Status & Auto-Commits
  ✅ Integrated Terminal (pwsh/bash)      ✅ Agent Switching (~/.kiro/agents)
  ✅ Steering Files (.kiro/steering/)     ✅ File System Tools
  ✅ MCP Client & Protocol Host           ✅ Context Management
  ─────────────────────────────────────────────────────────────────
                                │
                                ▼ (AWS Bedrock Converse Streaming via Port 8084)
                 Local KiroProxy Gateway (127.0.0.1:8084)
                 ├── Binary EventStream Framing (CRC32 Checksums)
                 ├── Autonomous Tool Call Normalizer
                 ├── 5-Tier Auto-Fallback Engine
                 └── Isolated Canvas Bridge Controller (/canvas, /poll)
=====================================================================
            │                                             │
            ▼ (REST HTTPS JSON)                           ▼ (Browser WebSocket / Poll)
================ UPSTREAM REST PROVIDERS ================  === BROWSER CANVAS BRIDGE ===
  1. Kilo Gateway (api.kilo.ai - Gemma 4 26B)                Google Gemini Web Session
  2. Cline API Free Tier (cline-free)                        (gemini.google.com)
  3. OpenRouter Free Tier (:free models)                     Model: gemini-3-flash-preview
  4. OrcaRouter Free Tier (orca-free)                        Cost: $0 (zero external keys)
  5. Custom Models (Groq, Ollama, DeepSeek)
=========================================================  =============================
```

---

## 🔄 The 5-Tier Auto-Fallback Engine

When requests target `auto` or an upstream provider returns an error (timeout, HTTP 429, 502, 503), KiroProxy Gateway automatically cascades through:

$$\mathbf{Kilo\ Gateway} \longrightarrow \mathbf{Cline\ Free} \longrightarrow \mathbf{OpenRouter\ Free} \longrightarrow \mathbf{OrcaRouter} \longrightarrow \mathbf{Custom\ Models}$$

1. **Tier 1 — Kilo Gateway (`https://api.kilo.ai`):** Anonymous, zero-auth, zero-cost Gemma 4 26B model.
2. **Tier 2 — Cline API Free Tier (`https://api.cline.bot`):** Auto-discovered coding models.
3. **Tier 3 — OpenRouter Free Tier (`https://openrouter.ai`):** Strictly filtered models with `:free` slug.
4. **Tier 4 — OrcaRouter Free Tier (`https://api.orcarouter.ai`):** Auto-discovered free tier endpoints.
5. **Tier 5 — Custom Models:** User-configured endpoints in `config/kiro_ai_config.json` (Groq, Ollama, DeepSeek).

---

## 🌐 The Ngrok Gemini Canvas Bridge

The Ngrok Canvas Bridge operates as an **architecturally isolated** browser-assisted reverse tunnel:
- **Zero API Key Requirement:** Relies on an active, authenticated browser tab at `https://gemini.google.com`.
- **Dedicated Dashboard:** Hosted locally at `http://127.0.0.1:8084/canvas` with client-side polling loops.
- **Protocol Invariant:** Canvas Bridge endpoints (`/canvas`, `/poll`, `/chunk`, `/done`) strictly precede the universal AWS Bedrock catch-all handler.

---

## ⚙️ Kiro IDE Dynamic Dual-Mode Extension Patching

Located in `kiro.kiro-agent/dist/extension.js`:
1. **Patch 1 (Model Catalog):** Injects unified catalog fallback pointing to `http://127.0.0.1:8084/listAvailableModels`.
2. **Patch 2 (CloudConfig Conditional):** Bypasses AWS Cloud credentials when local proxy is active.
3. **Patch 3A (KRS Client Dynamic Endpoint):** Intercepts minified KRS endpoint resolvers (`Bte` / `Zee` / `RKo`) to route Bedrock client instances and converse streaming to `http://127.0.0.1:8084`.
4. **Patch 3B (Runtime Prompt URL / getTarget Interceptor):** Intercepts `getTarget()` when a prompt is sent, routing `POST /generateAssistantResponse` requests directly to `http://127.0.0.1:8084` and bypassing AWS region/login restrictions (`oos.has(n)`).

---

*KiroProxy Gateway v2.7.0 — Engineering zero-cost AI systems with production resilience.*
