/**
 * src/config/index.js - Configuration loader & environment validator
 * Pure CommonJS exportable module
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
require('dotenv').config();

const CONFIG_FILE = path.join(__dirname, '..', '..', 'config', 'kiro_ai_config.json');
const LOCAL_CONFIG_FILE = path.join(__dirname, '..', '..', 'config', 'kiro_ai_config.local.json');
const USER_GLOBAL_CONFIG = path.join(os.homedir(), '.kiro', 'kiro_ai_config.json');

const DEFAULT_PORT = 8084;
const PROXY_PORT = process.env.PROXY_PORT
  ? parseInt(process.env.PROXY_PORT, 10)
  : (process.env.PORT ? parseInt(process.env.PORT, 10) : DEFAULT_PORT);

function isKeyValid(k) {
  // Support both old (AIza) and new (AQ.) Google API key formats
  return k && typeof k === 'string' && k.trim().length > 0 && 
         !k.trim().toLowerCase().startsWith('paste-your-') &&
         !k.includes('YOUR_') && !k.includes('_HERE') &&
         k !== 'your-key-here';
}

function loadCustomConfig() {
  const defaults = {
    provider: process.env.AI_PROVIDER || 'kilo',
    baseUrl: process.env.AI_BASE_URL || 'https://api.kilo.ai/api/gateway',
    model: process.env.AI_MODEL || 'kilo-auto/small',
    timeoutMs: 120000,
    
    // Multi-key fallback arrays for ALL providers
    kiloApiKeys: [
      process.env.KILO_API_KEY || '',
      ''
    ].filter(k => isKeyValid(k)),
    
    clineApiKeys: [
      process.env.CLINE_API_KEY || '',
      ''
    ].filter(k => isKeyValid(k)),
    
    openrouterApiKeys: [
      process.env.OPENROUTER_API_KEY || process.env.AI_API_KEY || '',
      ''
    ].filter(k => isKeyValid(k)),
    
    orcarouterApiKeys: [
      process.env.ORCAROUTER_API_KEY || '',
      process.env.ORCAROUTER_API_KEY_2 || '',
    ].filter(k => isKeyValid(k)),
    
    geminiApiKeys: [],
    
    currentKeyIndex: {
      kilo: 0,
      cline: 0,
      openrouter: 0,
      orcarouter: 0,
      gemini: 0
    },
    
    kiloApiKey: '',
    clineApiKey: '',
    apiKey: '',
    geminiApiKey: '',

    // Global Automode 6-Tier Priority Order (user-reorderable)
    providerPriorityOrder: ['kilo', 'cline', 'openrouter', 'orcarouter', 'gemini', 'custom'],

    // Core Provider Multi-Base-URL Failover Chains (user-reorderable)
    providerBaseUrls: {
      kilo: ['https://api.kilo.ai/api/gateway'],
      cline: ['https://api.cline.bot/api/v1'],
      openrouter: ['https://openrouter.ai/api/v1'],
      orcarouter: ['https://api.orcarouter.ai/v1'],
      gemini: ['https://generativelanguage.googleapis.com/v1beta']
    }
  };

  const DEFAULT_TIERS = ['kilo', 'cline', 'openrouter', 'orcarouter', 'gemini', 'custom'];

  function normalizeCustomProvider(item, fallbackItem = {}) {
    const rawUrls = [
      ...(Array.isArray(item.baseUrls) ? item.baseUrls : []),
      ...(item.baseUrl ? [item.baseUrl] : []),
      ...(Array.isArray(fallbackItem.baseUrls) ? fallbackItem.baseUrls : []),
      ...(fallbackItem.baseUrl ? [fallbackItem.baseUrl] : [])
    ].map(u => (typeof u === 'string' ? u.trim() : '')).filter(Boolean);
    const baseUrls = [...new Set(rawUrls)];

    const rawKeys = [
      ...(Array.isArray(item.apiKeys) ? item.apiKeys : []),
      ...(isKeyValid(item.apiKey) ? [item.apiKey.trim()] : []),
      ...(Array.isArray(fallbackItem.apiKeys) ? fallbackItem.apiKeys : []),
      ...(isKeyValid(fallbackItem.apiKey) ? [fallbackItem.apiKey.trim()] : [])
    ].map(k => (typeof k === 'string' ? k.trim() : '')).filter(k => isKeyValid(k));
    const apiKeys = [...new Set(rawKeys)];

    return {
      ...fallbackItem,
      ...item,
      baseUrls,
      baseUrl: baseUrls[0] || item.baseUrl || fallbackItem.baseUrl || '',
      apiKeys,
      apiKey: apiKeys[0] || (isKeyValid(item.apiKey) ? item.apiKey : (fallbackItem.apiKey || ''))
    };
  }

  const filesToCheck = [CONFIG_FILE, USER_GLOBAL_CONFIG, LOCAL_CONFIG_FILE];
  let merged = { ...defaults };

  for (const cfgPath of filesToCheck) {
    if (fs.existsSync(cfgPath)) {
      try {
        let content = fs.readFileSync(cfgPath, 'utf-8');
        if (content.charCodeAt(0) === 0xFEFF) {
          content = content.slice(1);
        }
        content = content.trim();
        if (!content) continue;
        const parsed = JSON.parse(content);
        for (const [key, val] of Object.entries(parsed)) {
          if (key.startsWith('_')) continue; // skip _comment, _instructions etc
          if (key === 'providerPriorityOrder' && Array.isArray(val) && val.length > 0) {
            const cleanOrder = val.map(v => String(v).toLowerCase().trim()).filter(v => DEFAULT_TIERS.includes(v));
            for (const t of DEFAULT_TIERS) {
              if (!cleanOrder.includes(t)) cleanOrder.push(t);
            }
            merged.providerPriorityOrder = cleanOrder;
          } else if (key === 'providerBaseUrls' && val && typeof val === 'object' && !Array.isArray(val)) {
            merged.providerBaseUrls = { ...merged.providerBaseUrls };
            for (const [pName, urls] of Object.entries(val)) {
              if (Array.isArray(urls)) {
                const cleaned = urls.map(u => String(u).trim()).filter(Boolean);
                if (cleaned.length > 0) merged.providerBaseUrls[pName] = [...new Set(cleaned)];
              }
            }
          } else if (Array.isArray(val)) {
            if (key === 'customProviders') {
              const existing = Array.isArray(merged.customProviders) ? [...merged.customProviders] : [];
              const updatedList = [];
              for (const item of val) {
                if (!item || !item.name) continue;
                const idx = existing.findIndex(p => p.name && p.name.toLowerCase() === item.name.toLowerCase());
                if (idx >= 0) {
                  updatedList.push(normalizeCustomProvider(item, existing[idx]));
                  existing.splice(idx, 1);
                } else {
                  updatedList.push(normalizeCustomProvider(item));
                }
              }
              merged.customProviders = [...updatedList, ...existing.map(e => normalizeCustomProvider(e))];
            } else if (Array.isArray(merged[key])) {
              // Put user's explicit config array order first, followed by env defaults
              merged[key] = [...new Set([...val.filter(k => isKeyValid(k)), ...merged[key]])];
            } else {
              merged[key] = val;
            }
          } else if (val && typeof val === 'object') {
            merged[key] = { ...(merged[key] || {}), ...val };
          } else if (isKeyValid(val) || (typeof val === 'number') || (typeof val === 'boolean')) {
            merged[key] = val;
          }
        }
      } catch (err) {
        console.warn(`[Config] Failed to read ${path.basename(cfgPath)}:`, err.message);
      }
    }
  }

  // Ensure all customProviders are normalized with baseUrls[] and apiKeys[]
  if (Array.isArray(merged.customProviders)) {
    merged.customProviders = merged.customProviders.map(p => normalizeCustomProvider(p));
  }

  // Normalize provider keys if present in providers object
  if (merged.providers?.orcarouter?.apiKey && !merged.orcarouterApiKey) {
    merged.orcarouterApiKey = merged.providers.orcarouter.apiKey;
  }
  if (merged.providers?.cline?.apiKey && !merged.clineApiKey) {
    merged.clineApiKey = merged.providers.cline.apiKey;
  }
  if (merged.providers?.openrouter?.apiKey && !merged.openrouterApiKey) {
    merged.openrouterApiKey = merged.providers.openrouter.apiKey;
  }
  if (merged.providers?.gemini?.apiKey && !merged.geminiApiKey) {
    merged.geminiApiKey = merged.providers.gemini.apiKey;
  }
  if (merged.providers?.kilo?.apiKey && !merged.kiloApiKey) {
    merged.kiloApiKey = merged.providers.kilo.apiKey;
  }

  // Support environment variables for all providers
  if (!merged.geminiApiKey && process.env.GEMINI_API_KEY) {
    merged.geminiApiKey = process.env.GEMINI_API_KEY;
  }
  
  // Merge single keys into arrays (append if valid and not already in array so explicit array priority is preserved)
  const providerKeyMappings = [
    { single: 'geminiApiKey', array: 'geminiApiKeys' },
    { single: 'clineApiKey', array: 'clineApiKeys' },
    { single: 'kiloApiKey', array: 'kiloApiKeys' },
    { single: 'apiKey', array: 'openrouterApiKeys' },           // legacy field name
    { single: 'openrouterApiKey', array: 'openrouterApiKeys' }, // current field name
    { single: 'orcarouterApiKey', array: 'orcarouterApiKeys' }
  ];
  
  for (const { single, array } of providerKeyMappings) {
    if (merged[single] && isKeyValid(merged[single])) {
      if (!merged[array]) merged[array] = [];
      if (!merged[array].includes(merged[single])) {
        merged[array] = [...merged[array], merged[single]];
      }
    }
  }
  
  // Set current active key for each provider from their arrays
  const providerNames = ['kilo', 'cline', 'openrouter', 'orcarouter', 'gemini'];
  for (const provider of providerNames) {
    const arrayKey = `${provider}ApiKeys`;
    const singleKey = provider === 'openrouter' ? 'apiKey' : `${provider}ApiKey`;
    
    if (merged[arrayKey] && merged[arrayKey].length > 0) {
      const idx = merged.currentKeyIndex?.[provider] || 0;
      merged[singleKey] = merged[arrayKey][Math.min(idx, merged[arrayKey].length - 1)];
      if (provider === 'openrouter') {
        merged.openrouterApiKey = merged[singleKey];
      }
    }
  }

  return merged;
}

module.exports = {
  loadCustomConfig,
  isKeyValid,
  CONFIG_PATHS: { CONFIG_FILE, USER_GLOBAL_CONFIG, LOCAL_CONFIG_FILE },
  DEFAULT_PORT,
  PROXY_PORT
};
