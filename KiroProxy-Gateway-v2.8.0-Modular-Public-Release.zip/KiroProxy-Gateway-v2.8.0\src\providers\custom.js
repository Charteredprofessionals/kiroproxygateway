/**
 * src/providers/custom.js - Custom / OpenAI-Compatible Provider Adapter
 * Pure CommonJS exportable module
 */

'use strict';

const http = require('http');
const https = require('https');
const { URL } = require('url');
const { ProxyError } = require('../resilience/errors');
const { MODELS } = require('../config/catalog');
const { translateToolsToUpstream } = require('../translators/tool_translator');
const { extractToolsAndTextFromProviderResponse } = require('../translators/tool_extractor');

function callCustomApi(cfg, messages, requestedModel, tools = [], otomodeContext = null) {
  const baseUrls = (Array.isArray(cfg.baseUrls) && cfg.baseUrls.length > 0)
    ? cfg.baseUrls.filter(Boolean)
    : (cfg.baseUrl ? [cfg.baseUrl] : []);
  const apiKeys = (Array.isArray(cfg.apiKeys) && cfg.apiKeys.length > 0)
    ? cfg.apiKeys.filter(Boolean)
    : (cfg.apiKey ? [cfg.apiKey] : []);

  const urlIdx = typeof cfg._urlIdx === 'number' ? cfg._urlIdx : 0;
  const keyIdx = typeof cfg._keyIdx === 'number' ? cfg._keyIdx : 0;
  const activeBaseUrl = baseUrls[urlIdx] || cfg.baseUrl || '';
  const activeApiKey = apiKeys[keyIdx] || cfg.apiKey || '';

  return new Promise((resolve, reject) => {
    let modelName = requestedModel || cfg.model;
    if (requestedModel === 'openrouter-deepseek') modelName = 'deepseek/deepseek-chat';
    else if (requestedModel === 'openrouter-claude') modelName = 'anthropic/claude-3.7-sonnet';
    else if (requestedModel === 'cline-deepseek-v4-flash') modelName = 'deepseek-ai/DeepSeek-V4-Flash';
    else if (requestedModel === 'cline-glm-flash') modelName = 'glm-5.3-flash';
    else if (requestedModel === 'cline-longcat-2') modelName = 'cline-free/longcat-2.0';
    else if (requestedModel === 'cline-laguna-s') modelName = 'poolside/laguna-s-2.1:free';
    else if (requestedModel === 'cline-nemotron') modelName = 'nvidia/nemotron-3.5-lightning';
    else if (requestedModel === 'cline-llama-free') modelName = 'meta-llama/llama-3.3-70b-instruct:free';
    else if (requestedModel === 'cline-deepseek-free') modelName = 'deepseek/deepseek-r1:free';
    else if (requestedModel === 'cline-qwen-free') modelName = 'qwen/qwen-2.5-coder-32b-instruct:free';
    else {
      const found = MODELS.models.find(m => m.modelId === requestedModel);
      if (found?.upstreamSlug) modelName = found.upstreamSlug;
    }

    const urlObj = new URL(activeBaseUrl.endsWith('/chat/completions') ? activeBaseUrl : `${activeBaseUrl.replace(/\/+$/, '')}/chat/completions`);
    const isHttps = urlObj.protocol === 'https:';
    const client = isHttps ? https : http;

    const translatedTools = tools && tools.length > 0
      ? translateToolsToUpstream(tools, 'openai')
      : undefined;

    const requestBody = {
      model: modelName,
      messages: messages,
      stream: false
    };

    if (translatedTools) {
      requestBody.tools = translatedTools;
    }

    const postData = JSON.stringify(requestBody);

    const headers = {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData),
      'Authorization': `Bearer ${activeApiKey}`
    };

    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method: 'POST',
      headers: headers,
      timeout: cfg.timeoutMs || 120000
    };

    const tryNextKeyOrUrl = (reasonMsg) => {
      if (keyIdx + 1 < apiKeys.length) {
        console.log(`[CustomKeyRotator] 🔄 Rotating API key (${keyIdx + 1}/${apiKeys.length} → ${keyIdx + 2}/${apiKeys.length}) on ${urlObj.hostname} (${reasonMsg})`);
        callCustomApi({ ...cfg, baseUrls, apiKeys, _urlIdx: urlIdx, _keyIdx: keyIdx + 1 }, messages, requestedModel, tools, otomodeContext)
          .then(resolve)
          .catch(reject);
        return true;
      }
      if (urlIdx + 1 < baseUrls.length) {
        console.log(`[CustomUrlFailover] 🌐 Switching Base URL (${urlIdx + 1}/${baseUrls.length} → ${urlIdx + 2}/${baseUrls.length}): ${activeBaseUrl} → ${baseUrls[urlIdx + 1]} (${reasonMsg})`);
        callCustomApi({ ...cfg, baseUrls, apiKeys, _urlIdx: urlIdx + 1, _keyIdx: 0 }, messages, requestedModel, tools, otomodeContext)
          .then(resolve)
          .catch(reject);
        return true;
      }
      return false;
    };

    console.log(`[KiroProxy] Forwarding to Custom API (${urlObj.hostname}, model: ${modelName}${translatedTools ? `, ${translatedTools.length} tools` : ''})...`);

    const req = client.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            const extracted = extractToolsAndTextFromProviderResponse(parsed, tools);
            const hasValidContent = Boolean(((extracted.text && extracted.text.trim().length > 0) || (extracted.toolCalls && extracted.toolCalls.length > 0)) && !parsed.error);

            if (hasValidContent) {
              resolve({
                ...parsed,
                _kiro: extracted
              });
              return;
            }

            console.warn(`[KiroProxy] ⚠️ Custom API returned HTTP 200 with empty completion (0 text, 0 tools) for model '${modelName}'`);

            if (tryNextKeyOrUrl('EMPTY_RESPONSE HTTP 200')) {
              return;
            }

            if (otomodeContext && otomodeContext._fallbackList && otomodeContext._fallbackList.length > 0) {
              const oldModel = otomodeContext._activeModel || modelName || requestedModel;
              const nextModel = otomodeContext._fallbackList.shift();
              otomodeContext._activeModel = nextModel;
              const delay = 50;
              console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName || 'Custom'}) from ${oldModel} → ${nextModel} due to EMPTY_RESPONSE (HTTP 200)`);
              (async () => {
                await new Promise(r => setTimeout(r, delay));
                try {
                  const result = await callCustomApi({ ...cfg, baseUrls, apiKeys, _urlIdx: 0, _keyIdx: 0, model: nextModel }, messages, nextModel, tools, otomodeContext);
                  resolve(result);
                } catch (err) {
                  reject(err);
                }
              })();
              return;
            }

            if (otomodeContext && (!otomodeContext._fallbackList || otomodeContext._fallbackList.length === 0)) {
              console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName || 'Custom'}`);
            }

            const err = new ProxyError(
              'EMPTY_RESPONSE',
              `Custom API (${res.statusCode}): Model returned 0 text and 0 tools`,
              'Free model context saturated or empty completion received',
              { statusCode: res.statusCode }
            );
            err.code = 'EMPTY_RESPONSE';
            return reject(err);
          } else {
            if (translatedTools && (res.statusCode === 400 || res.statusCode === 422)) {
              console.log(`[KiroProxy] 🔄 Custom API model '${modelName}' rejected native tools (${res.statusCode}); retrying with prompt-based tool guide...`);
              callCustomApi(cfg, messages, requestedModel, [], otomodeContext).then(resolve).catch(reject);
              return;
            }
            if (res.statusCode >= 400 && tryNextKeyOrUrl(`HTTP ${res.statusCode}`)) {
              return;
            }
            if (otomodeContext && otomodeContext._fallbackList.length > 0 && res.statusCode >= 400) {
              const oldModel = otomodeContext._activeModel;
              const nextModel = otomodeContext._fallbackList.shift();
              if (nextModel) {
                otomodeContext._activeModel = nextModel;
                const delay = 250 + Math.random() * 500;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName}) from ${oldModel} → ${nextModel} due to HTTP ${res.statusCode} (${otomodeContext._fallbackList.length} free models remaining)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callCustomApi({ ...cfg, baseUrls, apiKeys, _urlIdx: 0, _keyIdx: 0, model: nextModel }, messages, nextModel, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }
            }
            reject(new Error(`API error (${res.statusCode}): ${parsed.error?.message || data}`));
          }
        } catch {
          if (tryNextKeyOrUrl(`Invalid JSON HTTP ${res.statusCode}`)) return;
          reject(new Error(`Invalid JSON from API (${res.statusCode}): ${data.slice(0, 150)}`));
        }
      });
    });

    req.on('error', (err) => {
      if (tryNextKeyOrUrl(err.message)) return;
      reject(err);
    });
    req.on('timeout', () => {
      req.destroy();
      if (tryNextKeyOrUrl('timeout')) return;
      reject(new Error('API request timed out'));
    });
    req.write(postData);
    req.end();
  });
}

module.exports = {
  callCustomApi
};
