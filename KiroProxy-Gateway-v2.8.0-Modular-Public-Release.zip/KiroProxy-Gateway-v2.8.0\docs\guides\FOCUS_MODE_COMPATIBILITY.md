# Kiro Agent Focus Mode Compatibility

## Summary

**Status:** ⚠️ PARTIALLY COMPATIBLE (Direct Execution Only)

Kiro Agent Focus Mode works with the proxy gateway but **without workflow orchestration**. All tasks are executed directly in the current session using standard tools.

## What Works ✅

### Core Functionality
- ✅ Chat completions with any of 436 free models
- ✅ Tool execution (file operations, terminal, MCP tools)
- ✅ Direct implementation tasks
- ✅ Multi-file code changes
- ✅ Code analysis and debugging
- ✅ Test execution and verification
- ✅ MCP tool invocations

### Example Working Scenarios
- "Fix this bug in the codebase"
- "Implement this feature across multiple files"
- "Refactor this module"
- "Debug this error and run tests"
- "Add logging to these functions"

## What Doesn't Work ❌

### Workflow Orchestration (Not Supported)
- ❌ `run_workflow` - Launch multi-step workflows
- ❌ `inspect_workflow` - Check workflow progress
- ❌ `update_workflow` - Modify running workflows
- ❌ `validate_workflow` - Validate workflow definitions
- ❌ Multi-agent parallel execution via workflows
- ❌ Workflow state persistence
- ❌ Long-running background workflows

## How It Works

### Automatic Mode Detection

The gateway includes a steering file that automatically activates when using proxy models:

**File:** `.kiro/steering/proxy-mode.md`

```yaml
---
inclusion: auto
name: Proxy Mode
description: Conditionally enforce direct execution for Gateway providers
---
```

This steering file:
1. Detects when you're using gateway models (kilo-*, cline-*, orca-*, etc.)
2. Instructs the AI to use direct execution only
3. Prevents workflow API calls that would fail
4. Automatically deactivates when using native AWS Cloud models

### Workflow Compatibility Layer

The proxy server includes graceful handling for workflow requests:

```javascript
// When Kiro IDE tries to use workflows:
if (urlPath.includes('/runtime/workflows/run')) {
  console.log('[KiroProxy] 🔄 Workflow request received - converting to direct execution');
  
  return {
    status: 'not_supported',
    message: 'Workflows not available in proxy mode. Using direct execution instead.',
    fallbackMode: 'direct_execution'
  };
}
```

**Result:** Instead of crashing, the request is gracefully converted to direct execution.

## Execution Flow Comparison

### With Native AWS Cloud (Full Workflows)

```
User: "Implement feature X"
    ↓
AI Agent: Analyzes task complexity
    ↓
Decision: Complex → Launch workflow
    ↓
run_workflow: 
  - Step 1: Investigation (sub-agent)
  - Step 2: Design (sub-agent)
  - Step 3: Implementation (sub-agent)
  - Step 4: Review (sub-agent)
    ↓
Each step runs independently
Progress notifications sent
State persisted between steps
```

### With Proxy Gateway (Direct Execution)

```
User: "Implement feature X"
    ↓
AI Agent: Detects proxy mode
    ↓
Steering file: "Use direct execution only"
    ↓
Direct Implementation:
  - Read files
  - Analyze code
  - Make changes
  - Run tests
  - Verify results
    ↓
All done in single session
No workflow orchestration needed
```

## Model Selection Strategy

### Use Proxy Models (436 free) When:
✅ Task is straightforward (even if multi-file)
✅ You can monitor progress yourself
✅ You don't need parallel sub-agents
✅ Direct execution is acceptable
✅ You want zero-cost AI access

**Examples:**
- Bug fixes
- Feature implementations
- Code refactoring
- Adding tests
- Documentation updates

### Use Native AWS Cloud Models When:
⚠️ Task needs workflow decomposition
⚠️ You need parallel sub-agent execution
⚠️ Long-running autonomous workflows required
⚠️ You need workflow state management
⚠️ Task needs structured orchestration

**Examples:**
- Large multi-subsystem refactors
- Complex investigations requiring specialized agents
- Tasks with 10+ interdependent steps
- Projects needing persistent workflow state

## Supported Models for Focus Mode

All 436 free models work with Focus Mode direct execution:

### Auto Fallback
- `auto` - Smart routing

### Kilo Gateway (343+ models)
- `kilogateway` - Free Gemma 4 26B
- `kilo/*` - All Kilo models

### Cline API (68+ models)
- `cline-deepseek-v4-flash`
- `cline-glm-flash`
- `cline-longcat-2`
- `cline/*` - All Cline models

### OpenRouter (20+ models)
- `openrouter-free/*` - Free tier only

### OrcaRouter (6+ models)
- `orca-*` - Free tier only

### Ngrok Canvas Bridge
- `ngrok-gemini-flash` - Zero-cost Gemini

## Testing Focus Mode

### 1. Select a Proxy Model

Choose any model from the 436 free options:
- `auto` (recommended for testing)
- `kilogateway`
- `cline-deepseek-v4-flash`

### 2. Enable Focus Mode

In Kiro IDE:
- Toggle Focus Mode ON
- Or use slash command: `/focus`

### 3. Give It a Task

Try a test task:
```
Create a simple hello world function in Python, 
add tests, and verify it works
```

### 4. Observe Behavior

**Expected:**
- ✅ AI works directly in your session
- ✅ Creates files, runs tests, verifies
- ✅ No workflow orchestration attempts
- ✅ Task completes successfully

**Not Expected:**
- ❌ Workflow launch attempts
- ❌ Sub-agent coordination
- ❌ Workflow progress notifications

## Troubleshooting

### "Workflow not supported" Error

**Symptom:**
```
Error: Workflows are not supported in proxy mode
```

**Cause:** AI tried to launch workflow despite steering file

**Solution:**
1. Verify steering file exists: `.kiro/steering/proxy-mode.md`
2. Restart Kiro IDE to reload steering files
3. Ensure you're using a gateway model (not native AWS)
4. The AI should automatically adapt on retry

### Focus Mode Seems Slow

**Cause:** Direct execution can be slower than parallel workflow execution for very large tasks

**Solutions:**
- Break large tasks into smaller chunks
- Use native AWS Cloud models for truly complex workflows
- Most tasks work fine with direct execution

### Tools Not Working

**Symptom:** File operations or terminal commands fail

**Cause:** This is NOT related to Focus Mode - check tool permissions

**Solution:**
- Verify file paths are correct
- Check file permissions
- Ensure terminal commands work manually
- See troubleshooting docs for specific tool issues

## Performance Comparison

### Direct Execution (Proxy)
**Pros:**
- ✅ Zero cost (all free models)
- ✅ Simple, predictable behavior
- ✅ Easy to monitor and debug
- ✅ No workflow complexity

**Cons:**
- ⚠️ Single-threaded (no parallelism)
- ⚠️ All work in one session
- ⚠️ No state persistence between sessions

### Workflow Orchestration (Native Cloud)
**Pros:**
- ✅ Parallel sub-agent execution
- ✅ State persistence
- ✅ Progress tracking
- ✅ Structured task decomposition

**Cons:**
- 💰 Costs credits (AWS Cloud usage)
- ⚠️ More complex (can be overkill for simple tasks)
- ⚠️ Harder to debug

## Recommendations

### For 90% of Tasks
**Use Proxy Models with Direct Execution**
- Free, fast, and effective
- Works great for most development tasks
- Focus Mode still provides benefits (focused attention, tool use)

### For 10% of Complex Projects
**Use Native AWS Cloud with Full Workflows**
- When you genuinely need orchestration
- Large multi-step projects
- Parallel agent coordination required

### Hybrid Approach
1. **Start with proxy models** for exploration and initial implementation
2. **Switch to native Cloud** only if you hit workflow limitations
3. **Return to proxy models** once complex orchestration is done

## Technical Details

### Steering File Activation

The proxy-mode steering file uses:
```yaml
inclusion: auto
name: Proxy Mode
description: Conditionally enforce direct execution for Gateway providers
```

**How it works:**
- `inclusion: auto` - Activated automatically by Kiro IDE
- Kiro IDE matches model name against patterns
- When match found, steering instructions are included in context
- AI follows instructions to avoid workflow APIs

### Server-Side Compatibility

The proxy server handles workflow requests gracefully:

**Endpoints Handled:**
- `/runtime/workflows/run` → Returns "not_supported" with fallback hint
- `/runtime/workflows/inspect` → Returns 404 "WorkflowNotFound"
- `/runtime/workflows/update` → Returns 404 "WorkflowNotFound"
- `/runtime/workflows/validate` → Returns 501 "NotImplemented"

**Result:** No crashes, graceful degradation to direct execution

## FAQ

**Q: Can I use Focus Mode with free models?**  
A: ✅ Yes! All 436 free models work with Focus Mode (direct execution only)

**Q: Will my tasks fail without workflows?**  
A: ❌ No! Most tasks work great with direct execution. Only very complex orchestration needs workflows.

**Q: How do I know if I need workflows?**  
A: If your task needs parallel sub-agents or 10+ structured steps, consider workflows. Otherwise, direct execution is fine.

**Q: Can I switch mid-task?**  
A: Yes, but you'll lose workflow state. Best to choose at task start.

**Q: Does this affect tool availability?**  
A: ❌ No! All standard tools (file ops, terminal, MCP) work the same.

**Q: Is there a performance difference?**  
A: Slightly. Workflows can parallelize work, but direct execution is often faster for simple tasks due to less overhead.

## Related Documentation

- [MODEL_SELECTOR_NOT_SHOWING.md](troubleshooting/MODEL_SELECTOR_NOT_SHOWING.md) - Model selector issues
- [WHY_WORKFLOWS_FAIL_IN_PROXY.md](WHY_WORKFLOWS_FAIL_IN_PROXY.md) - Workflow architecture details
- [PROXY_MODE_RESTORED.md](PROXY_MODE_RESTORED.md) - Proxy mode steering file
- [AWS_CLOUD_COMPATIBILITY_REPORT.md](AWS_CLOUD_COMPATIBILITY_REPORT.md) - Full compatibility report

---

**Date:** January 6, 2025  
**Status:** ⚠️ Partially Compatible (Direct Execution Only)  
**Recommendation:** Use proxy models for 90% of tasks, native Cloud when workflows genuinely needed
