/**
 * src/providers/dispatcher.js - 6-Tier Automode Inference Dispatcher
 * Strict sequence: Kilo -> Cline -> OpenRouter -> OrcaRouter -> Gemini -> Custom
 * Canvas Bridge (ngrok-*) is strictly isolated from Global Automode.
 * Pure CommonJS exportable module
 */

'use strict';

const { loadCustomConfig, isKeyValid } = require('../config/index');
const { MODELS, buildOtomodeFallbackList } = require('../config/catalog');
const { isCircuitOpen } = require('../resilience/circuit_breaker');
const { callKiloGateway } = require('./kilo');
const { callClineApi } = require('./cline');
const { callOpenRouter } = require('./openrouter');
const { callOrcaRouter } = require('./orcarouter');
const { callGeminiApi } = require('./gemini_direct');
const { callCustomApi } = require('./custom');
const { callNgrokGemini } = require('./canvas_bridge');

const PROVIDERS = {
  KILO: 'kilo',
  CLINE: 'cline',
  OPENROUTER: 'openrouter',
  ORCAROUTER: 'orcarouter',
  CUSTOM: 'custom'
};

const PROVIDER_TIMEOUTS = {
  [PROVIDERS.KILO]: 90000,
  [PROVIDERS.CLINE]: 120000,
  [PROVIDERS.OPENROUTER]: 120000,
  [PROVIDERS.ORCAROUTER]: 120000,
  [PROVIDERS.CUSTOM]: 120000
};

const PROVIDER_RETRY_CONFIG = {
  [PROVIDERS.KILO]: { maxRetries: 3, backoff: 'exponential' },
  [PROVIDERS.CLINE]: { maxRetries: 3, backoff: 'exponential' },
  [PROVIDERS.OPENROUTER]: { maxRetries: 3, backoff: 'exponential' },
  [PROVIDERS.ORCAROUTER]: { maxRetries: 3, backoff: 'exponential' },
  [PROVIDERS.CUSTOM]: { maxRetries: 2, backoff: 'exponential' }
};

const FALLBACK_TOTAL_TIMEOUT = 180000; // 3 minutes cumulative timeout

/**
 * Sliding window history pruning (prevents timeouts & empty responses on 20–50+ turn chats)
 */
function pruneMessages(messages, maxMessages = 24, maxTotalChars = 75000) {
  if (!Array.isArray(messages) || messages.length === 0) return messages;

  const sanitizeMsg = (m, maxLen = 8000) => {
    if (m && typeof m.content === 'string' && m.content.length > maxLen) {
      const head = Math.floor(maxLen * 0.65);
      const tail = maxLen - head;
      return {
        ...m,
        content: m.content.slice(0, head) + '\n\n...[content truncated to maintain performance]...\n\n' + m.content.slice(-tail)
      };
    }
    return m;
  };

  const systemMsgs = messages.filter(m => m.role === 'system').map(m => sanitizeMsg(m, 16000));
  const nonSystemMsgs = messages.filter(m => m.role !== 'system');

  let lastHumanIdx = -1;
  for (let i = nonSystemMsgs.length - 1; i >= 0; i--) {
    const c = typeof nonSystemMsgs[i]?.content === 'string' ? nonSystemMsgs[i].content.trim() : '';
    if (nonSystemMsgs[i]?.role === 'user' && c && !c.startsWith('[Tool Result (')) {
      lastHumanIdx = i;
      break;
    }
  }

  let lastHumanMsg = null;
  let keptNonSystem;
  if (nonSystemMsgs.length <= maxMessages) {
    keptNonSystem = nonSystemMsgs.map((m, idx) => {
      const sanitized = sanitizeMsg(m, (idx === 0 || idx === lastHumanIdx) ? 16000 : 8000);
      if (idx === lastHumanIdx) lastHumanMsg = sanitized;
      return sanitized;
    });
  } else {
    const firstMsg = sanitizeMsg(nonSystemMsgs[0], 16000);
    const recentStartIdx = nonSystemMsgs.length - (maxMessages - 1);
    const recentMsgs = nonSystemMsgs.slice(recentStartIdx).map((m, i) => {
      const origIdx = recentStartIdx + i;
      const sanitized = sanitizeMsg(m, origIdx === lastHumanIdx ? 16000 : 8000);
      if (origIdx === lastHumanIdx) lastHumanMsg = sanitized;
      return sanitized;
    });
    if (lastHumanIdx > 0 && lastHumanIdx < recentStartIdx) {
      lastHumanMsg = sanitizeMsg(nonSystemMsgs[lastHumanIdx], 16000);
      keptNonSystem = [firstMsg, lastHumanMsg, ...recentMsgs];
    } else {
      if (lastHumanIdx === 0) lastHumanMsg = firstMsg;
      keptNonSystem = [firstMsg, ...recentMsgs];
    }
  }

  const countChars = (arr) => arr.reduce((sum, m) => sum + (typeof m?.content === 'string' ? m.content.length : JSON.stringify(m?.content || '').length), 0);
  const sysChars = countChars(systemMsgs);

  while (keptNonSystem.length > 4 && (sysChars + countChars(keptNonSystem)) > maxTotalChars) {
    let dropIdx = 1;
    if (lastHumanMsg && keptNonSystem[dropIdx] === lastHumanMsg && keptNonSystem.length > 2) {
      dropIdx = 2;
    }
    keptNonSystem.splice(dropIdx, 1);
  }

  return [...systemMsgs, ...keptNonSystem];
}

/**
 * Otomode Sequential Free-Model Engine
 */
async function runProviderOtomode(providerName, messages, tools = [], options = {}) {
  const rawName = (providerName || '').toLowerCase();
  const normalizedProvider = rawName === 'orca' ? 'orcarouter' : (rawName.startsWith('custom-') ? 'custom' : rawName);
  const customProvider = options.customProvider || null;
  const cfg = options.cfg || loadCustomConfig();
  const orcaKey = options.orcaKey || cfg.providers?.orcarouter?.apiKey || cfg.orcarouterApiKey;

  const fallbackList = buildOtomodeFallbackList(normalizedProvider, customProvider?.name);

  if (fallbackList.length === 0) {
    if (normalizedProvider === 'kilo') fallbackList.push('kilo-auto/free', 'nvidia/nemotron-3.5-lightning:free');
    else if (normalizedProvider === 'cline') fallbackList.push('nvidia/nemotron-3.5-lightning:free');
    else if (normalizedProvider === 'openrouter') fallbackList.push('nvidia/nemotron-3.5-lightning:free');
    else if (normalizedProvider === 'orcarouter') fallbackList.push('orcarouter/free');
    else if (normalizedProvider === 'gemini') fallbackList.push('gemini-2.5-flash', 'gemini-2.0-flash');
    else if (customProvider?.defaultModel) fallbackList.push(customProvider.defaultModel);
    else throw new Error(`No free fallback models available for provider '${customProvider?.name || normalizedProvider}'`);
  }

  const firstModel = fallbackList.shift();
  const otomodeContext = {
    _fallbackList: fallbackList,
    _activeModel: firstModel,
    _isOtomode: true,
    _providerName: customProvider ? `custom-${customProvider.name.toLowerCase()}` : normalizedProvider
  };

  const label = customProvider ? `Custom (${customProvider.name})` : normalizedProvider;
  console.log(`[Otomode] 🚀 Starting ${label} chain at free model 1: ${firstModel} (${fallbackList.length} additional free models queued)`);

  if (normalizedProvider === 'kilo') {
    return await callKiloGateway(messages, firstModel, tools, otomodeContext);
  } else if (normalizedProvider === 'cline') {
    return await callClineApi(messages, firstModel, tools, otomodeContext);
  } else if (normalizedProvider === 'openrouter') {
    return await callOpenRouter(messages, firstModel, tools, otomodeContext);
  } else if (normalizedProvider === 'orcarouter') {
    return await callOrcaRouter(messages, firstModel, orcaKey, tools, otomodeContext);
  } else if (normalizedProvider === 'gemini') {
    return await callGeminiApi(messages, firstModel, tools, otomodeContext);
  } else if (normalizedProvider === 'ngrok') {
    return await callNgrokGemini(messages, firstModel, tools, otomodeContext);
  } else if (normalizedProvider === 'custom') {
    let p = customProvider;
    if (!p && rawName.startsWith('custom-')) {
      const slug = rawName.replace(/^custom-/, '').toLowerCase();
      p = (cfg.customProviders || []).find(cp => cp.name && cp.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') === slug);
    }
    if (!p) {
      p = (cfg.customProviders || []).find(cp => cp.enabled !== false && (cp.baseUrl || (cp.baseUrls && cp.baseUrls.length > 0)) && (cp.apiKey || (cp.apiKeys && cp.apiKeys.length > 0)));
    }
    if (!p) {
      throw new Error(`No enabled custom provider found for '${rawName}'`);
    }
    const customCfg = {
      ...cfg,
      baseUrl: p.baseUrl || (p.baseUrls && p.baseUrls[0]),
      baseUrls: p.baseUrls || (p.baseUrl ? [p.baseUrl] : []),
      apiKey: p.apiKey || (p.apiKeys && p.apiKeys[0]),
      apiKeys: p.apiKeys || (p.apiKey ? [p.apiKey] : []),
      model: firstModel
    };
    return await callCustomApi(customCfg, messages, firstModel, tools, otomodeContext);
  } else {
    throw new Error(`Otomode not supported for provider '${providerName}'`);
  }
}

/**
 * Smart Multi-Provider Inference Dispatcher with User-Configurable 6-Tier Fallback Hierarchy
 */
async function dispatchInference(rawMessages, requestedModel, tools = []) {
  const cfg = loadCustomConfig();
  const messages = pruneMessages(rawMessages, 24);
  const fallbackStartTime = Date.now();

  const foundModel = MODELS.models.find(m => m.modelId === requestedModel);
  const targetSlug = foundModel?.upstreamSlug || requestedModel;

  const orcaKey = cfg.providers?.orcarouter?.apiKey || cfg.orcarouterApiKey;
  const openrouterKey = cfg.openrouterApiKey || cfg.providers?.openrouter?.apiKey || cfg.apiKey;

  // Mode 1: Custom API explicit configuration
  if (cfg.provider === 'custom' && cfg.apiKey && cfg.apiKey.trim().length > 0) {
    const res = await callCustomApi(cfg, messages, targetSlug, tools);
    const hasContent = Boolean(
      (res?._kiro?.text && res._kiro.text.trim().length > 0) ||
      (res?._kiro?.toolCalls && res._kiro.toolCalls.length > 0)
    );
    if (!hasContent) {
      throw new Error('EMPTY_RESPONSE: Model returned 0 text and 0 tools');
    }
    return res;
  }

  // Mode 2: Specific Model Request
  if (requestedModel && requestedModel !== 'auto' && requestedModel !== 'global-automode') {
    try {
      let res = null;

      // 2a. Otomode intra-provider fallback
      if (requestedModel.endsWith('-otomode')) {
        const providerName = requestedModel.replace('-otomode', '');
        res = await runProviderOtomode(providerName, messages, tools, { cfg, orcaKey });
      } else if (requestedModel.startsWith('ngrok-')) {
        // 2b. Ngrok/Gemini browser-bridge models (EXCLUDED from Global Automode)
        console.log(`[KiroProxy] Routing ${requestedModel} to Ngrok/Gemini provider...`);
        res = await callNgrokGemini(messages, requestedModel, tools);
      } else if (requestedModel.startsWith('gemini-')) {
        // 2c. Gemini API direct models
        console.log(`[KiroProxy] Routing ${requestedModel} to Gemini API...`);
        res = await callGeminiApi(messages, targetSlug, tools);
      } else if (requestedModel === 'kilogateway' || requestedModel.startsWith('kilo-') || requestedModel.startsWith('google/gemma')) {
        // 2d. Kilo Gateway specific models
        res = await callKiloGateway(messages, targetSlug, tools);
      } else if (requestedModel.startsWith('custom-')) {
        // 2e. Custom provider model (added via GUI)
        const customEntry = MODELS.models.find(m => m.modelId === requestedModel);
        if (customEntry?._customProvider) {
          const p = customEntry._customProvider;
          const upstreamModel = customEntry.upstreamSlug || p.defaultModel;
          const customCfg = {
            ...loadCustomConfig(),
            baseUrl: p.baseUrl || (p.baseUrls && p.baseUrls[0]),
            baseUrls: p.baseUrls || (p.baseUrl ? [p.baseUrl] : []),
            apiKey: p.apiKey || (p.apiKeys && p.apiKeys[0]),
            apiKeys: p.apiKeys || (p.apiKey ? [p.apiKey] : []),
            model: upstreamModel
          };
          res = await callCustomApi(customCfg, messages, upstreamModel, tools);
        } else {
          throw new Error(`Custom provider model '${requestedModel}' not found in catalog`);
        }
      } else if ((requestedModel.startsWith('orca-') || requestedModel.startsWith('orcarouter/')) && isKeyValid(orcaKey)) {
        // 2f. OrcaRouter models
        const cleanSlug = targetSlug.replace(/^orca-/, '');
        res = await callOrcaRouter(messages, cleanSlug, orcaKey, tools);
      } else if ((requestedModel.startsWith('or-') || requestedModel.startsWith('openrouter-') || requestedModel.startsWith('openrouter/') || foundModel?.provider === 'openrouter') && isKeyValid(openrouterKey)) {
        // 2g. OpenRouter models
        res = await callOpenRouter(messages, targetSlug, tools);
      } else if (requestedModel.startsWith('cline-') || (foundModel && foundModel.upstreamSlug && !foundModel.upstreamSlug.endsWith(':free'))) {
        // 2h. Cline models
        if (!isKeyValid(cfg.clineApiKey)) {
          throw new Error('Cline API key is required for cline-* models. Configure it in kiro_ai_config.json');
        }
        res = await callClineApi(messages, targetSlug, tools);
      } else {
        // 2i. Catch-all for unrecognized specific model
        console.log(`[KiroProxy] Model '${requestedModel}' unrecognised — attempting direct slug call`);
        if (foundModel) {
          try { res = await callKiloGateway(messages, targetSlug, tools); } catch (_) {}
          if (!res) { try { res = await callClineApi(messages, targetSlug, tools); } catch (_) {} }
          if (!res) { try { res = await callOpenRouter(messages, targetSlug, tools); } catch (_) {} }
        }
      }

      if (res) {
        const hasContent = Boolean(
          (res._kiro?.text && res._kiro.text.trim().length > 0) ||
          (res._kiro?.toolCalls && res._kiro.toolCalls.length > 0)
        );
        if (!hasContent) {
          throw new Error('EMPTY_RESPONSE: Model returned 0 text and 0 tools');
        }
        return res;
      }
    } catch (specificModelErr) {
      console.warn(`[KiroProxy] ⚠️ Specific model '${requestedModel}' failed (${specificModelErr.message}), falling back to Global Automode...`);
    }
  }

  // Mode 3: Global Automode (User-Ordered 6-Tier Fallback Hierarchy)
  const customCfg = loadCustomConfig();
  const geminiKey = cfg.geminiApiKey || (cfg.geminiApiKeys && cfg.geminiApiKeys[0]);
  const priorityOrder = Array.isArray(customCfg.providerPriorityOrder) && customCfg.providerPriorityOrder.length > 0
    ? customCfg.providerPriorityOrder
    : ['kilo', 'cline', 'openrouter', 'orcarouter', 'gemini', 'custom'];

  console.log(`[KiroProxy] 🌐 Global Automode: Priority → ${priorityOrder.map((t, i) => `${i + 1}. ${t}`).join(' → ')}`);

  // Build Custom Provider free model chains ordered by priority (high -> medium -> low, preserving array order within each bucket)
  const enabledCustom = (customCfg.customProviders || [])
    .filter(p => p.enabled !== false && (p.baseUrl || (p.baseUrls && p.baseUrls.length > 0)) && (p.apiKey || (p.apiKeys && p.apiKeys.length > 0)));

  const highCustom = enabledCustom.filter(p => p.priority === 'high');
  const mediumCustom = enabledCustom.filter(p => p.priority === 'medium');
  const lowCustom = enabledCustom.filter(p => p.priority !== 'high' && p.priority !== 'medium');
  const orderedCustom = [...highCustom, ...mediumCustom, ...lowCustom];

  const customChains = orderedCustom.map(p => ({
    name: `Custom (${p.name} Free Models)`,
    priority: p.priority || 'high',
    enabled: !isCircuitOpen(p.name || 'custom'),
    call: async () => await runProviderOtomode('custom', messages, tools, { cfg: customCfg, customProvider: p })
  }));

  const tierMap = {
    kilo: [{
      name: 'Kilo Gateway (Free Models)',
      enabled: !isCircuitOpen('kilo'),
      call: async () => await runProviderOtomode('kilo', messages, tools, { cfg })
    }],
    cline: [{
      name: 'Cline Free Models',
      enabled: isKeyValid(cfg.clineApiKey) && !isCircuitOpen('cline'),
      call: async () => await runProviderOtomode('cline', messages, tools, { cfg })
    }],
    openrouter: [{
      name: 'OpenRouter Free Models',
      enabled: isKeyValid(openrouterKey) && !isCircuitOpen('openrouter'),
      call: async () => await runProviderOtomode('openrouter', messages, tools, { cfg })
    }],
    orcarouter: [{
      name: 'OrcaRouter Free Models',
      enabled: isKeyValid(orcaKey) && !isCircuitOpen('orcarouter'),
      call: async () => await runProviderOtomode('orcarouter', messages, tools, { cfg, orcaKey })
    }],
    gemini: [{
      name: 'Gemini Free Models',
      enabled: isKeyValid(geminiKey) && !isCircuitOpen('gemini'),
      call: async () => await runProviderOtomode('gemini', messages, tools, { cfg })
    }],
    custom: customChains
  };

  const providers = [];
  for (const tierKey of priorityOrder) {
    if (tierMap[tierKey]) {
      providers.push(...tierMap[tierKey]);
    }
  }
  // Ensure any default tier omitted from custom list is still appended
  for (const defaultKey of ['kilo', 'cline', 'openrouter', 'orcarouter', 'gemini', 'custom']) {
    if (!priorityOrder.includes(defaultKey) && tierMap[defaultKey]) {
      providers.push(...tierMap[defaultKey]);
    }
  }

  let lastError = null;
  for (const provider of providers) {
    const elapsed = Date.now() - fallbackStartTime;
    if (elapsed > FALLBACK_TOTAL_TIMEOUT) {
      throw new Error(`Fallback chain timeout after ${Math.floor(elapsed / 1000)}s (limit: ${Math.floor(FALLBACK_TOTAL_TIMEOUT / 1000)}s)`);
    }

    if (!provider.enabled) {
      console.log(`[KiroProxy] Skipping ${provider.name} (not configured or circuit open)`);
      continue;
    }

    try {
      const remainingTime = FALLBACK_TOTAL_TIMEOUT - elapsed;
      const providerTimeout = Math.min(remainingTime, 60000);

      console.log(`[KiroProxy] Trying ${provider.name} (timeout: ${Math.floor(providerTimeout / 1000)}s)...`);
      const result = await Promise.race([
        provider.call(),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Provider timeout after ${Math.floor(providerTimeout / 1000)}s`)), providerTimeout)
        )
      ]);
      const hasContent = Boolean(
        (result?._kiro?.text && result._kiro.text.trim().length > 0) ||
        (result?._kiro?.toolCalls && result._kiro.toolCalls.length > 0)
      );
      if (!hasContent) {
        throw new Error('EMPTY_RESPONSE: Model returned 0 text and 0 tools');
      }
      console.log(`[KiroProxy] ✅ SUCCESS: ${provider.name} responded`);
      return result;
    } catch (err) {
      console.warn(`[KiroProxy] ❌ ${provider.name} failed: ${err.message}`);
      lastError = err;
    }
  }

  throw new Error(`All providers failed. Last error: ${lastError?.message || 'Unknown'}`);
}

module.exports = {
  dispatchInference,
  runProviderOtomode,
  pruneMessages,
  PROVIDERS,
  PROVIDER_TIMEOUTS,
  PROVIDER_RETRY_CONFIG,
  FALLBACK_TOTAL_TIMEOUT
};
