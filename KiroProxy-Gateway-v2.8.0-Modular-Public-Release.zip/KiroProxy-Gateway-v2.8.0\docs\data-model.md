# Data Model and In-Memory Entities — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary Files:** [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), `config/*.json`, `.kiro/config.json`  
**Persistence Type:** In-memory state singletons + Local JSON configuration files (no external SQL database).

---

## 1. Architecture & Entity-Relationship Overview

Although KiroProxy does not use an RDBMS, it manages mission-critical in-memory state entities, request buffers, circuit breaker state machines, and configuration schemas.

```mermaid
erDiagram
    CONFIG_FILE ||--o{ CUSTOM_PROVIDER : defines
    CUSTOM_PROVIDER ||--o{ MODEL_CATALOG : registers
    REQUEST_CONTEXT ||--|| CIRCUIT_BREAKER : checks
    REQUEST_CONTEXT ||--o{ KEY_ROTATOR : consumes
    REQUEST_CONTEXT ||--o| GEMINI_QUEUE : enqueues_if_canvas
    GEMINI_QUEUE ||--|| PENDING_REQUEST : transitions_to
    REQUEST_CONTEXT ||--|| EVENTSTREAM_FRAME : serializes_to

    MODEL_CATALOG {
        string modelId PK
        string modelName
        string provider
        float rateMultiplier
        int contextWindow
        boolean supportsTools
        boolean isCustom
    }

    CIRCUIT_BREAKER {
        string provider PK
        string state
        int failureCount
        timestamp lastFailureTime
        int resetTimeoutMs
    }

    GEMINI_QUEUE {
        string requestId PK
        string convId
        array messages
        array tools
        timestamp createdAt
        int ttlMs
    }

    KEY_ROTATOR {
        string provider PK
        int currentIndex
        array keys
        timestamp lastRotatedAt
    }
```

---

## 2. In-Memory Entities and State Structures

### E1: Model Catalog (`MODELS.models`)
- **`[FACT]`**: Defined at [`scripts/kiro_proxy_server.js#L735-L1140`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Purpose:** Stores all static and dynamically discovered models available for routing.
- **Entity Schema:**
  | Field | Type | Required | Constraints | Description |
  | :--- | :--- | :--- | :--- | :--- |
  | `modelId` | String | Yes | Unique, prefixed (`kilo-*`, etc.) | Unique identifier used by Kiro IDE model selector. |
  | `modelName` | String | Yes | Non-empty | Human-readable label displayed in UI. |
  | `provider` | String | Yes | Must match provider enum | Routing target (`kilo`, `cline`, `openrouter`, etc.). |
  | `rateMultiplier` | Number | Yes | **Must be exactly 0.0** | Rate card for Kiro IDE billing calculations. |
  | `contextWindow` | Number | Yes | `> 0` (e.g., 64000, 128000) | Token context capacity used by pruning engine. |
  | `supportsTools` | Boolean | Yes | Default: `true` | Declares whether model accepts function schemas. |
  | `isCustom` | Boolean | No | Default: `false` | Indicates user-registered custom upstream model. |

### E2: Circuit Breakers (`CIRCUIT_BREAKERS`)
- **`[FACT]`**: Defined at [`scripts/kiro_proxy_server.js#L306-L340`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Purpose:** Prevents cascading latency by failing fast when upstream providers throw errors.
- **Entity Schema:**
  | Field | Type | Description |
  | :--- | :--- | :--- |
  | `state` | String (`'CLOSED' \| 'OPEN' \| 'HALF_OPEN'`) | Current breaker lifecycle state. |
  | `failureCount` | Number | Consecutive failure counter. Trips to `OPEN` when `>= 5`. |
  | `lastFailureTime` | Number (Epoch ms) | Timestamp of most recent failure. |
  | `resetTimeout` | Number (ms) | Duration before transitioning to `HALF_OPEN` (default: `60000`). |

```mermaid
stateDiagram-v2
    [*] --> CLOSED
    CLOSED --> OPEN : 5 consecutive failures
    OPEN --> HALF_OPEN : 60s elapsed
    HALF_OPEN --> CLOSED : Probe request succeeds
    HALF_OPEN --> OPEN : Probe request fails
```

### E3: Canvas Bridge Queue (`geminiQueue`)
- **`[FACT]`**: Defined at [`scripts/kiro_proxy_server.js#L452`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Purpose:** FIFO queue buffering incoming AWS requests waiting for browser userscript polling.
- **Constraints:**
  - Maximum depth: 100 items (`MAX_QUEUE_DEPTH = 100`).
  - Item TTL: 300,000ms (`GEMINI_QUEUE_TIMEOUT_MS = 300000`).
- **Entity Schema:**
  | Field | Type | Description |
  | :--- | :--- | :--- |
  | `id` | String | Unique UUID for the bridge request. |
  | `prompt` | String | Extracted prompt text. |
  | `messages` | Array | Full conversational history payload. |
  | `tools` | Array | Tool definitions forwarded to Canvas. |
  | `timestamp` | Number | Epoch ms when request was enqueued. |
  | `resolve` | Function | Promise resolver triggered on `/done`. |
  | `reject` | Function | Promise rejector triggered on timeout or `/cancel`. |

### E4: Pending Requests Map (`pendingGeminiRequests`)
- **`[FACT]`**: Defined at [`scripts/kiro_proxy_server.js#L460`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Purpose:** Tracks in-flight requests that have been popped by `/poll` and are being processed in the browser.
- **Key:** `requestId` (String).
- **Value:** `{ req, res, timer, createdAt }`.

### E5: Provider Key Rotator State (`providerCurrentKeyIndex`)
- **`[FACT]`**: Defined at [`scripts/kiro_proxy_server.js#L1200`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js).
- **Purpose:** Tracks the active API key offset for providers with multiple comma-separated keys.
- **Key:** `provider` (String).
- **Value:** `index` (Integer, modulo `keys.length`).

---

## 3. Configuration File Schemas

### C1: Extension Gateway Config (`config/kiro_ai_config.json`)
- **`[FACT]`**: Read by Kiro IDE extension host to establish local proxy socket.
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "mode": { "type": "string", "enum": ["proxy", "native"] },
    "proxy": {
      "type": "object",
      "properties": {
        "enabled": { "type": "boolean" },
        "url": { "type": "string", "format": "uri" },
        "port": { "type": "integer" }
      },
      "required": ["enabled", "url"]
    }
  },
  "required": ["mode", "proxy"]
}
```

### C2: Steering Mode Config (`.kiro/config.json`)
- **`[FACT]`**: Read by Kiro IDE workspace agent to activate proxy steering commands.
```json
{
  "mode": "proxy",
  "steering": {
    "autoInject": true,
    "rulesDirectory": ".kiro/steering"
  }
}
```

### C3: Custom Provider Config (`config/custom_config.json`)
- **`[FACT]`**: Loaded at startup by `loadCustomConfig()` ([`scripts/kiro_proxy_server.js#L588`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)).
```json
{
  "customProviders": [
    {
      "name": "groq",
      "baseUrl": "https://api.groq.com/openai/v1",
      "apiKey": "gsk_...",
      "models": ["llama-3.3-70b-versatile"],
      "supportsTools": true
    }
  ]
}
```

---

## 4. Migration Rules & In-Memory State Safety

When modifying or expanding data structures in `scripts/kiro_proxy_server.js`:

1. **Zero-Downtime Catalog Updates:** Always append to `MODELS.models` dynamically; never replace the array reference (`MODELS.models = [...]` breaks references held by closures). Use `push()` or `splice()`.
2. **Queue Draining on Shutdown:** Server graceful shutdown handler ([`scripts/kiro_proxy_server.js#L6850`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)) must reject all pending promises in `pendingGeminiRequests` and `geminiQueue` with HTTP 503 before exiting.
3. **No Unbounded Memory Leaks:** 
   - `geminiQueue` is strictly capped at 100 items.
   - `pendingGeminiRequests` must have an active `setTimeout` cleanup handler.
   - Periodic cleanup timer runs every 60s to prune stale records older than 300s.
