#!/usr/bin/env node
/**
 * Test <function_calls> format extraction
 * Verifies that models generating <function_calls>...</function_calls> XML
 * have their tools extracted and stripped from text properly
 */

// Mock test - simulating the extractToolCallsFromResponse and stripToolBlocksFromText functions

const testCases = [
  {
    name: 'Gemini Canvas dots_function_call format',
    input: `Let me check that file.

<dots_function_call>
<execute_pwsh>
Select-String -Path tests/*.test.js -Pattern 'owned_by'
</execute_pwsh>
</dots_function_call>

Here are the results.`,
    expectedTools: [
      { name: 'execute_pwsh', args: { command: "Select-String -Path tests/*.test.js -Pattern 'owned_by'" } }
    ],
    expectedText: 'Let me check that file.\n\nHere are the results.'
  },
  {
    name: 'Simple function_calls with invoke',
    input: `Let me help you with that.

<function_calls>
<invoke name="read_file">
{"path": "package.json"}
</invoke>
</function_calls>

I'll check the file for you.`,
    expectedTools: [
      { name: 'read_file', args: { path: 'package.json' } }
    ],
    expectedText: `Let me help you with that.\n\nI'll check the file for you.`
  },
  {
    name: 'Multiple tools in function_calls',
    input: `<function_calls>
<invoke name="read_file">
{"path": "src/index.js"}
</invoke>
<invoke name="grep_search">
{"query": "function", "includePattern": "**/*.js"}
</invoke>
</function_calls>`,
    expectedTools: [
      { name: 'read_file', args: { path: 'src/index.js' } },
      { name: 'grep_search', args: { query: 'function', includePattern: '**/*.js' } }
    ],
    expectedText: ''
  },
  {
    name: 'function_calls with parameter tags',
    input: `<function_calls>
<invoke name="execute_pwsh">
<parameter name="command">npm test</parameter>
<parameter name="description">Run tests</parameter>
</invoke>
</function_calls>`,
    expectedTools: [
      { name: 'execute_pwsh', args: { command: 'npm test', description: 'Run tests' } }
    ],
    expectedText: ''
  },
  {
    name: 'Mixed text and function_calls',
    input: `First, let me read the configuration file.

<function_calls>
<invoke name="read_file">
{"path": "config.json"}
</invoke>
</function_calls>

Now I'll analyze the content.`,
    expectedTools: [
      { name: 'read_file', args: { path: 'config.json' } }
    ],
    expectedText: 'First, let me read the configuration file.\n\nNow I\'ll analyze the content.'
  }
];

console.log('═══════════════════════════════════════════════════════');
console.log('  <function_calls> Format Extraction Test');
console.log('═══════════════════════════════════════════════════════\n');

let passed = 0;
let failed = 0;

for (const testCase of testCases) {
  const extractRegex = /<function_calls>([\s\S]*?)<\/function_calls>/gi;
  const dotsRegex = /<dots_function_call>\s*<([a-zA-Z0-9_\-]+)>([\s\S]*?)<\/\1>\s*<\/dots_function_call>/gi;
  const stripRegex = /<function_calls>([\s\S]*?)<\/function_calls>|<dots_function_call>[\s\S]*?<\/dots_function_call>/gi;
  
  // Extract tools
  const detectedTools = [];
  let match;
  
  // Extract dots_function_call format
  while ((match = dotsRegex.exec(testCase.input)) !== null) {
    const toolName = match[1];
    const toolContent = match[2].trim();
    detectedTools.push({ name: toolName, args: { command: toolContent } });
  }
  
  // Extract function_calls format
  while ((match = extractRegex.exec(testCase.input)) !== null) {
    const innerContent = match[1];
    
    // Extract <invoke name="tool">...</invoke> blocks
    const innerInvokeRegex = /<invoke\s+name="([^"]+)">([\s\S]*?)<\/invoke>/g;
    let innerMatch;
    while ((innerMatch = innerInvokeRegex.exec(innerContent)) !== null) {
      try {
        const args = JSON.parse(innerMatch[2]);
        detectedTools.push({ name: innerMatch[1], args });
      } catch (e) {
        // Try parameter extraction
        const paramRegex = /<parameter\s+name="([^"]+)">([\s\S]*?)<\/parameter>/g;
        let paramMatch;
        const args = {};
        while ((paramMatch = paramRegex.exec(innerMatch[2])) !== null) {
          args[paramMatch[1]] = paramMatch[2].trim();
        }
        if (Object.keys(args).length > 0) {
          detectedTools.push({ name: innerMatch[1], args });
        }
      }
    }
  }
  
  // Strip from text
  let cleanedText = testCase.input.replace(stripRegex, '').replace(/\n{3,}/g, '\n\n').trim();
  
  // Check results
  const toolsMatch = JSON.stringify(detectedTools) === JSON.stringify(testCase.expectedTools);
  const textMatch = cleanedText === testCase.expectedText.trim();
  
  if (toolsMatch && textMatch) {
    console.log(`✅ ${testCase.name}`);
    passed++;
  } else {
    console.log(`❌ ${testCase.name}`);
    if (!toolsMatch) {
      console.log(`   Expected tools: ${JSON.stringify(testCase.expectedTools, null, 2)}`);
      console.log(`   Got tools: ${JSON.stringify(detectedTools, null, 2)}`);
    }
    if (!textMatch) {
      console.log(`   Expected text: "${testCase.expectedText}"`);
      console.log(`   Got text: "${cleanedText}"`);
    }
    failed++;
  }
}

console.log('\n═══════════════════════════════════════════════════════');
console.log('  Summary');
console.log('═══════════════════════════════════════════════════════');
console.log(`✅ Passed: ${passed}`);
console.log(`❌ Failed: ${failed}`);
console.log(`📊 Total:  ${passed + failed}`);
console.log(`📈 Success: ${Math.round((passed / (passed + failed)) * 100)}%`);
console.log('═══════════════════════════════════════════════════════\n');

process.exit(failed > 0 ? 1 : 0);
