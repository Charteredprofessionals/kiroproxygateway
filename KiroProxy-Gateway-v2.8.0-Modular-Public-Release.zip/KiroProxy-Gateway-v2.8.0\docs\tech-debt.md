# Technical Debt and Architectural Bottlenecks — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary File:** [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (6,950 lines)  
**Classification:** Documented for future AI assistants to refactor safely without breaking runtime behavior.

---

## 1. High-Priority Architectural Debt

### TD-01: Monolithic Single-File Server (6,950 Lines)
- **`[FACT]`**: [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) contains the entire server: HTTP router, AWS Smithy protocol handler, EventStream binary serializer, 6 provider dispatchers, regex tool translators, canvas bridge queues, model catalogs, and key rotators in a single file.
- **Impact:**
  - High cognitive load for AI assistants and human developers.
  - Merge conflicts on parallel edits.
  - Memory footprint of loading the entire file into AI context.
- **Remediation Plan:** Decompose into modular controllers: `controllers/bedrock.js`, `controllers/canvas.js`, `services/providers/`, `services/translators/`, `services/circuit_breaker.js`.

---

### TD-02: Disconnected Modular Utilities in `scripts/utils/`
- **`[FACT]`**: [`scripts/kiro_proxy_server.js#L51`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) imports **only** `global_automode_interceptor.js`.
- **`[FACT]`**: The modular files:
  - `scripts/utils/api_key_rotator.js`
  - `scripts/utils/request_queue.js`
  - `scripts/utils/smart_retry_engine.js`
  - `scripts/utils/structured_logger.js`
  - `scripts/utils/validators.js`  
  were written during refactoring efforts but are **never imported** by the active server. The server continues running its inline duplicate implementations (`executeWithRetry`, `rotateProviderKey`).
- **Impact:** Any bugfix or improvement applied to `scripts/utils/smart_retry_engine.js` has zero runtime effect.
- **Remediation Plan:** Wire `scripts/utils/*` into `scripts/kiro_proxy_server.js` or replace the inline logic with imports.

---

### TD-03: Lack of `module.exports` Causing Fragile `eval()` Test Slicing
- **`[FACT]`**: [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) does not export its internal pure functions.
- **`[FACT]`**: [`tests/test_bare_json_tool_calls.js#L15`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_bare_json_tool_calls.js) and [`tests/test_tool_translation_layer.js#L25`](file:///d:/sdlc_studio/projects/kiro-integration/tests/test_tool_translation_layer.js) read `kiro_proxy_server.js` as text, slice substring functions via `indexOf()`, and execute them using `eval()` or `vm.runInNewContext()`.
- **Impact:** Any renaming or whitespace modification of function signatures silently breaks the unit test suites.
- **Remediation Plan:** Add conditional export at the bottom of `scripts/kiro_proxy_server.js`:
  ```javascript
  if (require.main !== module) {
    module.exports = { extractToolCallsFromResponse, sanitizeJsonBackslashes, createEventStreamFrame };
  }
  ```

---

### TD-04: Test Suite Fragmentation & Schema Drift
- **`[FACT]`**: `tests/run_all_tests.js` only runs 2 out of 17 test suites (`test_gateway.js` and `test_edge_cases.js`), ignoring the comprehensive 57-test `tests/e2e/e2e_runner.js`.
- **`[FACT]`**: `tests/test_reliability_layer.js` has 8 failed assertions due to testing obsolete v2.5 schemas against v2.8 responses.
- **`[FACT]`**: `tests/test_custom_providers.js` has 3 failed assertions due to overly restrictive regexes rejecting slugs with underscores (`custom-groq-qwen_qwen3_8-27b`).
- **Remediation Plan:** Update test assertions to v2.8 schema and point `npm test` to `tests/e2e/e2e_runner.js`.

---

## 2. Fragile Code and Concurrency Limits

### TD-05: DOM Scraping Dependency in Canvas Bridge
- **`[FACT]`**: [`scripts/userscript.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/userscript.js) directly queries Google Gemini Web DOM selectors (`rich-textarea`, `send-button`).
- **Impact:** Google updates Gemini Web frontend markup frequently. Any DOM selector change immediately breaks Canvas Bridge without proxy code throwing any error.
- **Remediation Plan:** Implement fallback DOM selector heuristic matching in `userscript.js`.

---

### TD-06: Potential ReDoS in Argument Extraction
- **`[FACT]`**: Regex in `extractToolArguments()` ([`scripts/kiro_proxy_server.js#L4590`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js)):
  ```javascript
  trimmed.replace(/"((?:\\.|[^"\\])*)"/gs, ...)
  ```
  uses catastrophic backtracking patterns if evaluated on large unclosed string payloads (> 100KB).
- **Remediation Plan:** Replace regular expression string replacements with a linear tokenizer or stream parser.

---

### TD-07: In-Memory Volatility (No State Persistence)
- **`[FACT]`**: All active requests in `geminiQueue` (lines 452-470), `CIRCUIT_BREAKERS` failure states (line 306), and Prometheus counters in `METRICS` reside exclusively in process heap memory.
- **Impact:** If the proxy process crashes or restarts, all active browser queue sessions are dropped, and all circuit breakers reset to `CLOSED`.
- **Scaling Limit:** Memory footprint scales linearly with request queue depth. Capped at 100 items (`MAX_QUEUE_DEPTH = 100`).

---

### TD-08: Socket Hang on Malformed JSON Requests
- **`[FACT]`**: As documented in [`tests/e2e/tier2_boundaries.test.js#L81`](file:///d:/sdlc_studio/projects/kiro-integration/tests/e2e/tier2_boundaries.test.js), unhandled rejections during stream parsing in `readBody()` can cause HTTP sockets to hang until client timeout.
- **Remediation Plan:** Add explicit `req.on('error')` and `res.writeHead(400)` error responses in `readBody()`.
