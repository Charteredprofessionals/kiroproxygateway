# Canvas Bridge Routing Fix

## Problem

After adding `_kiro` metadata support to Gemini API and Custom API providers, the Ngrok-Gemini Canvas Bridge stopped working. The Canvas app was successfully polling `/poll` and receiving work, but requests were never being returned via `/done`.

## Root Cause

The Canvas Bridge endpoints (`/poll`, `/chunk`, `/done`, `/cancel`) were positioned **AFTER** the "Universal AWS Cloud Catch-All" handler in the request routing logic. This caused all POST requests to `/chunk` and `/done` to be intercepted by the AWS catch-all handler before reaching their specific endpoint handlers.

**Evidence from logs:**
```
[KiroProxy] POST /done (target: none)
[KiroProxy] AWS Catch-all handler for POST /done
```

The catch-all was logging the request but not processing it, so `handleBridgeDone()` was never being called.

## Solution

Moved all Canvas Bridge endpoint handlers to come **BEFORE** the AWS catch-all handler in `kiro_proxy_server.js`:

**Original Order (Broken):**
```javascript
// Line 4233: AWS Catch-All Handler
if (shouldLogAwsCatchall) {
  console.log(`[KiroProxy] AWS Catch-all handler for ${method} ${req.url}`);
}

// Line 4286: /poll endpoint (TOO LATE!)
if (method === 'GET' && ...) { ... }

// Line 4399: /done endpoint (TOO LATE!)
if (method === 'POST' && ...) { ... }
```

**Fixed Order (Working):**
```javascript
// Canvas Bridge Endpoints FIRST
if (urlPath.includes('space') ...) { ... }

// ── Browser Bridge Endpoints (Gemini Userscript Protocol) ────────────
// CRITICAL: These must come BEFORE the AWS catch-all

// /canvas, /poll, /chunk, /done, /cancel handlers here

// 12. Universal AWS Cloud Catch-All (Zero 404s, 100% Protocol Compliance)
// Positioned AFTER Canvas Bridge endpoints to avoid intercepting them
if (shouldLogAwsCatchall) {
  console.log(`[KiroProxy] AWS Catch-all handler for ${method} ${req.url}`);
}

// /health, /status, /config endpoints follow
```

## Verification

After the fix, the logs show:
```
[BridgePoll] Dispatching gemini_1791300524929_u3001f to browser
[KiroProxy] POST /chunk (target: none)
[KiroProxy] POST /done (target: none)
```

The `/chunk` and `/done` endpoints are now being reached **before** the AWS catch-all, allowing Canvas to successfully complete requests.

## Impact

✅ **Fixed:** Canvas Bridge now works correctly  
✅ **Maintained:** AWS Cloud compatibility for all other endpoints  
✅ **No breaking changes:** All 7 providers still work as native AWS Cloud  

## Related Files

- `scripts/kiro_proxy_server.js` (lines ~4220-4440)
- `docs/AWS_CLOUD_COMPATIBILITY_REPORT.md`
- `docs/troubleshooting/NGROK_TOOL_EXECUTION_FIX.md`

## Date

January 6, 2025 (Fixed after adding `_kiro` metadata support)
