# Gemini Canvas Bridge Setup Guide — KiroProxy Gateway

**Zero-Cost Google Gemini Access via Browser Session Auto-Authentication**

---

## 🏗️ Architecture & Isolation

```
[Kiro IDE / Cursor / Client]
         │ (OpenAI / Claude / AWS Bedrock format)
         ▼
[KiroProxy Gateway (Port 8084)]
    ├── Canvas Reverse Polling Engine (/poll, /chunk, /done)
    │        ▲
    │        │ HTTP Polling (with 'ngrok-skip-browser-warning: 69420')
    │        ▼
    └── [Browser Tab: canvas_bridge_dashboard.html]
             │
             │ Browser Auto-Auth Session
             ▼
        [Google Gemini Web: gemini.google.com]
        (Model: gemini-3-flash-preview — Zero External API Keys & Zero Billing)
```

> [!IMPORTANT]
> **Architectural Isolation:**
> The Ngrok Canvas Bridge (`ngrok-gemini-flash`) is **completely isolated** from the REST API fallback sequence (`Kilo -> Cline -> OpenRouter -> OrcaRouter -> Custom Models`). It operates as an interactive browser reverse-tunnel utilizing your personal Google Gemini web session, incurring zero external token costs.

---

## ✅ Step-by-Step Activation

### Step 1: Verify KiroProxy Gateway is Active
Ensure your proxy server is running:
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8084/health"
```
Ensure the response reports `"status": "ok"` and `"message": "KiroProxy Active"`.

---

### Step 2: Open Google Gemini in Browser
1. Open your browser (Google Chrome, Microsoft Edge, or Firefox).
2. Navigate to: **[https://gemini.google.com](https://gemini.google.com)**
3. **Sign in** with your Google account.
4. Keep this tab open.

---

### Step 3: Launch Canvas Bridge Dashboard
In a new tab in the same browser, open:
```
http://127.0.0.1:8084/canvas
```
*(Or your active Ngrok public URL: `https://your-tunnel.ngrok-free.dev/canvas`)*

You will see the dark-themed **KiroProxy Gateway — Gemini Canvas Bridge Dashboard** with real-time connection telemetry, queue depth, and polling controls.

---

### Step 4: Click "START BRIDGE"
Click the **"START BRIDGE"** button in the dashboard:
1. The dashboard begins polling `GET /poll` with header `'ngrok-skip-browser-warning': '69420'`.
2. When KiroProxy receives a prompt directed to `ngrok-gemini-flash`, it enters the queue.
3. The dashboard retrieves the prompt from `/poll`, forwards it to Gemini, streams chunks back via `/chunk`, and signals completion via `/done`.
4. KiroProxy Gateway formats the response into AWS Bedrock EventStream frames and delivers them to Kiro IDE.

---

### Step 5: Test in Kiro IDE
1. Open Kiro IDE.
2. Select model **`ngrok-gemini-flash`**.
3. Send a test message: `"Respond with: Canvas Bridge Operational"`.
4. Response streams instantly without external API tokens or billing.

---

## 🔒 Security & CORS Invariants

- **Dynamic CORS Reflection:** The `/canvas`, `/poll`, `/chunk`, and `/done` handlers dynamically reflect authorized origins (`gemini.google.com`, `127.0.0.1`, `localhost`) with `Access-Control-Allow-Credentials: true`.
- **Interstitial Bypass:** All bridge polling injects `ngrok-skip-browser-warning: 69420` to bypass free ngrok warning screens.
- **Routing Invariant:** In `scripts/kiro_proxy_server.js`, all Canvas Bridge routes strictly precede the universal AWS Bedrock catch-all handler.

---

*KiroProxy Gateway — Zero-cost AI access with architectural resilience.*
