# Getting Started — KiroProxy Gateway v2.8.0

Welcome to KiroProxy Gateway! This section contains setup guides for developers and end users.

---

## 📄 Essential Guides

1. **[Quick Start Guide](file:///d:/sdlc_studio/projects/kiro-integration/docs/guides/QUICK_START_v2.md)** — Launch and patch in 1 minute.
2. **[Configuration GUI Guide](file:///d:/sdlc_studio/projects/kiro-integration/docs/CONFIGURATION_GUI.md)** — Manage API keys and custom providers visually.
3. **[Global Automode Guide](file:///d:/sdlc_studio/projects/kiro-integration/docs/guides/GLOBAL_AUTOMODE_GUIDE.md)** — Understand the 6-tier zero-cost auto-fallback pipeline.
4. **[Kiro IDE Integration Guide](file:///d:/sdlc_studio/projects/kiro-integration/docs/setup/KIRO_IDE_INTEGRATION_GUIDE.md)** — Deep-dive on extension patching and dual-mode operation.

---

## 🛠️ CLI Quick Launch
```bash
# Start proxy server
npm start

# Patch Kiro IDE
npm run patch

# Verify health
curl http://localhost:8084/health
```