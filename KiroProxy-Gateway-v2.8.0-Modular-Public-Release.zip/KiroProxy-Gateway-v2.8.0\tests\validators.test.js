/**
 * validators.test.js - Unit tests for input validation
 */

'use strict';

const { 
  ValidationError,
  validateToolCall,
  validateApiKey,
  validateChatRequest,
  validateModelId,
  validateQueueConfig
} = require('../src/config/validators');

// Test results tracking
const results = { passed: 0, failed: 0, errors: [] };

function test(name, fn) {
  try {
    fn();
    results.passed++;
    console.log(`✅ ${name}`);
  } catch (err) {
    results.failed++;
    results.errors.push({ test: name, error: err.message });
    console.error(`❌ ${name}`);
    console.error(`   ${err.message}`);
  }
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}

function assertThrows(fn, expectedError) {
  try {
    fn();
    throw new Error('Expected function to throw, but it did not');
  } catch (err) {
    if (err.message === 'Expected function to throw, but it did not') {
      throw err;
    }
    const detailsStr = err.details ? (Array.isArray(err.details.errors) ? err.details.errors.join(' ') : JSON.stringify(err.details)) : '';
    const fullMessage = `${err.message} ${detailsStr}`;
    if (expectedError && !fullMessage.includes(expectedError)) {
      throw new Error(`Expected error containing "${expectedError}", got "${err.message}"`);
    }
  }
}

console.log('\n=== Validator Tests ===\n');

// ── validateToolCall Tests ───────────────────────────────────────────────────

test('validateToolCall: accepts valid tool call', () => {
  const schema = {
    required: ['path'],
    properties: {
      path: { type: 'string' },
      depth: { type: 'number' }
    }
  };
  
  const result = validateToolCall('list_directory', { path: '/tmp', depth: 2 }, schema);
  assert(result === true, 'Should return true for valid call');
});

test('validateToolCall: rejects missing required parameter', () => {
  const schema = {
    required: ['path'],
    properties: {
      path: { type: 'string' }
    }
  };
  
  assertThrows(
    () => validateToolCall('list_directory', {}, schema),
    'missing required parameter'
  );
});

test('validateToolCall: rejects wrong parameter type', () => {
  const schema = {
    required: ['path'],
    properties: {
      path: { type: 'string' }
    }
  };
  
  assertThrows(
    () => validateToolCall('list_directory', { path: 12345 }, schema),
    'type validation errors'
  );
});

test('validateToolCall: accepts null for nullable types', () => {
  const schema = {
    required: [],
    properties: {
      depth: { type: ['number', 'null'] }
    }
  };
  
  const result = validateToolCall('list_directory', { depth: null }, schema);
  assert(result === true, 'Should accept null for nullable types');
});

// ── validateApiKey Tests ─────────────────────────────────────────────────────

test('validateApiKey: accepts valid API key', () => {
  const result = validateApiKey('sk-1234567890abcdef', 'openai');
  assert(result === true, 'Should return true for valid key');
});

test('validateApiKey: rejects empty string', () => {
  assertThrows(
    () => validateApiKey('', 'openai'),
    'must be a non-empty string'
  );
});

test('validateApiKey: rejects null', () => {
  assertThrows(
    () => validateApiKey(null, 'openai'),
    'must be a non-empty string'
  );
});

test('validateApiKey: rejects placeholder values', () => {
  assertThrows(
    () => validateApiKey('your_key_here', 'openai'),
    'appears to be a placeholder'
  );
});

test('validateApiKey: rejects whitespace only', () => {
  assertThrows(
    () => validateApiKey('   ', 'openai'),
    'empty or whitespace'
  );
});

// ── validateChatRequest Tests ────────────────────────────────────────────────

test('validateChatRequest: accepts valid request', () => {
  const request = {
    modelId: 'claude-3-opus',
    messages: [
      {
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }]
      }
    ],
    inferenceConfig: {
      maxTokens: 1000,
      temperature: 0.7
    }
  };
  
  const result = validateChatRequest(request);
  assert(result === true, 'Should return true for valid request');
});

test('validateChatRequest: rejects missing modelId', () => {
  const request = {
    messages: [
      {
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }]
      }
    ]
  };
  
  assertThrows(
    () => validateChatRequest(request),
    'modelId is required'
  );
});

test('validateChatRequest: rejects empty messages array', () => {
  const request = {
    modelId: 'claude-3-opus',
    messages: []
  };
  
  assertThrows(
    () => validateChatRequest(request),
    'must be a non-empty array'
  );
});

test('validateChatRequest: rejects invalid message role', () => {
  const request = {
    modelId: 'claude-3-opus',
    messages: [
      {
        role: 'invalid',
        content: [{ type: 'text', text: 'Hello' }]
      }
    ]
  };
  
  assertThrows(
    () => validateChatRequest(request),
    'role must be'
  );
});

test('validateChatRequest: rejects invalid maxTokens', () => {
  const request = {
    modelId: 'claude-3-opus',
    messages: [
      {
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }]
      }
    ],
    inferenceConfig: {
      maxTokens: -100
    }
  };
  
  assertThrows(
    () => validateChatRequest(request),
    'maxTokens must be'
  );
});

test('validateChatRequest: rejects invalid temperature', () => {
  const request = {
    modelId: 'claude-3-opus',
    messages: [
      {
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }]
      }
    ],
    inferenceConfig: {
      temperature: 5.0
    }
  };
  
  assertThrows(
    () => validateChatRequest(request),
    'temperature must be'
  );
});

// ── validateModelId Tests ────────────────────────────────────────────────────

test('validateModelId: accepts valid model ID', () => {
  const result = validateModelId('claude-3-opus');
  assert(result === true, 'Should return true for valid modelId');
});

test('validateModelId: rejects empty string', () => {
  assertThrows(
    () => validateModelId(''),
    'must be a non-empty string'
  );
});

test('validateModelId: rejects unavailable model when list provided', () => {
  const availableModels = [
    { modelId: 'claude-3-opus' },
    { modelId: 'gpt-4' }
  ];
  
  assertThrows(
    () => validateModelId('nonexistent-model', availableModels),
    'Model not found'
  );
});

test('validateModelId: accepts available model when list provided', () => {
  const availableModels = [
    { modelId: 'claude-3-opus' },
    { modelId: 'gpt-4' }
  ];
  
  const result = validateModelId('claude-3-opus', availableModels);
  assert(result === true, 'Should accept available model');
});

// ── validateQueueConfig Tests ────────────────────────────────────────────────

test('validateQueueConfig: accepts valid config', () => {
  const config = {
    maxSize: 1000,
    timeout: 5000,
    priority: 'high'
  };
  
  const result = validateQueueConfig(config);
  assert(result === true, 'Should return true for valid config');
});

test('validateQueueConfig: rejects invalid maxSize', () => {
  const config = {
    maxSize: -10
  };
  
  assertThrows(
    () => validateQueueConfig(config),
    'maxSize must be'
  );
});

test('validateQueueConfig: rejects invalid timeout', () => {
  const config = {
    timeout: 100
  };
  
  assertThrows(
    () => validateQueueConfig(config),
    'timeout must be'
  );
});

test('validateQueueConfig: rejects invalid priority', () => {
  const config = {
    priority: 'urgent'
  };
  
  assertThrows(
    () => validateQueueConfig(config),
    'priority must be'
  );
});

// ── Test Summary ─────────────────────────────────────────────────────────────

console.log('\n=== Test Summary ===');
console.log(`Passed: ${results.passed}`);
console.log(`Failed: ${results.failed}`);
console.log(`Total:  ${results.passed + results.failed}`);

if (results.failed > 0) {
  console.log('\n=== Failed Tests ===');
  results.errors.forEach(({ test, error }) => {
    console.log(`\n${test}:`);
    console.log(`  ${error}`);
  });
  process.exit(1);
} else {
  console.log('\n✅ All tests passed!\n');
  process.exit(0);
}
