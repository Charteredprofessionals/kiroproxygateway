# 📜 Changelog: KiroProxy Gateway

All notable changes to the KiroProxy Gateway project are documented in this file.

---

## [2.7.1] — 2026-10-07 (KiroProxy Gateway Rebranding & Strict 5-Tier Fallback)

### 🏷️ Official Project Rebranding
- ✅ Formally rebranded project to **KiroProxy Gateway** across `package.json`, batch launchers, server logs, health check endpoints, and documentation.
- ✅ Strict naming boundary enforced: "KiroProxy Gateway" applies to the local proxy runtime; "Kilo Gateway" is strictly reserved for the external upstream service `https://api.kilo.ai`.

### 🔄 Strict 5-Tier Auto-Fallback Sequence
- ✅ Mode 3 auto-routing locked to the exact sequence:
  $$\mathbf{Kilo\ Gateway} \longrightarrow \mathbf{Cline\ Free} \longrightarrow \mathbf{OpenRouter\ Free} \longrightarrow \mathbf{OrcaRouter} \longrightarrow \mathbf{Custom\ Models}$$
- ✅ Custom models (`highCustom`, `mediumCustom`, `lowCustom`) placed at the end of the chain.
- ✅ Verified 100% operational success rate across 16 models and all 7 fallback progression hops.

### 🌐 Ngrok Gemini Canvas Bridge Isolation
- ✅ Formally separated Ngrok from the REST API fallback chain.
- ✅ Delivered responsive dark dashboard at `scripts/canvas_bridge_dashboard.html` (`GET /canvas`).
- ✅ Implemented inline HTML fallback in `scripts/kiro_proxy_server.js` guaranteeing `/canvas` never falls into the AWS Bedrock catch-all handler.
- ✅ Hardened CORS origin reflection (`gemini.google.com`, `127.0.0.1`) and enforced `'ngrok-skip-browser-warning': '69420'` headers.

- ✅ Upgraded Kiro IDE Patcher (`scripts/patch_kiro_extension.js`):
  - **Patch 3B:** Intercepts `getTarget()` to route prompts (`POST /generateAssistantResponse`) to `http://127.0.0.1:8084`, eliminating "model not available" errors.
  - **Patch 3A:** Intercepts minified KRS client resolvers (`Bte`, `Zee`, `Lte`, `RKo`) to redirect Bedrock client instances to `http://127.0.0.1:8084`.
- ✅ Fixed `createConverseEvent` undefined call in `scripts/kiro_proxy_server.js`, encoding binary AWS Bedrock EventStream frames with CRC32 checksums.
- ✅ Synchronized workspace `.kiro/steering/proxy-mode.md` direct execution steering with user-global configuration.

---

## [2.7.0] — 2026-10-07 (Edge Case Hardening & 7-Provider Support)

### 🎯 Edge Case Fixes & Validation Hardening

**Request Validation (400 Bad Request instead of 502)**
- ✅ Empty `messages` array now returns **400** with clear error message
- ✅ `null` or `undefined` message content now returns **400** with validation error
- ✅ Missing `messages` field now returns **400** instead of passing empty array to provider

**Health Endpoint Enhancement**
- ✅ Added **gemini** provider to `/health` endpoint (now 6 providers: kilo, cline, openrouter, orcarouter, gemini, ngrok)
- ✅ Changed provider format from string to object: `{status, latency, lastCheck, error}`
- ✅ All providers now report full health metrics

**Model Catalog Compatibility**
- ✅ Added backward-compatible `pricing` field to all models in `/listAvailableModels`
- ✅ Format: `{prompt: "0", completion: "0", unit: "credit"}` derived from `rateMultiplier`

### 🧪 Test Suite Expansion

**New Test Files**
- ✅ `tests/test_edge_cases.js` — 12 comprehensive edge case tests (100% pass)
- ✅ `tests/run_all_tests.js` — Unified test runner for all suites
- ✅ Updated `scripts/batch/test_gateway.bat` — Now 12 tests (added T11: provider objects, T12: pricing field)

**Test Coverage**
- Main suite: 16/16 tests (100%)
- Edge cases: 12/12 tests (100%)
- Total: **28/28 tests passing**

**Edge Cases Tested**
1. Empty messages array validation
2. Null/undefined content validation
3. Invalid model name handling
4. Missing required fields
5. Large message handling (10KB+)
6. Generation parameter validation (temperature, max_tokens)
7. Health endpoint provider structure
8. Model pricing field presence

### 🔧 Batch Script Fixes

**`launch.bat` Updates**
- ✅ Fixed `--status` display to read `provider.status` from health objects
- ✅ Fixed startup display to handle new provider object structure

**`test_gateway.bat` Enhancement**
- ✅ Added T11: Verify providers have status objects
- ✅ Added T12: Verify models include pricing field
- ✅ Updated from 10 to 12 tests

### 📚 Documentation Updates

**`docs/README.md`**
- ✅ Added test files reference table
- ✅ Added edge case fixes summary table (6 fixes documented)
- ✅ Updated with npm test commands

**`scripts/batch/README.md`**
- ✅ Updated test count from 10 to 12 tests
- ✅ Documented new T11 and T12 tests

### 🔍 Ngrok Verification

**Tunnel Status: ✅ LIVE**
- Public URL: https://reassure-shrivel-underwear.ngrok-free.dev
- Ngrok provider: healthy (11ms latency)
- Gemini provider: healthy (310ms latency)
- Tunnel accessible externally with full model catalog

### 📊 Summary Statistics

| Metric | Value |
|--------|-------|
| Total Tests | 28 (16 main + 12 edge) |
| Pass Rate | 100% |
| Providers | 6 (kilo, cline, openrouter, orcarouter, gemini, ngrok) |
| Models | 78 (all free, rateMultiplier=0.0) |
| Edge Case Fixes | 6 |
| Batch Scripts Updated | 2 (launch.bat, test_gateway.bat) |

---

## [2.4.0] — 2026-09-03 (Production Release)

### 🌟 Major Highlights
- **77+ Live Auto-Populated Free Models**: Integrated dynamic discovery engine querying OpenRouter Free Tier and Cline API in real-time.
- **Official AWS Cloud Protocol Synchronization**: Full parity with AWS EventStream binary protocol (CRC32), standard AWS headers (`x-amzn-session-id`, `x-amzn-kiro-profile-arn`), and AWS RPC envelopes (`com.amazon.kiro.runtimeservice#Success`).
- **3-Stage Tool Parser with Auto-Healing**: Direct JSON.parse first pass, quoted-key regex support, and automatic directory shield preventing `read_file` from ever receiving `.`.
- **5-Tier User Key Architecture**: Safe multi-tier configuration allowing users to configure keys locally, globally (`~/.kiro/`), via environment variables, or run 100% key-free.

### 🛡️ Hardening & Audit Fixes
- **Windows Path Backslash Sanitization**: Automatically escapes unescaped Windows backslashes (`\s`, `\p`, `\N`) before JSON deserialization.
- **Server Crash Resilience**: Added `res.headersSent` guards to prevent `ERR_HTTP_HEADERS_SENT` exceptions during client network drops.
- **Empty Completion Shield**: Prevents raw JSON leaks on empty model outputs, smoothly continuing the conversational prompt.
- **8-Point Live Verification Suite**: Validates health, root probes, model catalog, credit limits, MCP JSON-RPC, EventStream CRC32 framing, extension patches, and tool/spec argument parsing in 789ms.

---

## [2.3.0] — 2026-09-02
- Added Cline Free models integration (`api.cline.bot`).
- Added authenticated Kilo Gateway JWT token support with priority Google Vertex AI routing.
- Expanded model catalog from 4 to 12 models.
- Added sliding window message pruning to maintain strict context budgets.

---

## [2.2.0] — 2026-09-01
- Implemented AWS EventStream binary framing with CRC32 calculation.
- Added autonomous tool call translation (`<|tool_call|>` $\rightarrow$ `toolUseEvent`).
- Added MCP stdio JSON-RPC server.
- Built `launch.bat` universal switcher (`--kilo`, `--native`, `--test`, `--cli`, `--ide`).

---

## [2.0.0] — 2026-08-28
- Initial release of Kiro AI Gateway.
- Provided zero-cost cloud inference via Kilo Gateway (Google Gemma 4 26B).
- Created 1-click installer (`install.bat`) and uninstaller (`uninstall.bat`).
