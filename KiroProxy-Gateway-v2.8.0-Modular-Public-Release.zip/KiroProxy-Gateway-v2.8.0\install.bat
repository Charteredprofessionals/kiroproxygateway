@echo off
REM ============================================================
REM  install.bat — KiroProxy Gateway Root Installer v2.8.0
REM  Calls scripts\batch\install.bat
REM ============================================================

call "%~dp0scripts\batch\install.bat" %*
