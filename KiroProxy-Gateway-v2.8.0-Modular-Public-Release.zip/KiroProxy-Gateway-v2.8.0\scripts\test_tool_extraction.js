// Test all 12 tool extraction formats
const fs = require('fs');
const path = require('path');

// Load the proxy server as a module
const proxyModule = require(path.join(__dirname, 'kiro_proxy_server.js'));

// Get the functions we need
const extractToolCallsFromResponse = proxyModule.extractToolCallsFromResponse;
const extractToolArguments = proxyModule.extractToolArguments;

if (!extractToolCallsFromResponse || !extractToolArguments) {
  console.error('Could not extract functions from module');
  process.exit(1);
}

const formats = [
  ['F1 JSON', '```json\n{"tool":"read_file","arguments":{"path":"test.txt"}}\n```'],
  ['F2 XML', '<invoke name="read_file">{"path":"test.txt"}</invoke>'],
  ['F3 tool_use', '<tool_use><name>read_file</name><arguments>{"path":"test.txt"}</arguments></tool_use>'],
  ['F4 Kiro', '{"tool":"read_file","arguments":{"path":"test.txt"}}'],
  ['F5 code', '```js\nconsole.log("hi");\n```'],
  ['F6 dots', '<dots_function_call><execute_pwsh>echo hello</execute_pwsh></dots_function_call>'],
  ['F7 fn_calls', '<function_calls><invoke name="read_file">{"path":"test.txt"}</invoke></function_calls>'],
  ['F8 input', '<tool_use><id>toolu_123</id><name>read_file</name><input>{"path":"test.txt"}</input></tool_use>'],
  ['F9 openai', '{"tool_calls":[{"id":"call_123","type":"function","function":{"name":"read_file","arguments":"{\"path\":\"test.txt\"}"}}]}'],
  ['F10 param', '<invoke name="read_file"><parameter name="path">test.txt</parameter></invoke>'],
  ['F11 antml', '<antml_function_calls><antml_invoke name="read_file"><antml_parameter name="path">test.txt</antml_parameter></antml_invoke></antml_function_calls>'],
  ['F12 compact', '<tool_call><function=read_file><parameter=path>test.txt</parameter></function><\/tool_call>'],
];

const availableTools = [
  {name: 'read_file'},
  {name: 'execute_pwsh'},
  {name: 'fs_write'},
];

let passed = 0;
let failed = 0;

formats.forEach(([name, text]) => {
  try {
    const result = extractToolCallsFromResponse(text, availableTools);
    if (result.length > 0) {
      console.log(name + ' ✅ PASS - ' + JSON.stringify(result[0]));
      passed++;
    } else {
      console.log(name + ' ❌ FAIL - No tools detected');
      failed++;
    }
  } catch (e) {
    console.log(name + ' ❌ ERROR - ' + e.message);
    failed++;
  }
});

console.log('\nResults: ' + passed + ' passed, ' + failed + ' failed');
process.exit(failed > 0 ? 1 : 0);
