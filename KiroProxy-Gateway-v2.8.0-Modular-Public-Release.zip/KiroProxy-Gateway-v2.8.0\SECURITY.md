# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.7.x   | :white_check_mark: |
| 2.6.x   | :white_check_mark: |
| 2.5.x   | :x:                |
| < 2.5   | :x:                |

## Reporting a Vulnerability

We take the security of KiroProxy Gateway seriously. If you discover a security vulnerability, please follow these steps:

### DO NOT

- **Do not** open a public GitHub issue
- **Do not** disclose the vulnerability publicly
- **Do not** exploit the vulnerability

### DO

1. **Email security details to:** security@yourproject.com (replace with actual email)
2. **Include:**
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

### Response Timeline

- **24 hours:** Initial acknowledgment
- **72 hours:** Assessment and severity classification
- **7 days:** Fix development (for critical issues)
- **14 days:** Release with security patch

## Security Best Practices

### For Users

#### API Key Management

```bash
# ✅ GOOD: Use environment variables
KILO_API_KEY=your_key_here

# ❌ BAD: Hardcode in files
const apiKey = "sk-1234567890abcdef";
```

#### File Permissions

```bash
# Secure configuration files
chmod 600 config/kiro_ai_config.json
chmod 600 .env
```

#### Network Security

- Run gateway on localhost (127.0.0.1) by default
- Use ngrok only when remote access is needed
- Never expose gateway directly to internet without authentication
- Use HTTPS for ngrok tunnels

### For Developers

#### Input Validation

```javascript
// Always validate user inputs
function validateModelId(modelId) {
  if (typeof modelId !== 'string') {
    throw new Error('Invalid model ID type');
  }
  
  if (!/^[a-z0-9-_\/]+$/i.test(modelId)) {
    throw new Error('Invalid model ID format');
  }
  
  return modelId;
}
```

#### Rate Limiting

```javascript
// Implement rate limiting
const rateLimit = {
  maxRequests: 100,
  windowMs: 60000, // 1 minute
  message: 'Too many requests'
};
```

#### Error Handling

```javascript
// Don't expose sensitive information in errors
try {
  await apiCall();
} catch (error) {
  // ✅ GOOD: Generic error
  res.status(500).json({ error: 'Internal server error' });
  
  // ❌ BAD: Exposes internals
  res.status(500).json({ error: error.stack });
}
```

## Known Security Considerations

### API Keys

- API keys are stored in plain text in configuration files
- **Mitigation:** Files are gitignored, users should secure file permissions
- **Future:** Consider encryption at rest

### Ngrok Tunnels

- Ngrok tunnels expose gateway publicly
- **Mitigation:** Tunnels are opt-in, users warned in documentation
- **Recommendation:** Use authentication if exposing remotely

### Dependency Vulnerabilities

We regularly audit dependencies:

```bash
npm audit
npm audit fix
```

### Request Size Limits

- Default max request size: 10MB
- **Protection:** Prevents memory exhaustion attacks
- **Configuration:** Adjustable in server settings

## Security Features

### Current Protections

- ✅ Input validation on all endpoints
- ✅ Rate limiting on Canvas Bridge
- ✅ Circuit breakers prevent cascading failures
- ✅ Request timeouts prevent hanging connections
- ✅ CORS headers properly configured
- ✅ No authentication bypasses
- ✅ Sanitized error messages

### Planned Enhancements

- 🔄 Optional authentication layer
- 🔄 Encrypted configuration files
- 🔄 Audit logging
- 🔄 IP whitelisting

## Vulnerability Disclosure

When we receive a valid security report:

1. **Confirmation:** We confirm the vulnerability
2. **Fix Development:** We develop and test a fix
3. **Release:** We release a patched version
4. **Disclosure:** We publicly disclose (after fix is released)
5. **Credit:** We credit the reporter (if desired)

## Security Updates

Subscribe to security updates:

- **GitHub:** Watch repository for security advisories
- **Email:** Subscribe to security mailing list (if available)
- **RSS:** Follow release feed

## Compliance

### Data Handling

- **No persistent storage:** Gateway does not store conversations
- **No logging of content:** Only metadata logged
- **API keys:** User-provided, not transmitted to us

### Privacy

- Gateway routes requests to third-party providers
- Each provider has their own privacy policy
- Review provider policies:
  - [Kilo Gateway](https://kilo.ai/privacy)
  - [Gemini API](https://ai.google.dev/privacy)
  - [Cline API](https://cline.bot/privacy)
  - [OpenRouter](https://openrouter.ai/privacy)

## Security Checklist for Deployment

Before deploying to production:

- [ ] Update all dependencies
- [ ] Run `npm audit`
- [ ] Secure API key files (chmod 600)
- [ ] Use environment variables for secrets
- [ ] Enable rate limiting
- [ ] Configure firewall rules
- [ ] Use HTTPS for external access
- [ ] Set up monitoring and alerts
- [ ] Review logs regularly
- [ ] Backup configuration files
- [ ] Test failover scenarios

## Contact

For security concerns:
- **Email:** security@yourproject.com
- **PGP Key:** [Link to public key if available]

---

**Last Updated:** October 8, 2026  
**Version:** 2.7.0
