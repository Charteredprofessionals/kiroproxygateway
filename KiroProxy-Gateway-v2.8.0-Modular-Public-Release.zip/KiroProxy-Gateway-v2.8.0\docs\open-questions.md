# Open Questions and Architecture Unknowns — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Purpose:** Every statement labeled `[UNKNOWN]` in the codebase audit compiled into a checklist for human engineering confirmation.

---

## Architecture and Codebase Unknowns Checklist

- [ ] **UQ-01: Disconnected Utility Files in `scripts/utils/`**
  - **`[UNKNOWN]`**: Are the modular utility files (`api_key_rotator.js`, `request_queue.js`, `smart_retry_engine.js`, `structured_logger.js`, `validators.js`) intended to replace inline functions in `scripts/kiro_proxy_server.js`, or are they abandoned experiments that should be deleted?
  - **Context:** `scripts/kiro_proxy_server.js` currently duplicates all of these functions inline and imports only `global_automode_interceptor.js`.

- [ ] **UQ-02: Canvas Bridge Userscript Headless Testing**
  - **`[UNKNOWN]`**: Is there an approved testing strategy to run the browser userscript (`scripts/userscript.js`) inside a headless browser (e.g. Playwright or Puppeteer) in CI/CD to detect Google Gemini DOM selector changes before they break user workflows?
  - **Context:** Current tests only send synthetic `curl`-style POST requests to `/chunk` and `/done`, which cannot verify if Google changed the `rich-textarea` or `send-button` selectors.

- [ ] **UQ-03: Ngrok SDK Tunnel Reconnection Resilience**
  - **`[UNKNOWN]`**: Does `@ngrok/ngrok` automatically recover from residential broadband IP changes or WAN disconnects, or does it leave the local HTTP proxy bound without an active tunnel?
  - **Context:** No automated chaos testing exists for network socket disconnections.

- [ ] **UQ-04: Maximum Concurrency and EventStream Throughput Limits**
  - **`[UNKNOWN]`**: What is the maximum sustained RPS (Requests Per Second) and concurrent stream capacity of `scripts/kiro_proxy_server.js` before Node.js event-loop lag degrades CRC32 computation?
  - **Context:** The heaviest existing concurrency test in `test_real_world_agent_scenario.js` tests only 3 parallel requests.

- [ ] **UQ-05: Proprietary AWS Workflows Future Strategy**
  - **`[UNKNOWN]`**: Is there any intention to emulate AWS Bedrock workflow step execution locally in KiroProxy (e.g., executing step graphs locally), or will `/runtime/workflows/*` and workflow tools remain permanently stubbed with 404/501?
  - **Context:** Workflow tools are currently suppressed in proxy mode via `FORBIDDEN_TOOLS_IN_PROXY`.

- [ ] **UQ-06: Extension Auto-Patching or Pre-Launch Hook**
  - **`[UNKNOWN]`**: Should `npm start` automatically execute `npm run patch:check` and apply patches if missing, or should patching remain an explicit, manual operator command?
  - **Context:** When Kiro IDE auto-updates, users frequently forget to re-run `npm run patch`, causing proxy connection failures.

- [ ] **UQ-07: Automated Enforcement for `rateMultiplier: 0.0`**
  - **`[UNKNOWN]`**: Should an automated lint/pre-commit test be added to enforce that no model in `MODELS.models` or custom configurations can ever have a non-zero `rateMultiplier`?
  - **Context:** `INV-01` requires all models to be free, but enforcement is currently manual inspection.

- [ ] **UQ-08: Model Catalog Cache Persistence**
  - **`[UNKNOWN]`**: Should the dynamically discovered model catalog (`MODELS.models`) be cached to a local JSON file on disk, so that proxy startup is instantaneous even if upstream providers (Kilo, Cline, OpenRouter) are temporarily unreachable?
  - **Context:** On startup, if third-party endpoints are slow or offline, discovery delays model selector availability.
