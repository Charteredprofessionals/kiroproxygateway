# Troubleshooting Guide — KiroProxy Gateway v2.8.0

**Target Application:** `kiroproxy-gateway`  
**Primary Files:** [`scripts/kiro_proxy_server.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js), [`scripts/patch_kiro_extension.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js)  
**Log Locations:** `stdout` console, [`logs/kiro_proxy.log`](file:///d:/sdlc_studio/projects/kiro-integration/logs/kiro_proxy.log), Kiro IDE DevTools (`Help > Toggle Developer Tools`)

---

## 1. Quick Symptom Diagnostic Matrix

| Symptom | Primary Cause | Where to Look (Code Ref) | Immediate Fix |
| :--- | :--- | :--- | :--- |
| **Tool call rendered as raw text in chat** | Model emitted bare JSON or XML tags; missing parser format or unescaped backslashes. | [`scripts/kiro_proxy_server.js#L2349`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`extractToolCallsFromResponse`) | Verify `sanitizeJsonBackslashes()` and Format 1b/6b parsers are active. Run `node tests/test_bare_json_tool_calls.js`. |
| **Empty assistant response (Canvas Bridge)** | Browser tab inactive/throttled, userscript disconnected, or queue timed out (300s). | [`scripts/kiro_proxy_server.js#L2984, L6475`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`geminiQueue`) | Open browser to Gemini tab, ensure userscript shows "Polling /poll", check `http://localhost:8084/canvas`. |
| **Model selector empty / only AWS models** | Kiro extension unpatched, server offline, or invalid URL in config. | [`scripts/patch_kiro_extension.js#L45`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/patch_kiro_extension.js), `config/kiro_ai_config.json` | Run `npm run patch:check`. If 0/4 patches applied, run `npm run patch` and restart Kiro IDE. |
| **"EXPLORER: NO FOLDER OPENED" / Agent fails** | IDE opened without workspace directory; steering rules and relative paths cannot resolve. | Kiro IDE UI Explorer Pane, `.kiro/steering/` | Use `File > Open Folder` in Kiro IDE to open project root directory. |
| **Stream closed abruptly / "CRC mismatch"** | EventStream binary frame corrupted or byte length mismatch. | [`scripts/kiro_proxy_server.js#L2077`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`createEventStreamFrame`) | Inspect total byte length calculation; ensure 12-byte prelude and 4-byte CRC match payload length. |
| **401 Unauthorized / 429 Too Many Requests** | API key expired or rate limit hit; key rotator stuck or no keys defined. | [`scripts/kiro_proxy_server.js#L1200`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`rotateProviderKey`) | Verify API keys in `.env` / `config/custom_config.json`. Check `providerCurrentKeyIndex` in `/metrics`. |
| **503 Service Unavailable** | All providers in Global Automode chain failed or circuit breakers open. | [`scripts/kiro_proxy_server.js#L306, L4199`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Check `curl http://localhost:8084/health`. Reset breakers or verify upstream provider internet connectivity. |
| **Workflow validation infinite loop** | IDE sent `/runtime/workflows/*` requests; workflow tools unsuppressed. | [`scripts/kiro_proxy_server.js#L4659, L5984`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Ensure `FORBIDDEN_TOOLS_IN_PROXY` list strips workflow tools before sending payload upstream. |
| **Server crashes on startup (EADDRINUSE)** | Port 8084 already bound by previous node process or zombie task. | `netstat -ano \| findstr 8084`, `scripts/kiro_proxy_server.js:5609` | Run `Get-Process node \| Stop-Process -Force` or change `PROXY_PORT=8085` in `.env`. |
| **Custom provider models not discovered** | Custom endpoint offline or missing OpenAI standard `/models` route. | [`scripts/kiro_proxy_server.js#L1450`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) | Test endpoint: `curl <custom_endpoint>/models`. Check logs for `[CustomDiscovery]` errors. |

---

## 2. In-Depth Diagnostics and Remedies

### Scenario A: Tool Call Rendered as Raw Text
- **`[FACT]`**: Kiro IDE expects tool executions as AWS Smithy binary `toolUseEvent` frames. When an upstream model returns tools as text (e.g., inside markdown blocks or raw JSON), the proxy must intercept and translate them.
- **Root Causes:**
  1. DeepSeek V3 / Kilo emitted bare JSON without markdown code fences (`Format 1b`).
  2. GLM-4 / Gemini emitted XML tags like `<read_file>path</read_file>` (`Format 6b`).
  3. The model outputted a Windows path `d:\test\file` with single backslashes, causing `JSON.parse` to crash.
  4. The model emitted a shell alias like `dir` or `cat` instead of `list_directory` or `read_file`.
- **Where to Look:**
  - Check [`scripts/kiro_proxy_server.js#L2276`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`sanitizeJsonBackslashes`)
  - Check [`scripts/kiro_proxy_server.js#L2349-L2480`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/kiro_proxy_server.js) (`extractToolCallsFromResponse`)
- **Fix Verification:**
  ```bash
  node tests/test_bare_json_tool_calls.js
  node tests/test_tool_translation_layer.js
  ```

### Scenario B: Empty Assistant Response via Canvas Bridge
- **`[FACT]`**: Ngrok Canvas Bridge relies on an in-memory queue (`geminiQueue`, `kiro_proxy_server.js:452`) and browser userscript.
- **Root Causes:**
  1. Browser tab background throttling paused the userscript interval.
  2. Request timed out after 300,000ms (`GEMINI_QUEUE_TIMEOUT_MS`, line 454).
  3. Google updated Gemini Web DOM elements, breaking scraper selectors (`rich-textarea`).
  4. Ngrok public URL expired or was recreated without updating proxy config.
- **Where to Look:**
  - Proxy log: look for `[BridgePoll]` and `[GeminiCanvas]` lines.
  - Browser console on `https://gemini.google.com/app`.
- **Fix Steps:**
  1. Bring the Gemini Web browser tab to the foreground.
  2. Visit `http://localhost:8084/canvas` to verify queue depth and connection status.
  3. If DOM changed, update selector regex in [`userscript.js`](file:///d:/sdlc_studio/projects/kiro-integration/scripts/userscript.js).

### Scenario C: Extension Patches Not Loading
- **`[FACT]`**: Kiro IDE reads the patched `extension.js` bundle at startup.
- **Root Causes:**
  1. IDE auto-updated, overwriting patched `extension.js` with stock bundle.
  2. User ran `npm run patch:restore` and forgot to re-patch.
- **Verification:**
  ```bash
  npm run patch:check
  ```
- **Output Analysis:**
  - `0/4 patches applied`: Extension is completely unpatched. Run `npm run patch`.
  - `1/4` or `2/4 patches applied`: Incomplete patch due to changed upstream regex. Check `scripts/patch_kiro_extension.js`.
  - `4/4 patches applied`: Extension patched correctly. Restart Kiro IDE.

### Scenario D: Circuit Breaker Stuck in OPEN State
- **`[FACT]`**: Each provider has a circuit breaker (`CIRCUIT_BREAKERS[provider]`, `kiro_proxy_server.js:306`) tripping after 5 consecutive failures with 60-second reset timeout.
- **Diagnosis:**
  ```bash
  curl http://localhost:8084/health
  ```
  Look for `"state": "OPEN"` in provider status.
- **Fix:**
  - Breaker resets automatically after 60s once upstream errors cease.
  - To force-reset: restart the proxy process (`npm start`).

---

## 3. Log Inspection and Diagnostics

### Log Files
1. **Server Console (stdout):** Direct real-time request traces, tool conversions, and EventStream outputs.
2. **KiroProxy Log:** [`logs/kiro_proxy.log`](file:///d:/sdlc_studio/projects/kiro-integration/logs/kiro_proxy.log) (if file logging configured).
3. **Kiro IDE DevTools:** Press `Ctrl+Shift+I` (or `Help > Toggle Developer Tools`) in Kiro IDE. Filter console by `kiro.kiro-agent` or `bedrock`.

### Key Log Signatures

| Log Signature | Meaning | Next Step |
| :--- | :--- | :--- |
| `[KiroProxy] Forwarding N tools to upstream` | Tools successfully extracted from Smithy payload. | Normal operation. |
| `[KiroProxy] ⚠️ Suppressing forbidden workflow tool` | Workflow tool stripped to prevent hallucinated calls. | Normal operation. |
| `[KiroProxy] ⚠️ Circuit breaker OPEN for <provider>` | Provider failing; gateway auto-switching to next tier. | Check provider API key and quotas. |
| `[BridgePoll] GET /poll from ... (queue depth: N)` | Browser userscript active and polling. | Normal operation. |
| `[ToolExtract] Matched bare JSON tool call: <tool>` | Format 1b parser recovered raw JSON tool. | Normal operation. |
| `[ToolExtract] Matched direct XML tool call: <tool>` | Format 6b parser recovered XML tool tags. | Normal operation. |
| `Invalid EventStream prelude CRC` | Bedrock binary framing corrupted. | Debug `createEventStreamFrame`. |

---

## 4. Local Reproduction and Rollback

### How to Reproduce Locally
1. Start proxy server:
   ```bash
   node scripts/kiro_proxy_server.js
   ```
2. Send test mock Smithy Bedrock request:
   ```bash
   node tests/test_tool_translation_layer.js
   node tests/test_bare_json_tool_calls.js
   ```
3. Test Global Automode fallback chain:
   ```bash
   node tests/test_global_automode_unit.js
   ```

### Rollback Procedure
If an extension patch corrupts Kiro IDE:
```bash
# 1. Restore original extension from backup
npm run patch:restore

# 2. Verify restoration
npm run patch:check
# Expected: "0/4 patches applied (clean stock bundle)"

# 3. Restart Kiro IDE
```
If a proxy server code change causes regression:
```bash
git checkout HEAD -- scripts/kiro_proxy_server.js
npm test
```
