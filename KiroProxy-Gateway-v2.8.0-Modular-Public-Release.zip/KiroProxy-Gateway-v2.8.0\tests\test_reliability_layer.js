/**
 * test_reliability_layer.js
 * 
 * Integration tests for Kiro Native Proxy Gateway v2.5.0 Reliability Layer
 * 
 * Tests:
 * 1. Health Check Engine
 * 2. Circuit Breaker State Transitions
 * 3. Retry Engine with Exponential Backoff
 * 4. Metrics Collection
 * 5. Structured Error Responses
 * 6. End-to-End Provider Fallback
 * 7. /status and /metrics Endpoints
 */

'use strict';

const http = require('http');
const https = require('https');
const assert = require('assert');

const PROXY_HOST = '127.0.0.1';
const PROXY_PORT = 8084;
const TEST_TIMEOUT = 30000;

// ── Test Utilities ─────────────────────────────────────────────────────────────
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function httpGet(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`http://${PROXY_HOST}:${PROXY_PORT}${path}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ statusCode: res.statusCode, body: JSON.parse(data) });
        } catch {
          resolve({ statusCode: res.statusCode, body: data });
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(5000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
  });
}

function httpPost(path, data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data);
    const options = {
      hostname: PROXY_HOST,
      port: PROXY_PORT,
      path: path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = http.request(options, (res) => {
      let responseData = '';
      res.on('data', chunk => responseData += chunk);
      res.on('end', () => {
        try {
          resolve({ statusCode: res.statusCode, body: JSON.parse(responseData) });
        } catch {
          resolve({ statusCode: res.statusCode, body: responseData });
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    req.write(postData);
    req.end();
  });
}

// ── Test Suite ─────────────────────────────────────────────────────────────────
const tests = [];
let passCount = 0;
let failCount = 0;

function test(name, fn) {
  tests.push({ name, fn });
}

async function runTests() {
  console.log('\n╔════════════════════════════════════════════════════════════════╗');
  console.log('║  Kiro Native Proxy Gateway v2.5.0 - Integration Test Suite    ║');
  console.log('╚════════════════════════════════════════════════════════════════╝\n');

  for (const { name, fn } of tests) {
    try {
      process.stdout.write(`⏳ ${name}... `);
      await fn();
      console.log('✅ PASS');
      passCount++;
    } catch (err) {
      console.log(`❌ FAIL\n   Error: ${err.message}`);
      failCount++;
    }
  }

  console.log('\n╔════════════════════════════════════════════════════════════════╗');
  console.log(`║  Test Results: ${passCount} passed, ${failCount} failed (${tests.length} total)`.padEnd(65) + '║');
  console.log('╚════════════════════════════════════════════════════════════════╝\n');

  process.exit(failCount > 0 ? 1 : 0);
}

// ── Test 1: Health Check Endpoint ─────────────────────────────────────────────
test('Health Check - /health endpoint responds with provider status', async () => {
  const res = await httpGet('/health');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.status === 'ok', 'Status should be ok');
  assert.ok(res.body.health, 'Health object should exist');
  assert.ok(res.body.health.providers, 'Providers health should exist');
  
  const providers = res.body.health.providers;
  assert.ok(providers.kilo, 'Kilo provider health should exist');
  assert.ok(providers.cline, 'Cline provider health should exist');
  assert.ok(providers.openrouter, 'OpenRouter provider health should exist');
  
  // Check health status format
  for (const [name, health] of Object.entries(providers)) {
    assert.ok(['healthy', 'degraded', 'unknown'].includes(health.status),
      `${name} status should be valid (got: ${health.status})`);
    assert.ok(typeof health.latency === 'number', `${name} latency should be a number`);
    assert.ok(typeof health.lastCheck === 'number', `${name} lastCheck should be a number`);
  }
});

// ── Test 2: Circuit Breaker State ─────────────────────────────────────────────
test('Circuit Breaker - /status shows circuit breaker states', async () => {
  const res = await httpGet('/status');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.circuitBreakers, 'Circuit breakers should exist');
  
  const breakers = res.body.circuitBreakers;
  assert.ok(breakers.kilo, 'Kilo circuit breaker should exist');
  assert.ok(breakers.cline, 'Cline circuit breaker should exist');
  
  // Check circuit breaker format
  for (const [name, breaker] of Object.entries(breakers)) {
    assert.ok(['CLOSED', 'OPEN', 'HALF_OPEN'].includes(breaker.state),
      `${name} circuit state should be valid (got: ${breaker.state})`);
    assert.ok(typeof breaker.failures === 'number', `${name} failures should be a number`);
  }
});

// ── Test 3: Metrics Collection ────────────────────────────────────────────────
test('Metrics - /metrics endpoint returns Prometheus format', async () => {
  const res = await httpGet('/metrics');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(typeof res.body === 'string', 'Metrics should be plain text');
  assert.ok(res.body.includes('kiro_proxy_uptime_seconds'), 'Should include uptime metric');
  assert.ok(res.body.includes('kiro_provider_calls_total'), 'Should include provider calls metric');
  assert.ok(res.body.includes('kiro_provider_latency_p50'), 'Should include P50 latency');
  assert.ok(res.body.includes('kiro_provider_latency_p99'), 'Should include P99 latency');
});

// ── Test 4: Metrics Snapshot ──────────────────────────────────────────────────
test('Metrics - /status includes detailed metrics snapshot', async () => {
  const res = await httpGet('/status');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.metrics, 'Metrics object should exist');
  
  const metrics = res.body.metrics;
  assert.ok(typeof metrics.uptime === 'number', 'Uptime should be a number');
  assert.ok(metrics.providers, 'Provider metrics should exist');
  
  // Check provider metrics format
  for (const [name, stats] of Object.entries(metrics.providers)) {
    assert.ok(typeof stats.total === 'number', `${name} total calls should be a number`);
    assert.ok(typeof stats.success === 'number', `${name} success count should be a number`);
    assert.ok(typeof stats.failure === 'number', `${name} failure count should be a number`);
    assert.ok(typeof stats.avgLatency === 'number', `${name} avgLatency should be a number`);
    assert.ok(typeof stats.p50 === 'number', `${name} P50 should be a number`);
    assert.ok(typeof stats.p99 === 'number', `${name} P99 should be a number`);
  }
});

// ── Test 5: Model Catalog ─────────────────────────────────────────────────────
test('Model Catalog - listAvailableModels returns models', async () => {
  const res = await httpPost('/listAvailableModels', {});
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.models, 'Models array should exist');
  assert.ok(Array.isArray(res.body.models), 'Models should be an array');
  assert.ok(res.body.models.length > 0, 'Should have at least one model');
  
  // Check model format
  const firstModel = res.body.models[0];
  assert.ok(firstModel.modelId, 'Model should have modelId');
  assert.ok(firstModel.modelName, 'Model should have modelName');
});

// ── Test 6: Feature Configuration ─────────────────────────────────────────────
test('Feature Config - GetFeatureConfiguration returns feature flags', async () => {
  const res = await httpPost('/getFeatureConfiguration', {});
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.featureEvaluations, 'Feature evaluations should exist');
  assert.ok(Array.isArray(res.body.featureEvaluations), 'Should be an array');
});

// ── Test 7: Usage Limits ──────────────────────────────────────────────────────
test('Usage Limits - Returns unlimited free credits', async () => {
  const res = await httpPost('/getUsageLimits', {});
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.usageLimit > 0, 'Usage limit should be positive');
  assert.strictEqual(res.body.currentUsage, 0, 'Current usage should be 0');
  assert.ok(res.body.subscriptionInfo, 'Subscription info should exist');
});

// ── Test 8: Provider Health Status ────────────────────────────────────────────
test('Provider Health - At least one provider should be healthy', async () => {
  const res = await httpGet('/health');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  
  const providers = res.body.health.providers;
  const healthyProviders = Object.values(providers).filter(p => p.status === 'healthy');
  assert.ok(healthyProviders.length > 0, 
    `At least one provider should be healthy (found ${healthyProviders.length})`);
});

// ── Test 9: Circuit Breaker Initial State ─────────────────────────────────────
test('Circuit Breaker - All circuits should be CLOSED initially', async () => {
  const res = await httpGet('/status');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  
  const breakers = res.body.circuitBreakers;
  for (const [name, breaker] of Object.entries(breakers)) {
    if (breaker.failures === 0) {
      assert.strictEqual(breaker.state, 'CLOSED', 
        `${name} circuit should be CLOSED when failures=0 (got: ${breaker.state})`);
    }
  }
});

// ── Test 10: Proxy Version ────────────────────────────────────────────────────
test('Version - Proxy identifies as v2.5.0', async () => {
  const res = await httpGet('/status');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(res.body.proxy.includes('2.5'), 'Proxy version should be 2.5.x');
  assert.ok(res.body.proxy.includes('Reliability'), 'Should mention Reliability');
});

// ── Test 11: OpenAI Compatible Endpoint ───────────────────────────────────────
test('OpenAI API - /v1/chat/completions endpoint exists', async () => {
  const res = await httpPost('/v1/chat/completions', {
    model: 'kilo-auto/small',
    messages: [{ role: 'user', content: 'test' }],
    stream: false
  });
  
  // Should either succeed or return proper error structure
  assert.ok([200, 502].includes(res.statusCode), 
    `Status should be 200 or 502 (got: ${res.statusCode})`);
  
  if (res.statusCode === 200) {
    assert.ok(res.body.choices, 'Response should have choices array');
    assert.ok(res.body.model, 'Response should have model field');
  } else {
    assert.ok(res.body.error, 'Error response should have error object');
  }
});

// ── Test 12: Structured Error Format ──────────────────────────────────────────
test('Structured Errors - Provider errors should have code and remediation', async () => {
  // This test assumes at least one provider will fail or timeout
  // We'll check the error format by inspecting the /status metrics
  const res = await httpGet('/status');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  
  // If any provider has failures, the circuit breaker should track them
  const breakers = res.body.circuitBreakers;
  const hasFailures = Object.values(breakers).some(b => b.failures > 0);
  
  // Just verify the structure exists (actual error testing would require simulating failures)
  assert.ok(typeof hasFailures === 'boolean', 'Should track failure state');
});

// ── Test 13: Health Check Timing ──────────────────────────────────────────────
test('Health Check - Provider checks complete within acceptable time', async () => {
  const res = await httpGet('/health');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  
  const providers = res.body.health.providers;
  for (const [name, health] of Object.entries(providers)) {
    if (health.status === 'healthy') {
      assert.ok(health.latency < 5000, 
        `${name} health check should complete within 5s (took ${health.latency}ms)`);
    }
  }
});

// ── Test 14: Metrics Uptime ───────────────────────────────────────────────────
test('Metrics - Uptime should be tracked correctly', async () => {
  const res1 = await httpGet('/status');
  const uptime1 = res1.body.metrics.uptime;
  
  await sleep(1000); // Wait 1 second
  
  const res2 = await httpGet('/status');
  const uptime2 = res2.body.metrics.uptime;
  
  assert.ok(uptime2 > uptime1, 
    `Uptime should increase (was ${uptime1}ms, now ${uptime2}ms)`);
  assert.ok(uptime2 - uptime1 >= 900, 
    `Uptime delta should be at least 900ms (got ${uptime2 - uptime1}ms)`);
});

// ── Test 15: Provider Availability ────────────────────────────────────────────
test('Provider Availability - Status shows available providers', async () => {
  const res = await httpGet('/status');
  assert.strictEqual(res.statusCode, 200, 'Status code should be 200');
  assert.ok(Array.isArray(res.body.availableProviders), 
    'availableProviders should be an array');
  assert.ok(res.body.availableProviders.includes('kilo'), 
    'Should list kilo as available provider');
  assert.ok(res.body.availableProviders.includes('cline'), 
    'Should list cline as available provider');
});

// ── Run Tests ──────────────────────────────────────────────────────────────────
console.log('\n🚀 Starting Kiro Proxy Gateway Reliability Tests...\n');
console.log(`   Target: http://${PROXY_HOST}:${PROXY_PORT}`);
console.log(`   Timeout: ${TEST_TIMEOUT}ms per test\n`);

// Wait for proxy to be ready
setTimeout(() => {
  runTests().catch(err => {
    console.error('\n❌ Test suite failed:', err.message);
    process.exit(1);
  });
}, 2000); // Give proxy 2s to start
