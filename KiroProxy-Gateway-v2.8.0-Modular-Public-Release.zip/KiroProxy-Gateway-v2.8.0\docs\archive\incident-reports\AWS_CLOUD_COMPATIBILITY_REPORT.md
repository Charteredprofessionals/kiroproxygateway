# AWS Cloud Compatibility Report
## Kiro Gateway v2.7.1 - Native Kiro IDE Integration

**Date**: 2026-10-06  
**Status**: ✅ **FULLY COMPATIBLE** with Kiro IDE AWS EventStream Protocol

---

## Executive Summary

**All 7 providers in Kiro Gateway now return `_kiro` metadata**, ensuring 100% compatibility with Kiro IDE's AWS EventStream format. The gateway acts as a **transparent AWS Cloud replacement** for Kiro IDE, supporting:

- ✅ Multi-tool execution (parallel and sequential)
- ✅ AWS EventStream binary framing with CRC32
- ✅ Native tool calling (toolUseEvent emission)
- ✅ Streaming text responses (contentBlockDelta)
- ✅ Proper stopReason propagation (TOOL_USE / END_TURN)
- ✅ All Kiro IDE functionality (coding, file operations, MCP tools)

---

## Provider Compatibility Matrix

| Provider | Tool Translation | `_kiro` Metadata | AWS EventStream | Status |
|----------|-----------------|------------------|-----------------|--------|
| **Kilo Gateway** | ✅ Anthropic format | ✅ Yes | ✅ Yes | **100%** |
| **Cline API** | ✅ Anthropic format | ✅ Yes | ✅ Yes | **100%** |
| **OpenRouter** | ✅ OpenAI format | ✅ Yes | ✅ Yes | **100%** |
| **OrcaRouter** | ✅ OpenAI format | ✅ Yes | ✅ Yes | **100%** |
| **Gemini API** | ✅ Gemini format | ✅ Yes (FIXED) | ✅ Yes | **100%** |
| **Ngrok/Gemini** | ✅ Canvas format | ✅ Yes | ✅ Yes | **100%** |
| **Custom APIs** | ✅ OpenAI format | ✅ Yes (FIXED) | ✅ Yes | **100%** |

### What Was Fixed (v2.7.1)

#### 1. **Gemini API Provider** (Direct Google AI)
**Problem**: Returned plain OpenAI format without `_kiro` metadata.

**Fix**: Added tool extraction and `_kiro` metadata:
```javascript
// Extract tool calls from response (handles all 5 formats)
const toolCalls = extractToolCallsFromResponse(text, tools);

// Strip tool blocks from text to prevent duplicates
const cleanText = toolCalls.length > 0 
  ? stripToolBlocksFromText(text) 
  : text;

// Return with _kiro metadata for AWS EventStream compatibility
resolve({
  id: 'gemini-' + Date.now(),
  // ... standard OpenAI fields ...
  _kiro: {
    text: cleanText,
    toolCalls: toolCalls,
    stopReason: toolCalls.length > 0 ? 'TOOL_USE' : 'END_TURN'
  }
});
```

#### 2. **Custom API Provider** (Groq, Ollama, DeepSeek, etc.)
**Problem**: No tool translation and no `_kiro` metadata support.

**Fix**: 
- Added `tools` parameter to function signature
- Added tool translation via `translateToolsToUpstream(tools, 'openai')`
- Added tool extraction from responses
- Added `_kiro` metadata generation

```javascript
function callCustomApi(cfg, messages, requestedModel, tools = []) {
  // Translate tools to OpenAI format (most custom APIs use OpenAI-style tools)
  const translatedTools = tools && tools.length > 0 
    ? translateToolsToUpstream(tools, 'openai') 
    : undefined;

  // ... send request with tools ...

  // Extract tool calls and add _kiro metadata
  const toolCalls = extractToolCallsFromResponse(responseText, tools);
  const cleanText = toolCalls.length > 0 
    ? stripToolBlocksFromText(responseText) 
    : responseText;

  resolve({
    ...parsed,
    _kiro: {
      text: cleanText,
      toolCalls: toolCalls,
      stopReason: toolCalls.length > 0 ? 'TOOL_USE' : 'END_TURN'
    }
  });
}
```

#### 3. **Ngrok Path Default Fix**
**Problem**: `list_directory` tool was being called with relative path `'.'` instead of absolute path.

**Fix**: Added workspace root fallback in `normalizeGeminiToolCalls()`:
```javascript
if (name === 'list_directory') {
  const p = args.path || args.directory || args.dir || args.folder || args.target;
  if (!p || p === '.') {
    // list_directory requires absolute path - default to workspace root
    const workspaceRoot = process.env.WORKSPACE_ROOT || process.cwd();
    console.warn(`[KiroProxy] ⚠️  list_directory missing/relative path from Gemini — defaulting to workspace root: ${workspaceRoot}`);
    args.path = workspaceRoot;
  } else {
    args.path = p;
  }
  if (!args.explanation) args.explanation = `Listing contents of ${args.path}`;
}
```

---

## Technical Architecture

### AWS EventStream Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        KIRO IDE CLIENT                          │
│  1. Sends POST / with x-amz-target header                       │
│  2. Includes conversationState, tools, systemPrompt             │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                    KIRO GATEWAY (Port 8084)                     │
├─────────────────────────────────────────────────────────────────┤
│  1. extractMessagesFromKiroPayload()                            │
│  2. translateToolsToUpstream(tools, providerType)               │
│  3. callProvider(messages, model, tools)                        │
│     ├─► Kilo Gateway     (Anthropic format)                     │
│     ├─► Cline API        (Anthropic format)                     │
│     ├─► OpenRouter       (OpenAI format)                        │
│     ├─► OrcaRouter       (OpenAI format)                        │
│     ├─► Gemini API       (Gemini format)                        │
│     ├─► Ngrok/Gemini     (Canvas format)                        │
│     └─► Custom APIs      (OpenAI format)                        │
│  4. Provider returns response with _kiro metadata               │
│  5. createEventStreamFrame() - Binary AWS format                │
│  6. Emit toolUseEvent / contentBlockDelta / metadataEvent       │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                        KIRO IDE CLIENT                          │
│  ✅ Receives AWS EventStream chunks                             │
│  ✅ Executes tools autonomously                                 │
│  ✅ Shows progress in sidebar                                   │
│  ✅ Streams text in chat window                                 │
└─────────────────────────────────────────────────────────────────┘
```

### `_kiro` Metadata Structure

All providers now return this standardized metadata:

```javascript
{
  id: "provider-timestamp",
  object: "chat.completion",
  model: "requested-model",
  choices: [{ message: { role: "assistant", content: "..." }, ... }],
  usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
  
  // ✅ AWS EventStream compatibility layer
  _kiro: {
    text: "clean text without tool blocks",
    toolCalls: [
      { name: "list_directory", args: { path: "/abs/path" } },
      { name: "read_file", args: { path: "/abs/file.txt" } }
    ],
    stopReason: "TOOL_USE" | "END_TURN"
  }
}
```

### Tool Translation Layer

Each provider receives tools in its native format:

```javascript
// Kiro IDE tools (Anthropic format)
const kiroTools = [
  {
    name: "list_directory",
    description: "List directory contents",
    input_schema: {
      type: "object",
      properties: { path: { type: "string" } },
      required: ["path"]
    }
  }
];

// Provider-specific translation
translateToolsToUpstream(kiroTools, 'anthropic'); // Cline, Kilo
translateToolsToUpstream(kiroTools, 'openai');    // OpenRouter, OrcaRouter, Custom
translateToolsToUpstream(kiroTools, 'gemini');    // Gemini API
// Ngrok/Canvas: raw format (Canvas handles conversion)
```

---

## Test Results

### Test 1: Models Endpoint
```bash
GET http://127.0.0.1:8084/v1/models
```
**Result**: ✅ **PASS** - 436 models available

### Test 2: Simple Chat Completion
```bash
POST http://127.0.0.1:8084/v1/chat/completions
Model: kilo-auto/small
Prompt: "What is 2+2?"
```
**Result**: ✅ **PASS** - Response: "4"

### Test 3: AWS-Style Kiro IDE Request
```bash
POST http://127.0.0.1:8084/
x-amz-target: com.amazon.kiro.runtimeservice#GenerateAssistantResponse
Body: { conversationState, systemPrompt, requestedModel, tools }
```
**Result**: ✅ **PASS** - AWS EventStream binary response received

### Test 4: Tool Calling (All Providers)
Each provider tested with `list_directory` tool:
- ✅ Kilo Gateway: Tool extracted and normalized
- ✅ Cline API: Tool extracted and normalized
- ✅ OpenRouter: Tool extracted and normalized
- ✅ OrcaRouter: Tool extracted and normalized
- ✅ Gemini API: Tool extracted and normalized (FIXED)
- ✅ Ngrok/Gemini: Native functionCalls normalized
- ✅ Custom APIs: Tool extracted and normalized (FIXED)

### Test 5: Ngrok Path Normalization
```javascript
// Gemini Canvas sends: { name: "list_directory", args: {} }
// Gateway normalizes to: { name: "list_directory", args: { path: "d:\\sdlc_studio\\projects\\kiro-integration" } }
```
**Result**: ✅ **PASS** - Relative/missing paths converted to absolute workspace root

---

## Kiro IDE Feature Support

| Feature | Supported | Notes |
|---------|-----------|-------|
| **Chat Completions** | ✅ Yes | All providers working |
| **Tool Calling** | ✅ Yes | 5 formats supported (JSON, XML, Anthropic, Kiro, code blocks) |
| **Multi-Tool Execution** | ✅ Yes | Sequential and parallel |
| **File Operations** | ✅ Yes | read_file, fs_write, str_replace, list_directory |
| **Shell Commands** | ✅ Yes | execute_pwsh |
| **Code Search** | ✅ Yes | grep_search, file_search |
| **MCP Tools** | ✅ Yes | Full MCP protocol support |
| **Streaming** | ✅ Yes | AWS EventStream binary format |
| **Model Catalog** | ✅ Yes | 436 models auto-populated |
| **Health Checks** | ✅ Yes | All 6 providers monitored |
| **Circuit Breaker** | ✅ Yes | Auto-recovery on failures |
| **Rate Limiting** | ✅ Yes | 20 polls/min for Canvas bridge |
| **Retry Logic** | ✅ Yes | Exponential backoff |
| **Zero-Cost Operation** | ✅ Yes | All free providers + Gemini Canvas |

---

## Verification Commands

### Check Server Status
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8084/v1/models" `
  -Headers @{'ngrok-skip-browser-warning'='true'} | 
  Select-Object -First 1
```

### Test Chat Completion
```powershell
$body = @{
  model = "kilo-auto/small"
  messages = @(@{role="user"; content="Hello!"})
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://127.0.0.1:8084/v1/chat/completions" `
  -Method POST -Body $body `
  -Headers @{'Content-Type'='application/json'}
```

### Test AWS-Style Request
```powershell
$body = @{
  conversationState = @{
    messages = @(@{role="user"; content="Test"})
  }
  systemPrompt = "You are helpful."
  requestedModel = "kilo-auto/small"
} | ConvertTo-Json -Depth 5

Invoke-RestMethod -Uri "http://127.0.0.1:8084/" `
  -Method POST -Body $body `
  -Headers @{
    'Content-Type'='application/json'
    'x-amz-target'='com.amazon.kiro.runtimeservice#GenerateAssistantResponse'
  }
```

---

## Conclusion

**Kiro Gateway v2.7.1 is 100% compatible with Kiro IDE** and can serve as a drop-in replacement for AWS Kiro Cloud. All providers now implement the `_kiro` metadata contract, ensuring:

1. **Tool calls are properly extracted and normalized**
2. **AWS EventStream binary format is correctly generated**
3. **StopReason is accurately propagated** (TOOL_USE vs END_TURN)
4. **Clean text without duplicate tool blocks**
5. **Absolute paths for filesystem operations**

The gateway successfully acts as a **Native AWS Cloud** from Kiro IDE's perspective, enabling:
- Zero-cost AI development with free providers
- Local-first operation (no cloud dependency)
- Full Kiro IDE feature parity
- Production-ready reliability (circuit breakers, retries, health checks)

---

## Related Documentation

- [Ngrok Tool Execution Fix](./troubleshooting/NGROK_TOOL_EXECUTION_FIX.md)
- [Gemini Canvas Bridge Setup](../GEMINI_CANVAS_BRIDGE_SETUP.md)
- [Kiro Gateway README](../README.md)

**Last Updated**: 2026-10-06  
**Version**: v2.7.1
