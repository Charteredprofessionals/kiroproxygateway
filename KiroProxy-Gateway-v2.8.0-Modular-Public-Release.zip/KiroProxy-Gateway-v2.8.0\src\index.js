/**
 * src/index.js - KiroProxy Gateway Modular HTTP Server
 * Strangler Fig modular replacement running on port 8085 (< 150 lines)
 */

'use strict';

const http = require('http');
const { DEFAULT_PORT, PROXY_PORT, loadCustomConfig } = require('./config/index');
const { autoPopulateFreeModels } = require('./config/catalog');
const { readBody } = require('./protocol/smithy_parser');
const { handleConverseStreaming } = require('./handlers/bedrock_handler');
const { handleCanvasRoutes } = require('./handlers/canvas_handler');
const { handleWorkflowRoutes } = require('./handlers/workflow_handler');
const { handleDiagnosticsRoutes, handleAwsCatchAll } = require('./handlers/diagnostics_handler');
const { runHealthChecks, startNgrokTunnel } = require('./resilience/health');
const { cleanStaleQueueEntries } = require('./providers/canvas_bridge');

const server = http.createServer(async (req, res) => {
  const rawUrl = req.url.split('?')[0];
  const urlPath = rawUrl.toLowerCase();
  const method = req.method.toUpperCase();
  const reqId = req.headers['x-amzn-requestid'] || ('req_' + Date.now());
  const amzTarget = (req.headers['x-amz-target'] || req.headers['x-amzn-target'] || '').toLowerCase();

  // CORS Origin calculation
  const reqOrigin = req.headers.origin || req.headers.Origin;
  let corsOrigin = '*';
  let allowCredentials = false;
  if (reqOrigin) {
    try {
      const parsedOrigin = new URL(reqOrigin);
      const host = parsedOrigin.hostname.toLowerCase();
      if (host === 'gemini.google.com' || host.endsWith('.gemini.google.com') ||
          host === 'usercontent.goog' || host.endsWith('.usercontent.goog') ||
          host === 'localhost' || host.endsWith('.localhost') || host === '127.0.0.1') {
        corsOrigin = reqOrigin;
        allowCredentials = true;
      } else {
        corsOrigin = reqOrigin;
      }
    } catch (_) { corsOrigin = reqOrigin; }
  }

  const corsAllowHeaders = 'Content-Type, Authorization, x-amzn-requestid, x-amzn-kiro-conversation-id, x-amz-target, x-amzn-target, x-amzn-kiro-agent-mode, ngrok-skip-browser-warning';
  res.setHeader('Access-Control-Allow-Origin', corsOrigin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', corsAllowHeaders);
  res.setHeader('Access-Control-Max-Age', '86400');
  res.setHeader('ngrok-skip-browser-warning', '69420');
  if (allowCredentials || (reqOrigin && corsOrigin !== '*')) {
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Vary', 'Origin');
  }

  // Stage 1: OPTIONS CORS Preflight
  if (method === 'OPTIONS') {
    res.writeHead(200, {
      'Access-Control-Allow-Origin': corsOrigin,
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': corsAllowHeaders,
      'Access-Control-Max-Age': '86400',
      'ngrok-skip-browser-warning': '69420',
      'Server': 'Amazon.com',
      'Content-Length': '0'
    });
    return res.end();
  }

  // Parse request body for POST methods
  let body = {};
  if (method === 'POST') {
    try {
      body = await readBody(req);
    } catch (err) {
      if (!res.headersSent) {
        const statusCode = err.message.includes('exceeds') ? 413 : 400;
        res.writeHead(statusCode, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: err.message } }));
      }
      return;
    }
  }

  const corsContext = { corsOrigin, allowCredentials, corsAllowHeaders, reqOrigin };

  // Stage 2: AWS Bedrock Endpoints
  const isConverse = urlPath.includes('generateassistantresponse') ||
                     amzTarget.includes('generateassistantresponse') ||
                     urlPath.includes('/runtime/converse') ||
                     Boolean(body.conversationState);
  if (isConverse) {
    return await handleConverseStreaming(req, res, body, reqId);
  }

  // Stage 3: Canvas Bridge Endpoints (MUST PRECEDE CATCH-ALL!)
  if (await handleCanvasRoutes(req, res, urlPath, method, corsContext, body)) {
    return;
  }

  // Stage 4: Workflow & Diagnostics Endpoints
  if (await handleWorkflowRoutes(req, res, urlPath, method, amzTarget, reqId, body)) {
    return;
  }
  if (await handleDiagnosticsRoutes(req, res, urlPath, method, amzTarget, reqId, body)) {
    return;
  }

  // Stage 5: Universal AWS Catch-All (Zero 404s)
  const isNoise = urlPath.includes('/health') || urlPath.includes('/poll') || urlPath.includes('/ws');
  handleAwsCatchAll(req, res, reqId, !isNoise);
});

// Periodic maintenance
const maintenanceTimer = setInterval(cleanStaleQueueEntries, 60000);
if (maintenanceTimer && typeof maintenanceTimer.unref === 'function') {
  maintenanceTimer.unref();
}

// Process Safety Shields
process.on('uncaughtException', (err) => {
  console.error('[KiroProxy Safety Shield] Uncaught Exception:', err.message);
});
process.on('unhandledRejection', (reason) => {
  console.error('[KiroProxy Safety Shield] Unhandled Rejection:', reason);
});

if (require.main === module) {
  server.listen(PROXY_PORT, '127.0.0.1', async () => {
    console.log(`\n==========================================================`);
    console.log(`  KiroProxy Gateway v2.8.0 (Modular src/) on port ${PROXY_PORT}`);
    console.log(`==========================================================\n`);
    loadCustomConfig();
    await runHealthChecks().catch(() => {});
    await startNgrokTunnel(PROXY_PORT).catch(() => {});
    await autoPopulateFreeModels(true).catch(() => {});
  });
  server.on('error', (err) => {
    console.error(`[ERROR] Server error on port ${PROXY_PORT}:`, err.message);
  });
}

module.exports = { server, DEFAULT_PORT, PROXY_PORT };
