# API Documentation

This section contains API reference documentation.

## 📄 Available Documents

- **[Endpoint Reference](ENDPOINT_REFERENCE.md)** - API endpoints and usage
- **[Request Formats](REQUEST_FORMATS.md)** - Request examples and formats

## 🎯 Purpose

These documents describe the API endpoints, request/response formats, and integration patterns for the KiroProxy Gateway.

---

**Part of KiroProxy Gateway Documentation**