/**
 * src/providers/openrouter.js - OpenRouter Provider Adapter (https://openrouter.ai)
 * Pure CommonJS exportable module
 */

'use strict';

const https = require('https');
const { executeWithRetry } = require('../resilience/retry_engine');
const { isCircuitOpen } = require('../resilience/circuit_breaker');
const { ProxyError } = require('../resilience/errors');
const { loadCustomConfig, isKeyValid } = require('../config/index');
const { translateToolsToUpstream } = require('../translators/tool_translator');
const { recordProviderCall } = require('../resilience/metrics');
const { extractToolsAndTextFromProviderResponse } = require('../translators/tool_extractor');

const OPENROUTER_TIMEOUT = 120000;

function callOpenRouter(messages, requestedModel, tools = [], otomodeContext = null) {
  return executeWithRetry(async () => {
    if (isCircuitOpen('openrouter')) {
      const err = new Error('OpenRouter circuit breaker is open');
      err.code = 'CIRCUIT_OPEN';
      throw err;
    }

    const cfg = loadCustomConfig();
    const apiKey = cfg.openrouterApiKey || cfg.providers?.openrouter?.apiKey || cfg.apiKey || '';
    if (!apiKey || !isKeyValid(apiKey)) {
      const err = new Error('No valid OpenRouter API key configured in kiro_ai_config.json');
      err.code = 'MISSING_API_KEY';
      throw err;
    }

    const start = Date.now();

    let modelSlug = requestedModel || 'nvidia/nemotron-3.5-lightning:free';
    if (requestedModel === 'openrouter-claude') modelSlug = 'anthropic/claude-3.7-sonnet';
    else if (requestedModel === 'openrouter-deepseek') modelSlug = 'deepseek/deepseek-chat';
    else if (requestedModel === 'openrouter-nemotron') modelSlug = 'nvidia/nemotron-3.5-lightning:free';
    else if (requestedModel && requestedModel.startsWith('openrouter-')) modelSlug = requestedModel.replace(/^openrouter-/, '');
    else if (modelSlug === 'openai/gpt-3.5-turbo') modelSlug = 'nvidia/nemotron-3.5-lightning:free';

    return new Promise((resolve, reject) => {
      const translatedTools = tools && tools.length > 0
        ? translateToolsToUpstream(tools, 'openai')
        : undefined;

      const requestBody = {
        model: modelSlug,
        messages: messages,
        stream: false
      };

      if (translatedTools) {
        requestBody.tools = translatedTools;
      }

      const postData = JSON.stringify(requestBody);

      const headers = {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData),
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer': 'https://sdlc-studio.local',
        'X-Title': 'KiroProxy Gateway',
        'User-Agent': 'KiroProxy/2.7.0'
      };

      const options = {
        hostname: 'openrouter.ai',
        port: 443,
        path: '/api/v1/chat/completions',
        method: 'POST',
        headers: headers,
        timeout: OPENROUTER_TIMEOUT
      };

      console.log(`[KiroProxy] Forwarding to OpenRouter (https://openrouter.ai, model=${modelSlug}${translatedTools ? `, ${translatedTools.length} tools` : ''})...`);

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          const latency = Date.now() - start;

          try {
            const parsed = JSON.parse(data);
            if (res.statusCode >= 200 && res.statusCode < 300) {
              const extracted = extractToolsAndTextFromProviderResponse(parsed, tools);
              const hasValidContent = Boolean(((extracted.text && extracted.text.trim().length > 0) || (extracted.toolCalls && extracted.toolCalls.length > 0)) && !parsed.error);

              if (hasValidContent) {
                recordProviderCall('openrouter', true, latency);
                resolve({
                  ...parsed,
                  _kiro: extracted
                });
                return;
              }

              console.warn(`[KiroProxy] ⚠️ OpenRouter returned HTTP 200 with empty completion (0 text, 0 tools) for model '${modelSlug}'`);
              recordProviderCall('openrouter', false, latency);

              if (otomodeContext && otomodeContext._fallbackList && otomodeContext._fallbackList.length > 0) {
                const oldModel = otomodeContext._activeModel || modelSlug || requestedModel;
                const nextModel = otomodeContext._fallbackList.shift();
                otomodeContext._activeModel = nextModel;
                const delay = 50;
                console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName || 'OpenRouter'}) from ${oldModel} → ${nextModel} due to EMPTY_RESPONSE (HTTP 200)`);
                (async () => {
                  await new Promise(r => setTimeout(r, delay));
                  try {
                    const result = await callOpenRouter(messages, nextModel, tools, otomodeContext);
                    resolve(result);
                  } catch (err) {
                    reject(err);
                  }
                })();
                return;
              }

              if (otomodeContext && (!otomodeContext._fallbackList || otomodeContext._fallbackList.length === 0)) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName || 'OpenRouter'}`);
              }

              const emptyErr = new ProxyError(
                'EMPTY_RESPONSE',
                `OpenRouter (${res.statusCode}): Model returned 0 text and 0 tools`,
                'Free model context saturated or empty completion received',
                { statusCode: res.statusCode }
              );
              emptyErr.code = 'EMPTY_RESPONSE';
              reject(emptyErr);
              return;
            } else {
              if (translatedTools && (res.statusCode === 400 || res.statusCode === 422)) {
                console.log(`[KiroProxy] 🔄 OpenRouter model '${modelSlug}' rejected native tools (${res.statusCode}); retrying with prompt-based tool guide...`);
                callOpenRouter(messages, modelSlug, [], otomodeContext).then(resolve).catch(reject);
                return;
              }

              recordProviderCall('openrouter', false, latency);

              const isOtomodeRetryable = res.statusCode >= 400;

              if (otomodeContext && otomodeContext._fallbackList.length > 0 && isOtomodeRetryable) {
                const oldModel = otomodeContext._activeModel;
                const nextModel = otomodeContext._fallbackList.shift();
                if (nextModel) {
                  otomodeContext._activeModel = nextModel;
                  const delay = 250 + Math.random() * 500;
                  console.log(`[Otomode] 🔄 Switching (${otomodeContext._providerName}) from ${oldModel} → ${nextModel} due to HTTP ${res.statusCode} (${otomodeContext._fallbackList.length} free models remaining)`);
                  (async () => {
                    await new Promise(r => setTimeout(r, delay));
                    try {
                      const result = await callOpenRouter(messages, nextModel, tools, otomodeContext);
                      resolve(result);
                    } catch (err) {
                      reject(err);
                    }
                  })();
                  return;
                }
              }

              if (otomodeContext && otomodeContext._fallbackList.length === 0 && isOtomodeRetryable) {
                console.log(`[Otomode] ❌ Exhausted all free models for provider ${otomodeContext._providerName}`);
              }

              const err = new Error(`OpenRouter (${res.statusCode}): ${parsed.error?.message || data.slice(0, 100)}`);
              err.code = 'PROVIDER_ERROR';
              reject(err);
            }
          } catch {
            recordProviderCall('openrouter', false, latency);
            const err = new Error(`Invalid JSON from OpenRouter (${res.statusCode}): ${data.slice(0, 150)}`);
            err.code = 'INVALID_RESPONSE';
            reject(err);
          }
        });
      });

      req.on('error', err => {
        recordProviderCall('openrouter', false, Date.now() - start);
        err.code = err.code || 'NETWORK_ERROR';
        reject(err);
      });

      req.on('timeout', () => {
        req.destroy();
        recordProviderCall('openrouter', false, Date.now() - start);
        const err = new Error(`OpenRouter timed out after ${OPENROUTER_TIMEOUT}ms`);
        err.code = 'TIMEOUT';
        reject(err);
      });

      req.write(postData);
      req.end();
    });
  }, 'openrouter', otomodeContext ? 1 : 3);
}

module.exports = {
  callOpenRouter
};
